/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Circle, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Trophy, 
  Trash2, 
  User, 
  Cpu, 
  Layers, 
  Undo2, 
  HelpCircle, 
  ChevronLeft, 
  ChevronRight, 
  Sparkles, 
  Activity, 
  Flame,
  Info
} from 'lucide-react';

// Type definitions for TicTacToe state
type BoardState = (string | null)[];
type GameMode = 'pvp' | 'ai';
type Difficulty = 'easy' | 'medium' | 'hard';
type GridSize = 3 | 4 | 5;

interface Scores {
  pvp: { x: number; o: number; ties: number };
  ai: { player: number; computer: number; ties: number };
  streak: number;
}

export default function App() {
  // Game Setup Configurations
  const [gridSize, setGridSize] = useState<GridSize>(3);
  const [gameMode, setGameMode] = useState<GameMode>('ai');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Core Game Loop States
  // To support time travel (undo/redo), we maintain a history of board states
  const [history, setHistory] = useState<BoardState[]>([Array(9).fill(null)]);
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [isXNext, setIsXNext] = useState<boolean>(true);
  
  // Computed game states
  const [winningPlayer, setWinningPlayer] = useState<string | null>(null);
  const [winningLine, setWinningLine] = useState<number[] | null>(null);
  const [isAiThinking, setIsAiThinking] = useState<boolean>(false);
  const [showRules, setShowRules] = useState<boolean>(false);

  // Scoreboard metrics
  const [scores, setScores] = useState<Scores>({
    pvp: { x: 0, o: 0, ties: 0 },
    ai: { player: 0, computer: 0, ties: 0 },
    streak: 0,
  });

  const board = history[currentStep];

  // Dynamically calculate winning line combinations based on current grid size (3x3, 4x4, 5x5)
  // This is highly flexible and avoids hardcoding hundreds of index subsets.
  const getWinningCombinations = (size: number): number[][] => {
    const combos: number[][] = [];
    
    // 1. Horizontal row alignments (e.g. for 3x3: [0,1,2], [3,4,5], [6,7,8])
    for (let r = 0; r < size; r++) {
      const row: number[] = [];
      for (let c = 0; c < size; c++) {
        row.push(r * size + c);
      }
      combos.push(row);
    }
    
    // 2. Vertical column alignments (e.g. for 3x3: [0,3,6], [1,4,7], [2,5,8])
    for (let c = 0; c < size; c++) {
      const col: number[] = [];
      for (let r = 0; r < size; r++) {
        col.push(r * size + c);
      }
      combos.push(col);
    }
    
    // 3. Diagonal alignment: Top-Left to Bottom-Right (e.g. for 3x3: [0,4,8])
    const diag1: number[] = [];
    for (let i = 0; i < size; i++) {
      diag1.push(i * size + i);
    }
    combos.push(diag1);
    
    // 4. Diagonal alignment: Top-Right to Bottom-Left (e.g. for 3x3: [2,4,6])
    const diag2: number[] = [];
    for (let i = 0; i < size; i++) {
      diag2.push(i * size + (size - 1 - i));
    }
    combos.push(diag2);
    
    return combos;
  };

  const winningCombinations = getWinningCombinations(gridSize);

  // Load metrics from persistent LocalStorage on initial load
  useEffect(() => {
    const savedScores = localStorage.getItem('ttt-multigrid-scores');
    if (savedScores) {
      try {
        setScores(JSON.parse(savedScores));
      } catch (e) {
        console.error('Failed to parse saved board scores', e);
      }
    }
  }, []);

  // Sync scores back to localStorage when altered
  const saveScores = (newScores: Scores) => {
    setScores(newScores);
    localStorage.setItem('ttt-multigrid-scores', JSON.stringify(newScores));
  };

  // High quality client-side Web Audio Synthesizer to output zero-asset game sound effects
  const playSound = (type: 'click' | 'win' | 'draw' | 'reset' | 'thinking') => {
    if (!soundEnabled) return;
    try {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();
      
      if (type === 'click') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(isXNext ? 520 : 380, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(isXNext ? 800 : 250, ctx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.04, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.1);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.1);
      } else if (type === 'thinking') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(300, ctx.currentTime);
        gain.gain.setValueAtTime(0.01, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.15);
      } else if (type === 'win') {
        // High craft retro victory major triad sequence
        const notes = [261.63, 329.63, 392.00, 523.25]; // C4 -> E4 -> G4 -> C5
        notes.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.08);
          gain.gain.setValueAtTime(0.06, ctx.currentTime + idx * 0.08);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.08 + 0.3);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(ctx.currentTime + idx * 0.08);
          osc.stop(ctx.currentTime + idx * 0.08 + 0.45);
        });
      } else if (type === 'draw') {
        // Neutral minor tone
        const notes = [220.00, 233.08]; // A3, A#3
        notes.forEach((freq) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(freq, ctx.currentTime);
          gain.gain.setValueAtTime(0.03, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start();
          osc.stop(ctx.currentTime + 0.3);
        });
      } else if (type === 'reset') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(150, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(600, ctx.currentTime + 0.25);
        gain.gain.setValueAtTime(0.03, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.25);
      }
    } catch (e) {
      // Graceful catch for browsers blocking early audio initialization
    }
  };

  // Evaluate the current board state to check if someone has completed a winning alignment
  const checkWinState = (currentBoard: BoardState) => {
    for (const combo of winningCombinations) {
      const first = currentBoard[combo[0]];
      if (first && combo.every(idx => currentBoard[idx] === first)) {
        return { winner: first, line: combo };
      }
    }
    return null;
  };

  // Handle a tile select event at a specific index
  const makeMove = (index: number, player: string) => {
    if (board[index] || winningPlayer || isAiThinking) return;

    // Truncate any future redo-states if moving from a past step
    const nextHistory = history.slice(0, currentStep + 1);
    const newBoard = [...board];
    newBoard[index] = player;

    const updatedHistory = [...nextHistory, newBoard];
    setHistory(updatedHistory);
    setCurrentStep(updatedHistory.length - 1);
    playSound('click');

    const winData = checkWinState(newBoard);
    if (winData) {
      setWinningPlayer(winData.winner);
      setWinningLine(winData.line);
      playSound('win');

      // Update metrics depending on game mode
      if (gameMode === 'pvp') {
        const winnerKey = winData.winner.toLowerCase() as 'x' | 'o';
        const updated = {
          ...scores,
          pvp: {
            ...scores.pvp,
            [winnerKey]: scores.pvp[winnerKey] + 1
          }
        };
        saveScores(updated);
      } else {
        // AI Mode: X is always human player, O is Computer
        const isHumanWinner = winData.winner === 'X';
        const updated = {
          ...scores,
          ai: {
            ...scores.ai,
            player: scores.ai.player + (isHumanWinner ? 1 : 0),
            computer: scores.ai.computer + (!isHumanWinner ? 1 : 0),
          },
          streak: isHumanWinner ? scores.streak + 1 : 0
        };
        saveScores(updated);
      }
    } else if (newBoard.every(cell => cell !== null)) {
      // Handle grid completion tie (draw)
      setWinningPlayer('Draw');
      playSound('draw');
      if (gameMode === 'pvp') {
        saveScores({
          ...scores,
          pvp: { ...scores.pvp, ties: scores.pvp.ties + 1 }
        });
      } else {
        saveScores({
          ...scores,
          ai: { ...scores.ai, ties: scores.ai.ties + 1 },
          streak: 0
        });
      }
    } else {
      setIsXNext(player === 'X' ? false : true);
    }
  };

  // Human click wrapper
  const handleCellClick = (index: number) => {
    const currentPlayer = isXNext ? 'X' : 'O';
    
    // In computer mode, only allow clicking when it is X's turn
    if (gameMode === 'ai' && !isXNext) return;
    
    makeMove(index, currentPlayer);
  };

  // Smart responsive computer move selection logic
  useEffect(() => {
    const isComputerTurn = gameMode === 'ai' && !isXNext && !winningPlayer && !isAiThinking;
    if (!isComputerTurn) return;

    setIsAiThinking(true);
    playSound('thinking');

    // Simulate standard thinking latency (between 400ms and 800ms) for enhanced realism
    const delay = setTimeout(() => {
      const computerMoveIndex = getComputerMove();
      if (computerMoveIndex !== -1) {
        makeMove(computerMoveIndex, 'O');
      }
      setIsAiThinking(false);
    }, 600);

    return () => clearTimeout(delay);
  }, [isXNext, gameMode, winningPlayer, history, currentStep]);

  // Comprehensive, smart heuristic and rule-based AI solver
  const getComputerMove = (): number => {
    const emptyIndices = board
      .map((cell, idx) => (cell === null ? idx : null))
      .filter((val): val is number => val !== null);

    if (emptyIndices.length === 0) return -1;

    // --- RULE 1: Immediate Win Opportunities ---
    // If computer can win in 1 single move, take it.
    for (const idx of emptyIndices) {
      const tempBoard = [...board];
      tempBoard[idx] = 'O';
      if (checkWinState(tempBoard)?.winner === 'O') {
        return idx;
      }
    }

    // --- RULE 2: Immediate Opponent Threat Blocks ---
    // If the human is 1 move away from completing a line, block them.
    for (const idx of emptyIndices) {
      const tempBoard = [...board];
      tempBoard[idx] = 'X';
      if (checkWinState(tempBoard)?.winner === 'X') {
        return idx;
      }
    }

    // --- RULE 3: Difficulty-based Strategic Placement ---
    if (difficulty === 'easy') {
      // Pick randomly
      return emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
    }

    if (difficulty === 'medium') {
      // 50% chance to play strategically, otherwise choose random
      if (Math.random() < 0.4) {
        return emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
      }
    }

    // --- HEURISTIC STRATEGIC CALCULATIONS (Hard or Medium high roll) ---
    // Prefer center coordinates on odd grids
    const centerIdx = Math.floor((gridSize * gridSize) / 2);
    if (gridSize % 2 !== 0 && board[centerIdx] === null) {
      return centerIdx;
    }

    // Prefer corners
    const corners: number[] = [];
    if (gridSize === 3) corners.push(0, 2, 6, 8);
    else if (gridSize === 4) corners.push(0, 3, 12, 15);
    else if (gridSize === 5) corners.push(0, 4, 20, 24);

    const emptyCorners = corners.filter(idx => board[idx] === null);
    if (emptyCorners.length > 0) {
      return emptyCorners[Math.floor(Math.random() * emptyCorners.length)];
    }

    // Weight empty cells by how many of our own markers are in those winning lines
    let bestScore = -1;
    let bestMoves: number[] = [];

    for (const idx of emptyIndices) {
      let score = 0;
      for (const combo of winningCombinations) {
        if (combo.includes(idx)) {
          const markers = combo.map(i => board[i]);
          const oCount = markers.filter(m => m === 'O').length;
          const xCount = markers.filter(m => m === 'X').length;

          if (xCount === 0) {
            // Path is open for Computer win
            score += oCount * 2 + 1;
          } else if (oCount === 0) {
            // Path is open for Player win, block value
            score += xCount + 1;
          }
        }
      }

      if (score > bestScore) {
        bestScore = score;
        bestMoves = [idx];
      } else if (score === bestScore) {
        bestMoves.push(idx);
      }
    }

    if (bestMoves.length > 0) {
      return bestMoves[Math.floor(Math.random() * bestMoves.length)];
    }

    // Fallback: fully random choice
    return emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
  };

  // Restart current round cleanly
  const handleRestart = () => {
    setHistory([Array(gridSize * gridSize).fill(null)]);
    setCurrentStep(0);
    setIsXNext(true);
    setWinningPlayer(null);
    setWinningLine(null);
    setIsAiThinking(false);
    playSound('reset');
  };

  // Resets scoreboard fully back to zero parameters
  const handleResetScores = () => {
    const cleared = {
      pvp: { x: 0, o: 0, ties: 0 },
      ai: { player: 0, computer: 0, ties: 0 },
      streak: 0,
    };
    saveScores(cleared);
    playSound('reset');
  };

  // Adjust Grid Size (3x3, 4x4, 5x5) and reset state
  const handleGridSizeChange = (size: GridSize) => {
    setGridSize(size);
    setHistory([Array(size * size).fill(null)]);
    setCurrentStep(0);
    setIsXNext(true);
    setWinningPlayer(null);
    setWinningLine(null);
    setIsAiThinking(false);
    playSound('reset');
  };

  // Toggle PvP / AI game modes cleanly
  const handleModeChange = (mode: GameMode) => {
    setGameMode(mode);
    setHistory([Array(gridSize * gridSize).fill(null)]);
    setCurrentStep(0);
    setIsXNext(true);
    setWinningPlayer(null);
    setWinningLine(null);
    setIsAiThinking(false);
    playSound('reset');
  };

  // Step backward in history (Undo)
  const handleUndo = () => {
    if (currentStep > 0) {
      // In AI mode, undoing a human move requires removing both the AI move and the human move (2 steps)
      let stepsToBacktrack = 1;
      if (gameMode === 'ai' && currentStep >= 2) {
        stepsToBacktrack = 2;
      }

      const prevStep = Math.max(0, currentStep - stepsToBacktrack);
      setCurrentStep(prevStep);
      setWinningPlayer(null);
      setWinningLine(null);
      
      // Compute whose turn it is next
      const nextBoard = history[prevStep];
      const xCount = nextBoard.filter(c => c === 'X').length;
      const oCount = nextBoard.filter(c => c === 'O').length;
      setIsXNext(xCount <= oCount);
      
      playSound('click');
    }
  };

  // Render metrics or streaks
  const activePvpScores = scores.pvp;
  const activeAiScores = scores.ai;
  const totalMatches = gameMode === 'pvp' 
    ? activePvpScores.x + activePvpScores.o + activePvpScores.ties
    : activeAiScores.player + activeAiScores.computer + activeAiScores.ties;

  const winPercentage = totalMatches > 0 
    ? Math.round(
        ((gameMode === 'pvp' ? activePvpScores.x : activeAiScores.player) / totalMatches) * 100
      ) 
    : 0;

  return (
    <div id="game-root" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start py-8 px-4 selection:bg-cyan-500/20 overflow-y-auto relative font-sans">
      
      {/* Immersive radial layout backdrop glows */}
      <div className="absolute top-[-20%] left-[-20%] w-[60%] h-[60%] rounded-full bg-cyan-500/5 blur-[140px] pointer-events-none" />
      <div className="absolute bottom-[-20%] right-[-20%] w-[60%] h-[60%] rounded-full bg-rose-500/5 blur-[140px] pointer-events-none" />

      <div className="w-full max-w-lg flex flex-col gap-5 relative z-10">
        
        {/* App Title Header Bar */}
        <header className="flex items-center justify-between pb-2 border-b border-slate-900">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-400 to-rose-400 flex items-center justify-center shadow-lg shadow-cyan-500/10">
              <span className="font-mono font-bold text-slate-950 text-lg">#</span>
            </div>
            <div>
              <h1 className="font-sans font-extrabold text-xl tracking-tight bg-gradient-to-r from-cyan-400 via-slate-100 to-rose-400 bg-clip-text text-transparent">
                Tic-Tac-Toe Arena
              </h1>
              <p className="text-[10px] font-mono tracking-wider text-slate-500 uppercase">Interactive Lab</p>
            </div>
          </div>
          
          {/* Sounds, Rules, and clear metrics keys */}
          <div className="flex items-center gap-2">
            <button
              id="rules-toggle-btn"
              onClick={() => setShowRules(!showRules)}
              className={`p-2 rounded-xl transition-all duration-200 border ${
                showRules 
                  ? 'bg-cyan-950/40 border-cyan-500/30 text-cyan-400' 
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
              title="How to Play"
            >
              <Info size={18} />
            </button>
            <button
              id="sound-toggle-btn"
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200 transition-colors duration-200"
              title={soundEnabled ? "Mute Sounds" : "Unmute Sounds"}
            >
              {soundEnabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
            </button>
            <button
              id="reset-scores-btn"
              onClick={handleResetScores}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-rose-400 transition-colors duration-200"
              title="Clear Saved Stats"
            >
              <Trash2 size={18} />
            </button>
          </div>
        </header>

        {/* Dynamic Instructional panel drawer */}
        <AnimatePresence>
          {showRules && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-4 text-xs text-slate-300 flex flex-col gap-2 shadow-lg">
                <h3 className="font-bold text-slate-100 flex items-center gap-1.5 text-sm">
                  <Sparkles size={14} className="text-cyan-400" /> Game Rules & Mechanics
                </h3>
                <p>
                  Get <span className="text-cyan-400 font-semibold">{gridSize}</span> identical markers in a single horizontal row, vertical column, or diagonal line to conquer the board.
                </p>
                <div className="grid grid-cols-3 gap-2 mt-1 pt-2 border-t border-slate-800/60 font-mono text-[10px] text-slate-400">
                  <div>• 3x3 Grid: 3-in-a-row</div>
                  <div>• 4x4 Grid: 4-in-a-row</div>
                  <div>• 5x5 Grid: 5-in-a-row</div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Setting Selector controls: Grid size and Game mode */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-3 bg-slate-900/30 backdrop-blur-sm border border-slate-900/80 rounded-2xl p-3">
          
          {/* Game Mode Selector */}
          <div className="flex flex-col gap-1.5">
            <span className="text-[10px] font-mono tracking-widest text-slate-500 uppercase flex items-center gap-1">
              <User size={10} /> Mode Selection
            </span>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                id="mode-ai-btn"
                onClick={() => handleModeChange('ai')}
                className={`py-2 px-3 rounded-xl font-sans font-medium text-xs flex items-center justify-center gap-1.5 transition-all duration-300 border cursor-pointer ${
                  gameMode === 'ai'
                    ? 'bg-cyan-500/10 border-cyan-500/40 text-cyan-400 shadow-[0_0_15px_rgba(34,211,238,0.05)]'
                    : 'bg-slate-900/50 border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Cpu size={14} /> Vs Computer
              </button>
              <button
                id="mode-pvp-btn"
                onClick={() => handleModeChange('pvp')}
                className={`py-2 px-3 rounded-xl font-sans font-medium text-xs flex items-center justify-center gap-1.5 transition-all duration-300 border cursor-pointer ${
                  gameMode === 'pvp'
                    ? 'bg-rose-500/10 border-rose-500/40 text-rose-400 shadow-[0_0_15px_rgba(251,113,133,0.05)]'
                    : 'bg-slate-900/50 border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <User size={14} /> Local PvP
              </button>
            </div>
          </div>

          {/* Grid Size Selection */}
          <div className="flex flex-col gap-1.5">
            <span className="text-[10px] font-mono tracking-widest text-slate-500 uppercase flex items-center gap-1">
              <Layers size={10} /> Grid Dimension
            </span>
            <div className="grid grid-cols-3 gap-1.5">
              {([3, 4, 5] as GridSize[]).map((size) => (
                <button
                  id={`grid-size-${size}`}
                  key={size}
                  onClick={() => handleGridSizeChange(size)}
                  className={`py-2 px-1 rounded-xl font-mono text-xs font-bold transition-all duration-300 border cursor-pointer ${
                    gridSize === size
                      ? 'bg-slate-100 border-slate-200 text-slate-950 shadow-lg'
                      : 'bg-slate-900/50 border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {size}x{size}
                </button>
              ))}
            </div>
          </div>

        </section>

        {/* AI Difficulty Selector panel - only visible when gameMode is 'ai' */}
        <AnimatePresence>
          {gameMode === 'ai' && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="flex flex-col gap-1.5 bg-slate-900/20 border border-slate-900/60 rounded-xl p-3">
                <span className="text-[10px] font-mono tracking-widest text-slate-500 uppercase flex items-center gap-1">
                  <Activity size={10} /> CPU Intelligence
                </span>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['easy', 'medium', 'hard'] as Difficulty[]).map((diff) => (
                    <button
                      id={`difficulty-${diff}`}
                      key={diff}
                      onClick={() => setDifficulty(diff)}
                      className={`py-1.5 rounded-lg text-[11px] font-sans font-semibold uppercase tracking-wider transition-all duration-300 border cursor-pointer ${
                        difficulty === diff
                          ? 'bg-cyan-500/15 border-cyan-500/50 text-cyan-300 shadow-[0_0_12px_rgba(34,211,238,0.1)]'
                          : 'bg-slate-900/30 border-transparent text-slate-500 hover:text-slate-300'
                      }`}
                    >
                      {diff}
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Game Status Announcement Indicator */}
        <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800/80 rounded-2xl p-4 text-center shadow-2xl relative overflow-hidden">
          <AnimatePresence mode="wait">
            {isAiThinking ? (
              <motion.div
                key="thinking"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="flex flex-col items-center gap-1.5"
              >
                <span className="text-xs font-mono tracking-widest text-cyan-400/70 animate-pulse uppercase">AI Processing Turn</span>
                <div className="flex items-center gap-1.5 mt-1.5">
                  <div className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </motion.div>
            ) : winningPlayer ? (
              winningPlayer === 'Draw' ? (
                <motion.div
                  key="draw"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="flex flex-col items-center gap-1"
                >
                  <span className="text-sm font-mono tracking-widest text-slate-400 uppercase">MATCH FINISHED</span>
                  <span className="text-xl font-extrabold text-slate-200 flex items-center gap-2">
                    Tied Game! <span className="text-lg">🤝</span>
                  </span>
                </motion.div>
              ) : (
                <motion.div
                  key="win"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="flex flex-col items-center gap-1"
                >
                  <span className="text-sm font-mono tracking-widest text-yellow-500/90 flex items-center gap-1 uppercase">
                    <Trophy size={14} className="text-yellow-400 animate-bounce" /> Victory Proclaimed
                  </span>
                  <span className={`text-2xl font-black flex items-center gap-2 ${
                    winningPlayer === 'X' 
                      ? 'text-cyan-400 drop-shadow-[0_0_15px_rgba(34,211,238,0.3)]' 
                      : 'text-rose-400 drop-shadow-[0_0_15px_rgba(251,113,133,0.3)]'
                  }`}>
                    {winningPlayer === 'X' ? <X size={26} className="stroke-[3.5px]" /> : <Circle size={22} className="stroke-[3.5px]" />}
                    {gameMode === 'ai' 
                      ? (winningPlayer === 'X' ? 'You Won!' : 'CPU Won!')
                      : `Player ${winningPlayer} Wins!`}
                  </span>
                </motion.div>
              )
            ) : (
              <motion.div
                key="turn"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center gap-1"
              >
                <span className="text-[10px] font-mono tracking-widest text-slate-500 uppercase">CURRENT ACTION</span>
                <span className={`text-base font-bold flex items-center gap-2.5 transition-all duration-300 ${
                  isXNext ? 'text-cyan-400' : 'text-rose-400'
                }`}>
                  {isXNext ? (
                    <>
                      <X size={18} className="stroke-[3px]" /> 
                      {gameMode === 'ai' ? 'Your Move (Player X)' : "Player X's Turn"}
                    </>
                  ) : (
                    <>
                      <Circle size={15} className="stroke-[3px]" /> 
                      {gameMode === 'ai' ? "Computer (Player O)" : "Player O's Turn"}
                    </>
                  )}
                </span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Dynamic Multi-grid Game Canvas */}
        <main className="aspect-square w-full bg-slate-900/30 backdrop-blur-md border border-slate-900/80 rounded-3xl p-4 shadow-2xl relative">
          <div 
            className="grid h-full w-full gap-2.5"
            style={{
              gridTemplateColumns: `repeat(${gridSize}, minmax(0, 1fr))`,
              gridTemplateRows: `repeat(${gridSize}, minmax(0, 1fr))`
            }}
          >
            {board.map((cell, index) => {
              const isWinningCell = winningLine?.includes(index);
              const isHoverable = !cell && !winningPlayer && !isAiThinking && (gameMode !== 'ai' || isXNext);

              // Responsive scaling sizes depending on grid dimension count
              const markerSize = gridSize === 3 ? 46 : gridSize === 4 ? 34 : 26;
              const circleSize = gridSize === 3 ? 38 : gridSize === 4 ? 28 : 20;

              return (
                <button
                  id={`cell-${index}`}
                  key={index}
                  onClick={() => handleCellClick(index)}
                  disabled={!isHoverable}
                  className={`
                    relative group flex items-center justify-center rounded-2xl transition-all duration-300
                    border outline-none focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500/50
                    ${cell ? 'bg-slate-950/80 border-slate-900/60 shadow-inner' : 'bg-slate-900/30 border-slate-900/30'}
                    ${isHoverable ? 'hover:bg-slate-900/80 hover:border-slate-700/50 active:scale-[0.96] cursor-pointer' : ''}
                    ${isWinningCell ? 'bg-slate-900/90 border-yellow-500/80 ring-4 ring-yellow-500/15' : ''}
                  `}
                >
                  <AnimatePresence mode="popLayout">
                    {cell ? (
                      <motion.div
                        initial={{ scale: 0, rotate: -45 }}
                        animate={{ scale: 1, rotate: 0 }}
                        exit={{ scale: 0 }}
                        transition={{ type: "spring", stiffness: 220, damping: 16 }}
                        className="flex items-center justify-center w-full h-full"
                      >
                        {cell === 'X' ? (
                          <X 
                            size={markerSize} 
                            className={`stroke-[3.5px] transition-all duration-300 ${
                              isWinningCell 
                                ? 'text-yellow-400 drop-shadow-[0_0_18px_rgba(234,179,8,0.75)] animate-pulse' 
                                : 'text-cyan-400 drop-shadow-[0_0_12px_rgba(34,211,238,0.4)]'
                            }`} 
                          />
                        ) : (
                          <Circle 
                            size={circleSize} 
                            className={`stroke-[3.5px] transition-all duration-300 ${
                              isWinningCell 
                                ? 'text-yellow-400 drop-shadow-[0_0_18px_rgba(234,179,8,0.75)] animate-pulse' 
                                : 'text-rose-400 drop-shadow-[0_0_12px_rgba(251,113,133,0.4)]'
                            }`} 
                          />
                        )}
                      </motion.div>
                    ) : (
                      // Interactive hovering indicator hints
                      isHoverable && (
                        <div className="opacity-0 group-hover:opacity-15 transition-opacity duration-200">
                          {isXNext ? (
                            <X size={markerSize} className="stroke-[2px] text-cyan-400" />
                          ) : (
                            <Circle size={circleSize} className="stroke-[2px] text-rose-400" />
                          )}
                        </div>
                      )
                    )}
                  </AnimatePresence>
                </button>
              );
            })}
          </div>
        </main>

        {/* History / Navigation & Clear Control buttons */}
        <div className="flex items-center justify-between gap-3">
          
          {/* Time Travel / Undo Button */}
          <button
            id="undo-btn"
            onClick={handleUndo}
            disabled={currentStep === 0 || isAiThinking}
            className={`flex items-center justify-center gap-2 px-4 py-3 rounded-2xl border text-xs font-semibold tracking-wide transition-all duration-200 cursor-pointer ${
              currentStep === 0 || isAiThinking
                ? 'opacity-30 border-slate-900 text-slate-600 cursor-not-allowed'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-slate-100 hover:border-slate-700 active:scale-[0.97]'
            }`}
          >
            <Undo2 size={14} /> Undo Move
          </button>

          {/* Quick Clear Restart Button */}
          <button
            id="restart-game-btn"
            onClick={handleRestart}
            className="flex-1 relative flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-slate-900 to-slate-900 hover:from-slate-850 hover:to-slate-850 border border-slate-800 hover:border-slate-700 rounded-2xl shadow-xl transition-all duration-300 overflow-hidden cursor-pointer active:scale-[0.98]"
          >
            <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-cyan-500/5 to-rose-500/5 opacity-0 hover:opacity-100 transition-opacity duration-300" />
            <RotateCcw size={14} className="text-slate-300" />
            <span className="font-sans font-semibold text-xs tracking-wide text-slate-200">
              Restart Board
            </span>
          </button>

        </div>

        {/* Scoreboard Metrics panel */}
        <section className="bg-slate-900/50 backdrop-blur-sm border border-slate-800/60 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
          
          {/* Header metadata label */}
          <div className="flex items-center justify-between pb-2 border-b border-slate-800/60">
            <span className="text-[10px] font-mono tracking-widest text-slate-400 uppercase">
              {gameMode === 'ai' ? 'Vs Computer Statistics' : 'Local Multiplayer Stats'}
            </span>
            {gameMode === 'ai' && scores.streak > 0 && (
              <span className="text-[10px] font-mono tracking-widest text-amber-400 flex items-center gap-1 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
                <Flame size={10} className="fill-amber-400" /> {scores.streak} streak
              </span>
            )}
          </div>

          <div className="grid grid-cols-3 gap-3 text-center">
            {/* Player 1 Metric */}
            <div className="flex flex-col items-center">
              <span className="text-[10px] font-mono tracking-widest text-cyan-400 uppercase">
                {gameMode === 'ai' ? 'PLAYER (X)' : 'PLAYER X'}
              </span>
              <span className="text-2xl font-black font-mono text-cyan-400 mt-1">
                {gameMode === 'ai' ? scores.ai.player : scores.pvp.x}
              </span>
            </div>

            {/* Tie Metric */}
            <div className="flex flex-col items-center border-x border-slate-800/80">
              <span className="text-[10px] font-mono tracking-widest text-slate-400 uppercase">
                DRAWS
              </span>
              <span className="text-2xl font-black font-mono text-slate-200 mt-1">
                {gameMode === 'ai' ? scores.ai.ties : scores.pvp.ties}
              </span>
            </div>

            {/* Player 2 Metric */}
            <div className="flex flex-col items-center">
              <span className="text-[10px] font-mono tracking-widest text-rose-400 uppercase">
                {gameMode === 'ai' ? 'COMPUTER (O)' : 'PLAYER O'}
              </span>
              <span className="text-2xl font-black font-mono text-rose-400 mt-1">
                {gameMode === 'ai' ? scores.ai.computer : scores.pvp.o}
              </span>
            </div>
          </div>

          {/* Dynamic analytics dashboard bar */}
          {totalMatches > 0 && (
            <div className="pt-2 border-t border-slate-800/40 flex flex-col gap-1.5">
              <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                <span>Win Rate Percentage</span>
                <span className="text-cyan-400 font-bold">{winPercentage}%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden flex">
                <div 
                  className="bg-cyan-500 h-full transition-all duration-500" 
                  style={{ width: `${winPercentage}%` }} 
                />
                <div 
                  className="bg-rose-500 h-full transition-all duration-500" 
                  style={{ 
                    width: `${totalMatches > 0 ? ((gameMode === 'ai' ? scores.ai.computer : scores.pvp.o) / totalMatches) * 100 : 0}%` 
                  }} 
                />
              </div>
            </div>
          )}

        </section>

      </div>

      {/* Humble Footer Credit line */}
      <footer className="mt-8 text-[9px] font-mono tracking-[0.25em] text-slate-600 uppercase text-center relative z-10">
        Tic-Tac-Toe Arena • Built for Google AI Studio
      </footer>

    </div>
  );
}
