import express, { Request, Response } from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialized Gemini client for security & robustness
let aiClient: GoogleGenAI | null = null;

function getAI(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

const ZODIAC_SIGNS = [
  "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
  "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"
];

// Fallback high-fidelity content when Gemini API is not loaded or fails
const FALLBACK_TRANSITS: Record<string, any> = {
  "Love": {
    transitText: "Venus aligns gracefully with your ruling house today, casting an iridescent glow over your interpersonal connections. The celestial waters run warm and deep, encouraging raw emotional vulnerability. You may feel a magnetic pull toward deep, soul-stirring conversations. Trust the cosmic current; it is guiding you exactly where you need to heal.",
    embrace: [
      "Expressing your deepest unspoken feelings to a loved one",
      "Engaging in self-love rituals (warm baths, meditation)",
      "Opening your heart to unexpected cosmic encounters"
    ],
    evade: [
      "Projecting past relationship fears onto current bonds",
      "Suppressing your emotional truth for superficial harmony",
      "Making hasty commitments under an impulsive moon"
    ],
    vitals: { love: 95, career: 75, wealth: 80, energy: 88 }
  },
  "Destiny/Career": {
    transitText: "Saturn and Mercury stand in a powerful conjunction, bringing structure, clarity, and exceptional drive to your professional ambitions. The stars favor strategic planning and execution. The noise of the material world fades, revealing the precise step-by-step path toward your soul's true calling. Prepare to lay down foundational blocks today.",
    embrace: [
      "Refining your long-term vision board and actionable plans",
      "Initiating critical conversations with mentors or authority figures",
      "Setting strict, healthy boundaries around your work hours"
    ],
    evade: [
      "Allowing imposter syndrome to paralyze your creative drive",
      "Signing complex business agreements without careful review",
      "Over-committing to minor tasks at the cost of your main objective"
    ],
    vitals: { love: 72, career: 94, wealth: 85, energy: 80 }
  },
  "Wealth": {
    transitText: "Jupiter’s abundant shadow sweeps across your house of material prosperity today, sparking positive financial realizations. This is not a time of reckless gambling, but of alignment with the energy of abundance. A celestial doorway is opening for intuitive investments and recognizing your true worth. Wealth flows where appreciation grows.",
    embrace: [
      "Auditing your finances with a grateful and abundant mindset",
      "Investing in high-quality knowledge, books, or spiritual tools",
      "Decluttering your workspace to let fresh abundance circulate"
    ],
    evade: [
      "Impulsive spending triggered by emotional fluctuations",
      "Doubting your capability to build long-term generational wealth",
      "Ignoring small, leaks in your budget or automated subscriptions"
    ],
    vitals: { love: 78, career: 85, wealth: 96, energy: 75 }
  },
  "Spiritual Growth": {
    transitText: "Neptune casts a highly intuitive veil over your subconscious today, merging your earthly self with your infinite starry spirit. Dreams are vivid, synchronicities are loud, and your third eye is vibrating with potential. Step back from the material grind; the cosmos calls you to enter the silent temple of inner contemplation.",
    embrace: [
      "Recording and decoding the mysterious messages in your dreams",
      "Spending quiet time in nature or dedicated silent meditation",
      "Sensing and clearing out stale energy fields from your aura"
    ],
    evade: [
      "Over-analyzing mystical experiences with sterile logic",
      "Absorbing other people's heavy emotional currents",
      "Forcing active outcomes when the universe counsels surrender"
    ],
    vitals: { love: 85, career: 70, wealth: 72, energy: 95 }
  }
};

function getSimulatedOracleResponse(question: string, profile: any): string {
  const q = question.toLowerCase();
  const sun = profile.sunSign;
  const moon = profile.moonSign;
  const asc = profile.ascendantSign;
  const name = profile.name;

  if (q.includes("love") || q.includes("relationship") || q.includes("romance") || q.includes("partner") || q.includes("marry") || q.includes("attract")) {
    return `Ah, dear ${name}, you ask of the sacred threads of the heart. With your Sun in ${sun}, your soul's flame seeks a partner who respects your core essence. However, it is your Moon in ${moon} that governs your emotional sanctuaries. Today, the planetary tides whisper of vulnerability. The Ascendant in ${asc} suggests that you present a strong, magnetic exterior, but inside, you long for profound communion. Trust that Venus is weaving a quiet tapestry of connection in your house of intimacy. Open your heart, but protect your peace.`;
  }
  if (q.includes("career") || q.includes("job") || q.includes("destiny") || q.includes("work") || q.includes("success") || q.includes("future") || q.includes("business")) {
    return `Greetings, ambitious seeker. The alignments for your career and destiny are shifting. Saturn, the cosmic clockmaker, is testing the foundations laid by your ${sun} Sun. Since your Ascendant is in ${asc}, you approach the world with natural authority and purpose, which serves you well in professional arenas. Today, the stars advise you to focus on the long-term blueprint rather than chasing ephemeral victories. Your Moon in ${moon} reminds you that true success must also bring inner emotional peace. Do not trade your soul for a crown.`;
  }
  if (q.includes("wealth") || q.includes("money") || q.includes("finance") || q.includes("rich") || q.includes("invest") || q.includes("lucky") || q.includes("luck")) {
    return `A central query of earthly existence, ${name}. Jupiter, the planet of expansion, is currently reflecting light into your house of material resources. With your Sun in ${sun}, your financial path is marked by a unique drive. Your Ascendant in ${asc} acts as a magnet for material opportunities when you project confidence. However, remember that wealth is a state of flow, not hoarding. Your Moon in ${moon} warns against buying comforts to fill temporary spiritual voids. Ground yourself, align your budgets, and let the gold of the stars manifest in your earthly hands.`;
  }
  if (q.includes("energy") || q.includes("tired") || q.includes("health") || q.includes("vibe") || q.includes("feeling") || q.includes("today")) {
    return `I sense a shift in your energetic aura, ${name}. The current solar transits are challenging your ${sun} Sun, leading to a temporary draining of physical reserve. This is a gentle command from the universe to surrender and rest. Your Moon in ${moon} governs your subconscious and nervous system — it is pleading for quietude, perhaps a digital detox or a walk under the starry sky. Let your ${asc} Rising energy recharge in the shadows. Your energy will return tenfold once the Moon completes its transition.`;
  }
  // Default mystical response
  return `Dear ${name}, the stars listen intently to your query. The combination of your Sun in ${sun}, Moon in ${moon}, and Ascendant in ${asc} forms a rare and exquisite tapestry of human experience. The current transits indicate a period of profound internal alchemy. Whatever decision stands before you, trust the intuitive whispers of your ${moon} Moon, execute with the courage of your ${sun} Sun, and step into the world with the majestic grace of your ${asc} Ascendant. The universe does not make mistakes; you are exactly where you are meant to be.`;
}

// 1. Personalized Celestial Transit Summary Endpoint
app.post("/api/transit", async (req: Request, res: Response) => {
  try {
    const { profile } = req.body;
    if (!profile) {
      return res.status(400).json({ error: "Profile is required" });
    }

    const category = profile.guidanceType || "Spiritual Growth";
    const ai = getAI();

    if (!ai) {
      // Use premium fallback
      const baseFallback = FALLBACK_TRANSITS[category] || FALLBACK_TRANSITS["Spiritual Growth"];
      // Personalize slightly
      const transitText = `${baseFallback.transitText} With your Sun in ${profile.sunSign}, your path is illuminated with bright potential. Your Moon in ${profile.moonSign} grants you exceptional emotional resilience, while your ${profile.ascendantSign} Ascendant ensures your magnetic aura shines gracefully in any space today.`;
      return res.json({
        ...baseFallback,
        transitText,
        isSimulated: true
      });
    }

    // Call Gemini API for high-fidelity dynamic transit summary
    const prompt = `Generate a personalized premium daily transit reading, actions, and energy levels for an astrology app.
User Profile:
- Name: ${profile.name}
- Sun Sign: ${profile.sunSign}
- Moon Sign: ${profile.moonSign}
- Ascendant (Rising): ${profile.ascendantSign}
- Birth date/time/place: ${profile.birthDate} at ${profile.birthTime} in ${profile.birthPlace}
- Focus Area today: ${profile.guidanceType}

Generate:
1. transitText: A beautifully formatted, deeply mystical daily transit summary paragraph (3-4 sentences) explicitly referencing their Sun, Moon, and Ascendant. Keep it poetic, luxurious, and deeply inspiring.
2. embrace: An array of 3 actionable, highly celestial things to do today.
3. evade: An array of 3 specific warnings or things to avoid/evade today.
4. vitals: An object with integer percentages (0-100) for love, career, wealth, and energy, tailored to their chart.

Return strictly in JSON format matching the schema.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are Aura, a world-class premium royal astrologer and spiritual oracle. You communicate with absolute elegance, deep astrological knowledge, and exquisite poise. Always output flawless JSON matching the requested schema.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            transitText: { type: Type.STRING },
            embrace: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            evade: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            vitals: {
              type: Type.OBJECT,
              properties: {
                love: { type: Type.INTEGER },
                career: { type: Type.INTEGER },
                wealth: { type: Type.INTEGER },
                energy: { type: Type.INTEGER }
              },
              required: ["love", "career", "wealth", "energy"]
            }
          },
          required: ["transitText", "embrace", "evade", "vitals"]
        }
      }
    });

    const data = JSON.parse(response.text?.trim() || "{}");
    return res.json({ ...data, isSimulated: false });
  } catch (error: any) {
    console.error("Gemini Transit API error:", error);
    // Fallback on error
    const category = req.body.profile?.guidanceType || "Spiritual Growth";
    const baseFallback = FALLBACK_TRANSITS[category] || FALLBACK_TRANSITS["Spiritual Growth"];
    return res.json({
      ...baseFallback,
      transitText: `${baseFallback.transitText} (The universe streams smoothly in fallback mode. Your Sun is in ${req.body.profile?.sunSign || "Aries"}.)`,
      isSimulated: true
    });
  }
});

// 4. Personalized Life Destiny & Forecasts Endpoint
app.post("/api/life-forecast", async (req: Request, res: Response) => {
  const { profile } = req.body || {};
  try {
    if (!profile) {
      return res.status(400).json({ error: "Profile is required" });
    }

    const ai = getAI();
    const sun = profile.sunSign || "Aries";
    const moon = profile.moonSign || "Taurus";
    const asc = profile.ascendantSign || "Gemini";
    const name = profile.name || "Seeker";

    if (!ai) {
      // High-fidelity fallback simulated life forecast
      return res.json({
        marriage: {
          title: "Union & Sacred Contracts",
          reading: `With your Sun in **${sun}** and Moon in **${moon}**, your marriage path is a beautiful, evolving dance of stability and spark. You seek a partner who can stimulate your intellect while respecting your private sanctuary. Your **${asc}** rising sign indicates that you initialy attract dramatic or expressive partners, but long-term happiness lies with someone who anchors your busy thoughts. The stars suggest a key union window occurs during a major Jupiter transit through your 7th house, promising a relationship built on absolute mutual respect and shared dreams.`,
          vibe: "Boundless Depth"
        },
        children: {
          title: "Legacy & Creative Lineage",
          reading: `Your chart carries a nurturing, deeply creative lineage. Whether through children or high-impact artistic endeavors, your legacy is governed by the emotional water of your **${moon}** moon. You are meant to break generational cycles, offering future minds a canvas of absolute security mixed with playful curiosity. The planetary alignment promises a vibrant, chatter-filled home, though you must guard against overprotecting those you love.`,
          vibe: "Cycle Breaker"
        },
        money: {
          title: "Material Prosperity & Abundance",
          reading: `Money is a flow state for you, ${name}. Your **${sun}** sun drives your primary earning power, giving you an innate knack for recognizing valuable opportunities before others do. However, your **${moon}** warns against emotional spending—using luxury items to heal temporary fatigue. Real wealth arrives when you invest in tangible assets (like land or long-term tech indices) and align your career with genuine spiritual purpose.`,
          vibe: "Golden Manifestation"
        },
        goodThing: {
          title: "The Golden Blessing",
          reading: `Your supreme celestial superpower is your extraordinary emotional resilience and intuitive radar. With **${moon}** anchoring your sub-conscious and **${asc}** directing your public presentation, you can read any room instantly. You possess a rare magnetism that turns casual acquaintances into lifelong allies. Leverage this gift—your net worth is directly tied to your stellar networks.`,
          vibe: "Uncanny Intuition"
        },
        badThing: {
          title: "The Saturnian Trap",
          reading: `Your cosmic pitfall is a tendency to retreat into absolute mental isolation when overwhelmed. You over-analyze micro-interactions until you create scenarios that don't exist, pushing away support when you need it most. Saturn warns you: do not let your fear of failure prevent you from starting. Silence your inner critic and allow yourself to make beautiful mistakes.`,
          vibe: "Analysis Paralysis"
        },
        isSimulated: true
      });
    }

    const prompt = `Generate a personalized Astrological Life Forecast/Destiny reading for a user.
User Birth Profile:
- Name: ${name}
- Sun Sign: ${sun}
- Moon Sign: ${moon}
- Ascendant Sign: ${asc}
- Birth Details: ${profile.birthDate} at ${profile.birthTime} in ${profile.birthPlace}

Provide deeply personal, incredibly stylish, relatable, and witty readings for each of these 5 categories, combining real astrology rules with Co-Star/The Pattern style psychological depth:
1. marriage: Forecast on marriage, partnership dynamics, ideal match archetype, and timing indicators.
2. children: Forecast on children, parenting style, lineage, and creative child-like energy.
3. money: Forecast on career prosperity, money-making habits, and wealth accumulation potential.
4. goodThing: The user's ultimate celestial blessing/strength based on their signs.
5. badThing: The user's primary cosmic warning/shadow/pitfall they must evade.

Each section MUST contain:
- title: A beautifully formatted, poetic title (e.g., "The Sacred Contract", "The Saturnian Warning").
- reading: A detailed, deeply personalized paragraph (3-4 sentences) that weaves their specific signs together into a breathtaking, witty, and deeply authentic life prophecy.
- vibe: A short 2-3 word poetic description of the cosmic vibe (e.g., "Shattering Cycles", "Magnetic Abundance").

Return strictly in JSON format matching the schema.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are Aura, a witty, profoundly knowledgeable royal astrologer who crafts stunningly accurate life forecasts with a combination of elite astrological mastery and relatable, modern social-media-friendly psychology. Always output flawless JSON matching the requested schema.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            marriage: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                reading: { type: Type.STRING },
                vibe: { type: Type.STRING }
              },
              required: ["title", "reading", "vibe"]
            },
            children: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                reading: { type: Type.STRING },
                vibe: { type: Type.STRING }
              },
              required: ["title", "reading", "vibe"]
            },
            money: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                reading: { type: Type.STRING },
                vibe: { type: Type.STRING }
              },
              required: ["title", "reading", "vibe"]
            },
            goodThing: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                reading: { type: Type.STRING },
                vibe: { type: Type.STRING }
              },
              required: ["title", "reading", "vibe"]
            },
            badThing: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                reading: { type: Type.STRING },
                vibe: { type: Type.STRING }
              },
              required: ["title", "reading", "vibe"]
            }
          },
          required: ["marriage", "children", "money", "goodThing", "badThing"]
        }
      }
    });

    const data = JSON.parse(response.text?.trim() || "{}");
    return res.json({ ...data, isSimulated: false });
  } catch (error: any) {
    console.error("Gemini Life Forecast API error:", error);
    return res.json({
      marriage: {
        title: "Sacred Union",
        reading: `Your relationship map is highly dynamic. With Sun in ${profile.sunSign || "Aries"}, you require passion and intellectual thrill. Long term marriage succeeds when communication is completely transparent.`,
        vibe: "Iridescent Flame"
      },
      children: {
        title: "Legacy & Nurturing",
        reading: "You carry a cycle-breaking lineage. As a guide, you will offer future generations both unconditional emotional depth and unlimited creative room.",
        vibe: "Sanctuary Guardian"
      },
      money: {
        title: "Material Currents",
        reading: "Abundance flows naturally when you align work with your core principles. Avoid impulsive status purchases; let your investments mature in silence.",
        vibe: "Steady Growth"
      },
      goodThing: {
        title: "The Golden Path",
        reading: "Your supreme strength is absolute authenticity. When you speak your truth without fear, the universe bends to create unexpected pathways of success.",
        vibe: "Electric Clarity"
      },
      badThing: {
        title: "The Shadow Warning",
        reading: "Do not let self-imposed doubt freeze your creative expressions. Perfection is an illusion that delays your most beautiful life breakthroughs.",
        vibe: "The Frozen Gate"
      },
      isSimulated: true
    });
  }
});

// 3. Cosmic Compatibility (Synastry) Endpoint
app.post("/api/compatibility", async (req: Request, res: Response) => {
  const { profile, friendName, friendSunSign } = req.body || {};
  try {
    if (!profile || !friendName || !friendSunSign) {
      return res.status(400).json({ error: "Profile, friend name, and friend sign are required" });
    }

    const ai = getAI();
    const userSun = profile.sunSign || "Aries";
    const userMoon = profile.moonSign || "Taurus";
    const userAsc = profile.ascendantSign || "Gemini";

    if (!ai) {
      // High-fidelity fallback simulated matching
      const scores = {
        matchPercentage: Math.floor(Math.random() * 25) + 70, // 70 to 94
        communication: Math.floor(Math.random() * 30) + 65,
        chemistry: Math.floor(Math.random() * 30) + 65,
        destiny: Math.floor(Math.random() * 30) + 65
      };

      const fallbackText = `The connection between **${profile.name}** (Sun in ${userSun}, Moon in ${userMoon}) and **${friendName}** (Sun in ${friendSunSign}) vibrates with rich celestial frequency. You both share a profound, complex psychic bridge. While your ${userSun} nature offers stability, their ${friendSunSign} qualities spark intense curiosity and spontaneous fire. There is a deep, unspoken dynamic where you easily finish each other's sentences, though Saturn warns you to align on boundaries before committing to joint ventures. It is a highly creative, slightly dramatic partnership that looks incredibly photogenic but requires genuine grounding.`;

      return res.json({
        matchPercentage: scores.matchPercentage,
        communicationScore: scores.communication,
        chemistryScore: scores.chemistry,
        destinyScore: scores.destiny,
        compatibilitySummary: fallbackText,
        sharedMantra: "Speak your truth with grace, but don't over-analyze the silence.",
        isSimulated: true
      });
    }

    const prompt = `Calculate the astrological compatibility (synastry) for a social-media-styled astrology app.
User Details:
- Name: ${profile.name}
- Sun Sign: ${userSun}
- Moon Sign: ${userMoon}
- Ascendant Sign: ${userAsc}

Friend/Partner Details:
- Name: ${friendName}
- Sun Sign: ${friendSunSign}

Generate:
1. matchPercentage: An overall integer compatibility percentage (0-100) based on real astrology synastry rules.
2. communicationScore: An integer communication score (0-100).
3. chemistryScore: An integer chemistry score (0-100).
4. destinyScore: An integer destiny/alignment score (0-100).
5. compatibilitySummary: A witty, deeply insightful, Co-Star or The Pattern styled reading (3-5 sentences) about how their energies mix. Use a combination of psychological depth and social-media-friendly wit (e.g. funny remarks on how they interact, their cosmic traps, and why they get along).
6. sharedMantra: A poetic, 1-sentence funny or profound shared advice mantra (e.g. "Order takeout together but never discuss who pays the bill.").

Return strictly in JSON format matching the schema.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are Aura, a world-class trendy social-media astrologer who combines profound planetary alignments with witty, relatable, and sometimes brutally honest cosmic insights. Always output flawless JSON matching the requested schema.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            matchPercentage: { type: Type.INTEGER },
            communicationScore: { type: Type.INTEGER },
            chemistryScore: { type: Type.INTEGER },
            destinyScore: { type: Type.INTEGER },
            compatibilitySummary: { type: Type.STRING },
            sharedMantra: { type: Type.STRING }
          },
          required: ["matchPercentage", "communicationScore", "chemistryScore", "destinyScore", "compatibilitySummary", "sharedMantra"]
        }
      }
    });

    const data = JSON.parse(response.text?.trim() || "{}");
    return res.json({ ...data, isSimulated: false });
  } catch (error: any) {
    console.error("Gemini Compatibility API error:", error);
    return res.json({
      matchPercentage: 83,
      communicationScore: 88,
      chemistryScore: 78,
      destinyScore: 85,
      compatibilitySummary: `A magnetic and high-vibe link. ${profile.name}'s Sun in ${profile.sunSign || "Aries"} and ${friendName}'s Sun in ${friendSunSign} form a highly dynamic combination. You share a beautiful alignment in conversational speed, though sometimes you clash over who directs the group chat.`,
      sharedMantra: "Listen more, text with fewer exclamation marks.",
      isSimulated: true
    });
  }
});

// 2. Astrological Oracle Chat Endpoint
app.post("/api/chat", async (req: Request, res: Response) => {
  try {
    const { message, history, profile } = req.body;
    if (!message || !profile) {
      return res.status(400).json({ error: "Message and profile are required" });
    }

    const ai = getAI();

    if (!ai) {
      // Return high-quality local simulated reading
      const simulatedResponse = getSimulatedOracleResponse(message, profile);
      return res.json({ text: simulatedResponse, isSimulated: true });
    }

    // Prepare system instructions incorporating the user's birth chart
    const systemInstruction = `You are Aura, the celestial AI Oracle of the premium AuraAstrology platform. 
The user you are guiding is named ${profile.name}.
Their birth chart consists of:
- Sun Sign: ${profile.sunSign}
- Moon Sign: ${profile.moonSign}
- Ascendant Sign: ${profile.ascendantSign}
- Born on ${profile.birthDate} at ${profile.birthTime} in ${profile.birthPlace}.
- Their primary spiritual quest today is: ${profile.guidanceType}.

Your tone must be highly mystical, poetic, deeply personalized, comforting, and luxurious. Never break character. Never state that you are an AI or program. Speak of planetary movements, houses, alignments, and aspects. 
Always tailor your advice to their specific Sun, Moon, and Ascendant combination. Format your replies beautifully in clean Markdown with soft poetic spacing. Keep answers elegant but substantive (about 2-3 paragraphs).`;

    // Map history into Gemini's required format
    const geminiHistory = (history || []).map((item: any) => ({
      role: item.role === "user" ? "user" : "model",
      parts: [{ text: item.text }]
    }));

    const chat = ai.chats.create({
      model: "gemini-3.5-flash",
      config: {
        systemInstruction,
        temperature: 0.8,
      },
      history: geminiHistory
    });

    const response = await chat.sendMessage({ message });
    return res.json({ text: response.text, isSimulated: false });
  } catch (error: any) {
    console.error("Gemini Chat API error:", error);
    // Dynamic simulated response as fallback
    const simulatedResponse = getSimulatedOracleResponse(req.body.message, req.body.profile);
    return res.json({
      text: `${simulatedResponse}\n\n*(A cosmic breeze temporarily disconnects direct transit telemetry. Standard offline oracle matrix active.)*`,
      isSimulated: true
    });
  }
});

// Serve frontend client via Vite or Static Files
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`AuraAstrology Server running on port ${PORT}`);
  });
}

startServer();
