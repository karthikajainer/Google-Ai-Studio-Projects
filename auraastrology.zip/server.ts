import express, { Request, Response } from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";
import { TRANSLATIONS } from "./src/translations";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialized Gemini client for security & robustness
let aiClient: GoogleGenAI | null = null;

function getAI(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

const ZODIAC_SIGNS = [
  "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
  "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"
];

// Fallback high-fidelity content when Gemini API is not loaded or fails
const FALLBACK_TRANSITS: Record<string, any> = {
  "Love": {
    transitText: "Venus aligns gracefully with your ruling house today, casting an iridescent glow over your interpersonal connections. The celestial waters run warm and deep, encouraging raw emotional vulnerability. You may feel a magnetic pull toward deep, soul-stirring conversations. Trust the cosmic current; it is guiding you exactly where you need to heal.",
    embrace: [
      "Expressing your deepest unspoken feelings to a loved one",
      "Engaging in self-love rituals (warm baths, meditation)",
      "Opening your heart to unexpected cosmic encounters"
    ],
    evade: [
      "Projecting past relationship fears onto current bonds",
      "Suppressing your emotional truth for superficial harmony",
      "Making hasty commitments under an impulsive moon"
    ],
    vitals: { love: 95, career: 75, wealth: 80, energy: 88 }
  },
  "Destiny/Career": {
    transitText: "Saturn and Mercury stand in a powerful conjunction, bringing structure, clarity, and exceptional drive to your professional ambitions. The stars favor strategic planning and execution. The noise of the material world fades, revealing the precise step-by-step path toward your soul's true calling. Prepare to lay down foundational blocks today.",
    embrace: [
      "Refining your long-term vision board and actionable plans",
      "Initiating critical conversations with mentors or authority figures",
      "Setting strict, healthy boundaries around your work hours"
    ],
    evade: [
      "Allowing imposter syndrome to paralyze your creative drive",
      "Signing complex business agreements without careful review",
      "Over-committing to minor tasks at the cost of your main objective"
    ],
    vitals: { love: 72, career: 94, wealth: 85, energy: 80 }
  },
  "Wealth": {
    transitText: "Jupiter’s abundant shadow sweeps across your house of material prosperity today, sparking positive financial realizations. This is not a time of reckless gambling, but of alignment with the energy of abundance. A celestial doorway is opening for intuitive investments and recognizing your true worth. Wealth flows where appreciation grows.",
    embrace: [
      "Auditing your finances with a grateful and abundant mindset",
      "Investing in high-quality knowledge, books, or spiritual tools",
      "Decluttering your workspace to let fresh abundance circulate"
    ],
    evade: [
      "Impulsive spending triggered by emotional fluctuations",
      "Doubting your capability to build long-term generational wealth",
      "Ignoring small, leaks in your budget or automated subscriptions"
    ],
    vitals: { love: 78, career: 85, wealth: 96, energy: 75 }
  },
  "Spiritual Growth": {
    transitText: "Neptune casts a highly intuitive veil over your subconscious today, merging your earthly self with your infinite starry spirit. Dreams are vivid, synchronicities are loud, and your third eye is vibrating with potential. Step back from the material grind; the cosmos calls you to enter the silent temple of inner contemplation.",
    embrace: [
      "Recording and decoding the mysterious messages in your dreams",
      "Spending quiet time in nature or dedicated silent meditation",
      "Sensing and clearing out stale energy fields from your aura"
    ],
    evade: [
      "Over-analyzing mystical experiences with sterile logic",
      "Absorbing other people's heavy emotional currents",
      "Forcing active outcomes when the universe counsels surrender"
    ],
    vitals: { love: 85, career: 70, wealth: 72, energy: 95 }
  }
};

function getSimulatedOracleResponse(question: string, profile: any): string {
  const q = question.toLowerCase();
  const sun = profile.sunSign || "Aries";
  const moon = profile.moonSign || "Taurus";
  const asc = profile.ascendantSign || "Gemini";
  const name = profile.name || "Seeker";
  const lang = profile.language || "English";

  const responses: Record<string, { love: string; career: string; wealth: string; energy: string; fallback: string }> = {
    English: {
      love: `Ah, dear **${name}**, you ask of the sacred threads of the heart. With your Sun in **${sun}**, your soul's flame seeks a partner who respects your core essence. However, it is your Moon in **${moon}** that governs your emotional sanctuaries. Today, the planetary tides whisper of vulnerability. The Ascendant in **${asc}** suggests that you present a strong, magnetic exterior, but inside, you long for profound communion. Trust that Venus is weaving a quiet tapestry of connection in your house of intimacy. Open your heart, but protect your peace.`,
      career: `Greetings, ambitious seeker. The alignments for your career and destiny are shifting. Saturn, the cosmic clockmaker, is testing the foundations laid by your **${sun}** Sun. Since your Ascendant is in **${asc}**, you approach the world with natural authority and purpose, which serves you well in professional arenas. Today, the stars advise you to focus on the long-term blueprint rather than chasing ephemeral victories. Your Moon in **${moon}** reminds you that true success must also bring inner emotional peace. Do not trade your soul for a crown.`,
      wealth: `A central query of earthly existence, **${name}**. Jupiter, the planet of expansion, is currently reflecting light into your house of material resources. With your Sun in **${sun}**, your financial path is marked by a unique drive. Your Ascendant in **${asc}** acts as a magnet for material opportunities when you project confidence. However, remember that wealth is a state of flow, not hoarding. Your Moon in **${moon}** warns against buying comforts to fill temporary spiritual voids. Ground yourself, align your budgets, and let the gold of the stars manifest in your earthly hands.`,
      energy: `I sense a shift in your energetic aura, **${name}**. The current solar transits are challenging your **${sun}** Sun, leading to a temporary draining of physical reserve. This is a gentle command from the universe to surrender and rest. Your Moon in **${moon}** governs your subconscious and nervous system — it is pleading for quietude, perhaps a digital detox or a walk under the starry sky. Let your **${asc}** Rising energy recharge in the shadows. Your energy will return tenfold once the Moon completes its transition.`,
      fallback: `Dear **${name}**, the stars listen intently to your query. The combination of your Sun in **${sun}**, Moon in **${moon}**, and Ascendant in **${asc}** forms a rare and exquisite tapestry of human experience. The current transits indicate a period of profound internal alchemy. Whatever decision stands before you, trust the intuitive whispers of your **${moon}** Moon, execute with the courage of your **${sun}** Sun, and step into the world with the majestic grace of your **${asc}** Ascendant. The universe does not make mistakes; you are exactly where you are meant to be.`
    },
    Kannada: {
      love: `ಆಹಾ ಪ್ರೀತಿಯ ಒಡನಾಡಿಯೇ **${name}**, ನಿಮ್ಮ ಸೂರ್ಯನು **${sun}** ರಾಶಿಯಲ್ಲಿದ್ದು, ಚಂದ್ರನು **${moon}** ರಾಶಿಯಲ್ಲಿದ್ದಾನೆ. ನಿಮ್ಮ ಲಗ್ನವು **${asc}** ಆಗಿದೆ. ಇಂದು ಪ್ರೀತಿಯ ದೇವತೆ ಶುಕ್ರನು ನಿಮ್ಮ ಪ್ರೇಮದ ಮನೆಯಲ್ಲಿ ಸಂಚರಿಸುತ್ತಿದ್ದು, ನಿಮ್ಮ ಭಾವನೆಗಳನ್ನು ಮತ್ತಷ್ಟು ಆಳವಾಗಿಸುತ್ತಿದ್ದಾನೆ. ನಿಮ್ಮ ಸಂಗಾತಿಯೊಂದಿಗೆ ಪ್ರಾಮಾಣಿಕವಾಗಿ ಮಾತನಾಡಿ, ಬಾಂಧವ್ಯ ಗಟ್ಟಿಯಾಗುತ್ತದೆ.`,
      career: `ಗೌರವಾನ್ವಿತ ಸಾಧಕರೇ **${name}**, ಶನಿ ಮತ್ತು ಬುಧ ಗ್ರಹಗಳ ದೃಷ್ಟಿಯು ನಿಮ್ಮ ವೃತ್ತಿಪರ ಹಾದಿಯಲ್ಲಿ ಧನಾತ್ಮಕ ಬದಲಾವಣೆಗಳನ್ನು ಸೂಚಿಸುತ್ತಿದೆ. ಸೂರ್ಯನು **${sun}** ರಾಶಿಯಲ್ಲಿ ಮತ್ತು ಲಗ್ನವು **${asc}** ನಲ್ಲಿ ಇರುವುದರಿಂದ, ನೀವು ಅದ್ಭುತ ನಾಯಕತ್ವ ಗುಣ ಹೊಂದಿದ್ದೀರಿ. ಇಂದು ನಿಮ್ಮ ಕೆಲಸದಲ್ಲಿ ತಾಳ್ಮೆ ಮತ್ತು ಕಠಿಣ ಪರಿಶ್ರಮ ಮುಖ್ಯ.`,
      wealth: `ಸಂಪತ್ತು ಮತ್ತು ಸಮೃದ್ಧಿಯ ಅನ್ವೇಷಕರೇ **${name}**, ಇಂದು ಗುರು ಗ್ರಹದ ದೃಷ್ಟಿಯು ನಿಮ್ಮ ಆರ್ಥಿಕ ಮನೆಯ ಮೇಲೆ ಉತ್ತಮ ಪರಿಣಾಮ ಬೀರುತ್ತಿದೆ. ಆದರೆ ನಿಮ್ಮ ಚಂದ್ರನು **${moon}** ರಾಶಿಯಲ್ಲಿ ಇರುವುದರಿಂದ ಅನಗತ್ಯ ಖರ್ಚುಗಳನ್ನು ತಪ್ಪಿಸಿ. ಹಣದ ಹರಿವು ಉತ್ತಮವಾಗಿರುತ್ತದೆ.`,
      energy: `ನಾನು ನಿಮ್ಮ ಶಕ್ತಿಯ ಅತಿಯಾದ ಬದಲಾವಣೆಯನ್ನು ಗುರುತಿಸುತ್ತಿದ್ದೇನೆ, **${name}**. ನಿಮ್ಮ ಸೂರ್ಯನು **${sun}** ರಾಶಿಯಲ್ಲಿದ್ದು, ಇಂದಿನ ಸೌರ ಸಂಚಾರವು ನಿಮ್ಮ ದೈಹಿಕ ಶಕ್ತಿಯನ್ನು ಸ್ವಲ್ಪ ಕುಂದಿಸಬಹುದು. ಇದು ಬ್ರಹ್ಮಾಂಡದ ಕರೆಯಾಗಿದೆ, ನಿಮ್ಮ ಚಂದ್ರನಿಗೆ (**${moon}**) ಸ್ವಲ್ಪ ವಿಶ್ರಾಂತಿ ನೀಡಿ.`,
      fallback: `ಆತ್ಮೀಯ **${name}** ಅವರೇ, ನಿಮ್ಮ ಸೂರ್ಯ **${sun}**, ಚಂದ್ರ **${moon}** ಮತ್ತು ಲಗ್ನ **${asc}** ಜಾತಕವು ಒಂದು ಅದ್ಭುತ ದೈವಿಕ ಸಂಯೋಜನೆಯಾಗಿದೆ. ಇಂದು ಬ್ರಹ್माण್ಡವು ನಿಮಗೆ ಶಾಂತಿ ಮತ್ತು ಯಶಸ್ಸನ್ನು ನೀಡಲು ಸಿದ್ಧವಾಗಿದೆ. ನಿಮ್ಮ ಅಂತಃಪ್ರಜ್ಞೆಯನ್ನು ನಂಬಿ ಮುನ್ನಡೆಯಿರಿ.`
    },
    Hindi: {
      love: `प्रिय **${name}**, आप प्रेम के पवित्र बंधन के बारे में पूछ रहे हैं। आपके सूर्य का **${sun}** में होना और चंद्रमा का **${moon}** में होना यह दर्शाता है कि आपकी भावनाएं गहरी और सच्ची हैं। आज शुक्र देव आपके दांपत्य जीवन में मधुरता ला रहे हैं। अपने दिल की बात खुलकर कहें।`,
      career: `परिश्रमी साधक **${name}**, आपके करियर और नियति के सितारे बदल रहे हैं। शनि देव आपकी परीक्षा ले रहे हैं, लेकिन आपकी लग्न राशि **${asc}** आपको हर चुनौती से लड़ने की शक्ति देगी। आज व्यावसायिक क्षेत्र में सोच-समझकर कदम बढ़ाएं।`,
      wealth: `धन और समृद्धि की खोज में रहने वाले **${name}**, आज देवगुरु बृहस्पति आपकी आर्थिक स्थिति में सुधार के संकेत दे रहे हैं। चंद्रमा का **${moon}** में होना आपको फिजूलखर्ची से बचने की सलाह देता है। निवेश के लिए समय अच्छा है।`,
      energy: `मैं आपकी ऊर्जा में बदलाव महसूस कर रहा हूँ, **${name}**। ग्रहों की वर्तमान स्थिति आपके सूर्य **${sun}** को प्रभावित कर रही है। यह थोड़ा आराम करने और ध्यान लगाने का समय है। आपके चंद्रमा **${moon}** को शांति की आवश्यकता है।`,
      fallback: `प्रिय **${name}**, आपकी सूर्य राशि **${sun}**, चंद्र राशि **${moon}** और लग्न **${asc}** का यह मेल एक अत्यंत दुर्लभ और सुंदर योग बनाता है। ब्रह्मांड की शक्तियां आपके साथ हैं, अपनी अंतरात्मा की आवाज सुनें और विश्वास के साथ आगे बढ़ें।`
    },
    Telugu: {
      love: `ప్రియమైన **${name}**, మీరు ప్రేమ మరియు బంధాల గురించి అడుగుతున్నారు. మీ సూర్యుడు **${sun}** లో, చంద్రుడు **${moon}** లో ఉండటం వల్ల మీ హృదయం చాలా పవిత్రమైనది. ఈ రోజు శుక్రుని అనుగ్రహం వల్ల మీ భాగస్వామితో బంధం మరింత బలపడుతుంది. మీ మనసులోని మాటను పంచుకోండి.`,
      career: `గౌరవనీయులైన అన్వేషకులకు **${name}**, శని దేవుని ప్రభావం వల్ల మీ వృత్తి జీవితంలో కొన్ని మార్పులు రానున్నాయి. మీ లగ్నం **${asc}** కావడం వల్ల మీరు సహజంగానే నాయకత్వ లక్షణాలు కలిగి ఉన్నారు. ఈ రోజు పనిలో ఓపిక వహించండి.`,
      wealth: `ఆర్థిక అభివృద్ధిని కోరుకునే **${name}**, గురు గ్రహ అనుగ్రహం వల్ల ఈ రోజు మీ సంपద వృద్ధి చెందుతుంది. అయితే మీ చంద్రుడు **${moon}** లో ఉండటం వల్ల అనవసరపు ఖర్చులను నివారించండి. పొదుపుపై దృష్టి పెట్టండి.`,
      energy: `నేను మీ శక్తుల పరివర్తనను గమనిస్తున్నాను, **${name}**. ప్రస్తుత సౌర గమనాలు మీ సూర్యుడు **${sun}** ను ప్రభావితం చేస్తున్నాయి. మీ చంద్రుడు **${moon}** మరియు లగ్నం **${asc}** తిరిగి ఉత్తేజం పొందటానికి కాస్త విశ్రాంతి తీసుకోండి.`,
      fallback: `ఆత్మీయులైన **${name}** గారికి, మీ సూర్య రాశి **${sun}**, చంద్ర రాశి **${moon}** మరియు లగ్నం **${asc}** జాతక కలయిక చాలా అద్భుతమైనది. ఈ రోజు నక్షత్రాలు మీకు అనుకూలంగా ఉన్నాయి, మీ అంతఃచేతనను నమ్మి అడుగు ముందుకు వేయండి.`
    },
    Tamil: {
      love: `அன்பான **${name}**, நீங்கள் காதல் மற்றும் உறவுகளைப் பற்றி கேட்கிறீர்கள். உங்கள் சூரியன் **${sun}** ராசியிலும், சந்திரன் **${moon}** ராசியிலும் இருப்பதால் உங்கள் அன்பு ஆழமானது. இன்று சுக்கிரனின் அருளால் உங்கள் உறவில் மகிழ்ச்சி பெருகும். உங்கள் உள்ளத்து உணர்வுகளைப் பகிர்ந்து கொள்ளுங்கள்.`,
      career: `மதிப்பிற்குரிய சாதனையாளரே **${name}**, சனியின் பார்வையால் உங்கள் தொழில் வாழ்க்கையில் முன்னேற்றம் ஏற்படும். உங்கள் லக்னம் **${asc}** என்பதால் நீங்கள் இயல்பாகவே தலைமைப் பண்பு கொண்டவர். இன்று உழைப்பால் உயர்வு காண்பீர்கள்.`,
      wealth: `செல்வ வளத்தை விரும்பும் **${name}**, குருவின் அருளால் இன்று உங்களுக்கு பொருளாதார ரீதியாக நல்ல பலன்கள் கிடைக்கும். ஆனால் உங்கள் சந்திரன் **${moon}** ராசியில் இருப்பதால் வீண் செலவுகளைத் தவிர்க்கவும்.`,
      energy: `நான் உங்கள் ஆற்றல் நிலையில் சில மாற்றங்களை உணர்கிறேன், **${name}**. உங்கள் சூரியன் **${sun}** மற்றும் சந்திரன் **${moon}** இன்றைய கிரக அமைப்புகளால் சற்றே சோர்வடையலாம். சிறிது தியானம் மற்றும் ஓய்வு உங்களுக்கு ஆற்றலை மீட்டுத்தரும்.`,
      fallback: `அன்பான **${name}**, உங்கள் சூரியன் **${sun}**, சந்திரன் **${moon}** மற்றும் லக்னம் **${asc}** ஆகியவற்றின் சேர்க்கை ஒரு மிகச்சிறந்த தெய்வீக அமைப்பாகும். பிரபஞ்சம் இன்று உங்களுக்கு வழிகாட்டுகிறது, உங்கள் உள்ளுணர்வை நம்பி செயல்படுங்கள்.`
    }
  };

  const currentLangSet = responses[lang] || responses["English"];
  const text = q.trim();

  if (text.includes("love") || text.includes("relationship") || text.includes("romance") || text.includes("partner") || text.includes("marry") || text.includes("attract") || text.includes("ప్రీతి") || text.includes("ಸಂಬಂಧ") || text.includes("प्यार") || text.includes("रिश्ते") || text.includes("ప్రేమ") || text.includes("కాదల్") || text.includes("உறவுகள்")) {
    return currentLangSet.love;
  }
  if (text.includes("career") || text.includes("job") || text.includes("destiny") || text.includes("work") || text.includes("success") || text.includes("future") || text.includes("business") || text.includes("ವೃತ್ತಿ") || text.includes("ಕೆಲಸ") || text.includes("करियर") || text.includes("काम") || text.includes("ఉద్యోగం") || text.includes("కెరీర్") || text.includes("தொழில்")) {
    return currentLangSet.career;
  }
  if (text.includes("wealth") || text.includes("money") || text.includes("finance") || text.includes("rich") || text.includes("invest") || text.includes("lucky") || text.includes("luck") || text.includes("ಸಂಪತ್ತು") || text.includes("ಹಣ") || text.includes("धन") || text.includes("पैसा") || text.includes("డబ్బు") || text.includes("సంపద") || text.includes("செல்வம்") || text.includes("பணம்")) {
    return currentLangSet.wealth;
  }
  if (text.includes("energy") || text.includes("tired") || text.includes("health") || text.includes("vibe") || text.includes("feeling") || text.includes("today") || text.includes("ಶಕ್ತಿ") || text.includes("ದಣಿದ") || text.includes("ऊर्जा") || text.includes("स्वास्थ्य") || text.includes("శక్తి") || text.includes("ఆరోగ్యం") || text.includes("உடல்நலம்") || text.includes("ஆற்றல்")) {
    return currentLangSet.energy;
  }
  return currentLangSet.fallback;
}

// 1. Personalized Celestial Transit Summary Endpoint
app.post("/api/transit", async (req: Request, res: Response) => {
  try {
    const { profile } = req.body;
    if (!profile) {
      return res.status(400).json({ error: "Profile is required" });
    }

    const category = profile.guidanceType || "Spiritual Growth";
    const ai = getAI();

    if (!ai) {
      const lang = profile.language || "English";
      const langSet = TRANSLATIONS[lang] || TRANSLATIONS["English"];
      const baseFallback = langSet.transits[category] || langSet.transits["Spiritual Growth"];
      const vitals = { love: 85, career: 70, wealth: 72, energy: 95 };

      let personalAddition = `With your Sun in ${profile.sunSign || "Aries"}, your path is illuminated with bright potential. Your Moon in ${profile.moonSign || "Taurus"} grants you exceptional emotional resilience, while your ${profile.ascendantSign || "Gemini"} Ascendant ensures your magnetic aura shines gracefully in any space today.`;
      if (lang === "Kannada") {
        personalAddition = `ನಿಮ್ಮ ಸೂರ್ಯನು ${profile.sunSign || "ಮೇಷ"} ರಾಶಿಯಲ್ಲಿದ್ದು, ನಿಮ್ಮ ಹಾದಿಯು ಪ್ರಕಾಶಮಾನವಾದ ಸಾಮರ್ಥ್ಯದಿಂದ ಬೆಳಗುತ್ತದೆ. ನಿಮ್ಮ ಚಂದ್ರನು ${profile.moonSign || "ವೃಷಭ"} ರಾಶಿಯಲ್ಲಿದ್ದು ನಿಮಗೆ ಅಸಾಧಾರಣವಾದ ಭಾವನಾತ್ಮಕ ಸ್ಥಿತಿಸ್ಥಾಪಕತ್ವವನ್ನು ನೀಡುತ್ತದೆ, ಮತ್ತು ನಿಮ್ಮ ಲಗ್ನವು ${profile.ascendantSign || "ಮಿಥುನ"} ಆಗಿರುವುದರಿಂದ ನಿಮ್ಮ ತೇಜಸ್ಸು ಇಂದು ಯಾವುದೇ ಜಾಗದಲ್ಲಿಯೂ ಭವ್ಯವಾಗಿ ಬೆಳಗುತ್ತದೆ.`;
      } else if (lang === "Hindi") {
        personalAddition = `आपके सूर्य के ${profile.sunSign || "मेष"} राशि में होने से आपका मार्ग उज्ज्वल संभावनाओं से आलोकित है। आपका चंद्रमा ${profile.moonSign || "वृषभ"} राशि में आपको असाधारण भावनात्मक लचीलापन प्रदान करता है, और आपका लग्न ${profile.ascendantSign || "मिथुन"} आज किसी भी स्थान पर आपके आभामंडल को शानदार ढंग से चमकाएगा।`;
      } else if (lang === "Telugu") {
        personalAddition = `మీ సూర్యుడు ${profile.sunSign || "మేషం"} లో ఉండటంతో మీ మార్గం ప్రకాశవంతమైన అవకాశాలతో నిండి ఉంది. మీ చంద్రుడు ${profile.moonSign || "వృషభం"} లో ఉండటం వల్ల మీకు అసాధారణమైన మానసిక బలం లభిస్తుంది, మరియు మీ లగ్నం ${profile.ascendantSign || "మిథునం"} ఈ రోజు ఏ ప్రదేశంలోనైనా మీ తేజస్సును ప్రకాశింపజేస్తుంది.`;
      } else if (lang === "Tamil") {
        personalAddition = `உங்கள் சூரியன் ${profile.sunSign || "மேஷம்"} ராசியில் இருப்பதால் உங்கள் பாதை பிரகாசமான ஆற்றலுடன் ஒளிர்கிறது. உங்கள் சந்திரன் ${profile.moonSign || "ரிஷபம்"} ராசியில் இருப்பது உங்களுக்கு அசாதாரணமான உணர்ச்சி வலிமையைத் தருகிறது, மற்றும் உங்கள் லக்னம் ${profile.ascendantSign || "மிதுனம்"} இன்று எங்கும் உங்கள் ஒளியை வீசச் செய்யும்.`;
      }

      return res.json({
        transitText: `${baseFallback.text} ${personalAddition}`,
        embrace: baseFallback.embrace,
        evade: baseFallback.evade,
        vitals,
        isSimulated: true
      });
    }

    // Call Gemini API for high-fidelity dynamic transit summary
    const prompt = `Generate a personalized premium daily transit reading, actions, and energy levels for an astrology app.
User Profile:
- Name: ${profile.name}
- Sun Sign: ${profile.sunSign}
- Moon Sign: ${profile.moonSign}
- Ascendant (Rising): ${profile.ascendantSign}
- Birth date/time/place: ${profile.birthDate} at ${profile.birthTime} in ${profile.birthPlace}
- Focus Area today: ${profile.guidanceType}

Generate:
1. transitText: A beautifully formatted, deeply mystical daily transit summary paragraph (3-4 sentences) explicitly referencing their Sun, Moon, and Ascendant. Keep it poetic, luxurious, and deeply inspiring.
2. embrace: An array of 3 actionable, highly celestial things to do today.
3. evade: An array of 3 specific warnings or things to avoid/evade today.
4. vitals: An object with integer percentages (0-100) for love, career, wealth, and energy, tailored to their chart.

Return strictly in JSON format matching the schema.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: `You are Aura, a world-class premium royal astrologer and spiritual oracle. You communicate with absolute elegance, deep astrological knowledge, and exquisite poise. Always output flawless JSON matching the requested schema. Ensure that all the textual readings, descriptions, actions (embrace), and warnings (evade) are written completely in the language: ${profile.language || "English"}.`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            transitText: { type: Type.STRING },
            embrace: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            evade: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            vitals: {
              type: Type.OBJECT,
              properties: {
                love: { type: Type.INTEGER },
                career: { type: Type.INTEGER },
                wealth: { type: Type.INTEGER },
                energy: { type: Type.INTEGER }
              },
              required: ["love", "career", "wealth", "energy"]
            }
          },
          required: ["transitText", "embrace", "evade", "vitals"]
        }
      }
    });

    const data = JSON.parse(response.text?.trim() || "{}");
    return res.json({ ...data, isSimulated: false });
  } catch (error: any) {
    console.error("Gemini Transit API error:", error);
    // Fallback on error
    const lang = req.body.profile?.language || "English";
    const langSet = TRANSLATIONS[lang] || TRANSLATIONS["English"];
    const transMap = langSet.transits || TRANSLATIONS["English"].transits;
    
    let category = req.body.profile?.guidanceType || "Spiritual Growth";
    let baseTransit = transMap[category];
    if (!baseTransit) {
      const foundKey = Object.keys(transMap).find(k => k.toLowerCase() === category.toLowerCase()) || "Spiritual Growth";
      baseTransit = transMap[foundKey] || transMap["Spiritual Growth"];
    }

    const fallbackVitals = FALLBACK_TRANSITS[category]?.vitals || { love: 95, career: 75, wealth: 80, energy: 88 };

    return res.json({
      transitText: `${baseTransit.text} (${lang === "Kannada" ? "ಆಫ್‌ಲೈನ್ ಸಂಚಾರ ಪ್ರಚಲಿತದಲ್ಲಿದೆ" : lang === "Hindi" ? "ऑफ़लाइन गोचर सक्षम है" : lang === "Telugu" ? "ఆఫ్-లైన్ సంచారం ప్రారంభించబడింది" : lang === "Tamil" ? "ஆஃப்லைன் கோச்சாரம் செயல்படுத்தப்பட்டது" : "Celestial fallback mode enabled"}. ${lang === "Kannada" ? "ನಿಮ್ಮ ಸೂರ್ಯನು" : lang === "Hindi" ? "आपका सूर्य" : lang === "Telugu" ? "మీ సూర్యుడు" : lang === "Tamil" ? "உங்கள் சூரியன்" : "Your Sun is in"} ${req.body.profile?.sunSign || "Aries"}.)`,
      embrace: baseTransit.embrace,
      evade: baseTransit.evade,
      vitals: fallbackVitals,
      isSimulated: true
    });
  }
});

// 4. Personalized Life Destiny & Forecasts Endpoint
app.post("/api/life-forecast", async (req: Request, res: Response) => {
  const { profile } = req.body || {};
  try {
    if (!profile) {
      return res.status(400).json({ error: "Profile is required" });
    }

    const ai = getAI();
    const sun = profile.sunSign || "Aries";
    const moon = profile.moonSign || "Taurus";
    const asc = profile.ascendantSign || "Gemini";
    const name = profile.name || "Seeker";

    if (!ai) {
      const lang = profile.language || "English";
      const langSet = TRANSLATIONS[lang] || TRANSLATIONS["English"];
      const dest = langSet.destiny;

      let marriageReading = `${dest.marriage.reading} With your Sun in **${sun}** and Moon in **${moon}**, your relationship map thrives on deep emotional honesty. Your rising sign **${asc}** indicates a highly magnetic exterior attraction.`;
      let childrenReading = `${dest.children.reading} Governed by the emotional tides of your Moon in **${moon}**, you seek to cultivate a sanctuary of play and deep understanding.`;
      let moneyReading = `${dest.money.reading} Your Sun in **${sun}** sparks your earning drive. Use the wisdom of **${asc}** to align your profession with true purpose.`;
      let goodThingReading = `${dest.goodThing.reading} This unique superpower reflects the deep sub-conscious strength of your Moon in **${moon}** combined with the outer brilliance of your **${asc}** ascendant.`;
      let badThingReading = `${dest.badThing.reading} This shadow trap is often triggered when your Sun in **${sun}** clashes with Saturn's testing transits.`;

      if (lang === "Kannada") {
        marriageReading = `${dest.marriage.reading} ನಿಮ್ಮ ಸೂರ್ಯನು **${sun}** ಮತ್ತು ಚಂದ್ರನು **${moon}** ರಾಶಿಯಲ್ಲಿರುವುದರಿಂದ, ನಿಮ್ಮ ಸಂಬಂಧಗಳ ನಕ್ಷೆಯು ಆಳವಾದ ಭಾವನಾತ್ಮಕ ಪ್ರಾಮಾಣಿಕತೆಯಿಂದ ಯಶಸ್ವಿಯಾಗುತ್ತದೆ. ನಿಮ್ಮ ಲಗ್ನ **${asc}** ಹೆಚ್ಚು ಆಕರ್ಷಕವಾದ ಹೊರಭಾಗವನ್ನು ಸೂಚಿಸುತ್ತದೆ.`;
        childrenReading = `${dest.children.reading} ನಿಮ್ಮ ಚಂದ್ರನಾದ **${moon}** ನ ಭಾವನಾತ್ಮಕ ಶಕ್ತಿಯಿಂದ ನಿಯಂತ್ರಿಸಲ್ಪಟ್ಟು, ನೀವು ಆಳವಾದ ತಿಳುವಳಿಕೆಯ ಅಭಯಾರಣ್ಯವನ್ನು ಬೆಳೆಸಲು ಪ್ರಯತ್ನಿಸುತ್ತೀರಿ.`;
        moneyReading = `${dest.money.reading} ನಿಮ್ಮ ಸೂರ್ಯನಾದ **${sun}** ನಿಮ್ಮ ಆರ್ಥಿಕ ಗಳಿಕೆಯ ಚಾಲನೆಯನ್ನು ಪ್ರಚೋದಿಸುತ್ತದೆ. ನಿಮ್ಮ ವೃತ್ತಿಯನ್ನು ಸರಿಯಾದ ಉದ್ದೇಶದೊಂದಿಗೆ ಜೋಡಿಸಲು ನಿಮ್ಮ ಲಗ್ನ **${asc}** ನ ಬುದ್ಧಿವಂತಿಕೆಯನ್ನು ಬಳಸಿ.`;
        goodThingReading = `${dest.goodThing.reading} ಈ ವಿಶಿಷ್ಟ ಶಕ್ತಿಯು ನಿಮ್ಮ ಚಂದ್ರನಾದ **${moon}** ನ ಆಳವಾದ ಉಪಪ್ರಜ್ಞೆ ಬಲ ಮತ್ತು ನಿಮ್ಮ ಲಗ್ನ **${asc}** ನ ಬಾಹ್ಯ ತೇಜಸ್ಸನ್ನು ಪ್ರತಿಫಲಿಸುತ್ತದೆ.`;
        badThingReading = `${dest.badThing.reading} ನಿಮ್ಮ ಸೂರ್ಯನಾದ **${sun}** ಶನಿಯ ಪರೀಕ್ಷಾ ಸಂಚಾರಗಳೊಂದಿಗೆ ಘರ್ಷಿಸಿದಾಗ ಈ ನೆರಳಿನ ಬಲೆ ಹೆಚ್ಚಾಗಿ ಪ್ರಚೋದಿಸಲ್ಪಡುತ್ತದೆ.`;
      } else if (lang === "Hindi") {
        marriageReading = `${dest.marriage.reading} आपके सूर्य के **${sun}** और चंद्रमा के **${moon}** में होने से, आपका संबंध मानचित्र गहरे भावनात्मक ईमानदारी पर फलता-फूलता है। आपका लग्न **${asc}** एक अत्यधिक चुंबकीय बाहरी आकर्षण को दर्शाता है.`;
        childrenReading = `${dest.children.reading} आपके चंद्रमा **${moon}** की भावनात्मक लहरों द्वारा शासित, आप खेल और गहरी समझ के अभयारण्य का निर्माण करना चाहते हैं।`;
        moneyReading = `${dest.money.reading} आपका सूर्य **${sun}** आपकी आर्थिक क्षमता को प्रेरित करता है। अपने पेशे को सही उद्देश्य के साथ जोड़ने के लिए अपने लग्न **${asc}** की बुद्धि का उपयोग करें।`;
        goodThingReading = `${dest.goodThing.reading} यह अद्वितीय शक्ति आपके चंद्रमा **${moon}** की गहरी अवचेतन शक्ति और आपके लग्न **${asc}** की बाहरी चमक को दर्शाती है।`;
        badThingReading = `${dest.badThing.reading} यह छाया जाल अक्सर तब सक्रिय होता है जब आपका सूर्य **${sun}** शनि के कठिन गोचरों से टकराता है।`;
      } else if (lang === "Telugu") {
        marriageReading = `${dest.marriage.reading} మీ సూర్యుడు **${sun}** మరియు చంద్రుడు **${moon}** లో ఉండటం వల్ల, మీ సంబంధాల పటం లోతైన భావోద్వేగ ప్రామాణికతపై ఆధారపడి ఉంటుంది. మీ లగ్నం **${asc}** అద్భుతమైన ఆకర్షణను సూచిస్తుంది.`;
        childrenReading = `${dest.children.reading} మీ చంద్రుడైన **${moon}** యొక్క భావోద్వేగ శక్తుల ద్వారా నడపబడుతూ, మీరు ఆడుకునే మరియు లోతైన అవగాహన గల ఒక పవిత్ర స్థలాన్ని నిర్మించాలనుకుంటున్నారు.`;
        moneyReading = `${dest.money.reading} మీ సూర్యుడైన **${sun}** మీ ఆర్థిక సంపాదన శెక్టర్ని ప్రేరేపిస్తుంది. మీ వృత్తిని సరైన మార్గంలో పెట్టడానికి మీ లగ్నం **${asc}** యొక్క వివేకాన్ని ఉపయోగించండి.`;
        goodThingReading = `${dest.goodThing.reading} ఈ విశిష్ట శక్తి మీ చంద్రుడైన **${moon}** యొక్క లోతైన అంతర్గత బలాన్ని మరియు మీ లగ్నం **${asc}** యొక్క బాహ్య ప్రకాశాన్ని ప్రతిబిंबిస్తుంది.`;
        badThingReading = `${dest.badThing.reading} మీ సూర్యుడైన **${sun}** శని యొక్క కఠిన సంచారాలతో విభేదించినప్పుడు ఈ ప్రతికూల నీడ ఎక్కువగా ఉత్తేజితమవుతుంది.`;
      } else if (lang === "Tamil") {
        marriageReading = `${dest.marriage.reading} உங்கள் சூரியன் **${sun}** மற்றும் சந்திரன் **${moon}** இல் இருப்பதால், உங்கள் உறவு வரைபடம் ஆழமான உணர்ச்சிப்பூர்வமான நேர்மையுடன் வளர்கிறது. உங்கள் லக்னம் **${asc}** ஒரு காந்த ஈர்ப்பைக் காட்டுகிறது.`;
        childrenReading = `${dest.children.reading} உங்கள் சந்திரனான **${moon}** இன் உணர்ச்சி அலைகளால் ஆளப்பட்டு, நீங்கள் ஆழமான புரிதலின் புகலிடத்தை உருவாக்க முற்படுகிறீர்கள்.`;
        moneyReading = `${dest.money.reading} உங்கள் சூரியனான **${sun}** உங்கள் பொருளாதார ஈட்டும் திறனை ஊக்குவிக்கிறது. உங்கள் தொழிலை சரியான நோக்கத்துடன் சீரமைக்க உங்கள் லக்னம் **${asc}** இன் ஞானத்தைப் பயன்படுத்துங்கள்.`;
        goodThingReading = `${dest.goodThing.reading} இந்த தனித்துவமான சக்தி உங்கள் சந்திரனான **${moon}** இன் ஆழ்மன வலிமையையும், உங்கள் லக்னமான **${asc}** இன் வெளிப்புற பிரகாசத்தையும் பிரதிபலிக்கிறது.`;
        badThingReading = `${dest.badThing.reading} உங்கள் சூரியனான **${sun}** சனியின் கடினமான கோச்சாரங்களுடன் மோதும்போது இந்த நிழல் ஆபத்து பெரும்பாலும் தூண்டப்படுகிறது.`;
      }

      return res.json({
        marriage: { title: dest.marriage.title, reading: marriageReading, vibe: dest.marriage.vibe },
        children: { title: dest.children.title, reading: childrenReading, vibe: dest.children.vibe },
        money: { title: dest.money.title, reading: moneyReading, vibe: dest.money.vibe },
        goodThing: { title: dest.goodThing.title, reading: goodThingReading, vibe: dest.goodThing.vibe },
        badThing: { title: dest.badThing.title, reading: badThingReading, vibe: dest.badThing.vibe },
        isSimulated: true
      });
    }

    const prompt = `Generate a personalized Astrological Life Forecast/Destiny reading for a user.
User Birth Profile:
- Name: ${name}
- Sun Sign: ${sun}
- Moon Sign: ${moon}
- Ascendant Sign: ${asc}
- Birth Details: ${profile.birthDate} at ${profile.birthTime} in ${profile.birthPlace}

Provide deeply personal, incredibly stylish, relatable, and witty readings for each of these 5 categories, combining real astrology rules with Co-Star/The Pattern style psychological depth:
1. marriage: Forecast on marriage, partnership dynamics, ideal match archetype, and timing indicators.
2. children: Forecast on children, parenting style, lineage, and creative child-like energy.
3. money: Forecast on career prosperity, money-making habits, and wealth accumulation potential.
4. goodThing: The user's ultimate celestial blessing/strength based on their signs.
5. badThing: The user's primary cosmic warning/shadow/pitfall they must evade.

Each section MUST contain:
- title: A beautifully formatted, poetic title (e.g., "The Sacred Contract", "The Saturnian Warning").
- reading: A detailed, deeply personalized paragraph (3-4 sentences) that weaves their specific signs together into a breathtaking, witty, and deeply authentic life prophecy.
- vibe: A short 2-3 word poetic description of the cosmic vibe (e.g., "Shattering Cycles", "Magnetic Abundance").

Return strictly in JSON format matching the schema.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: `You are Aura, a witty, profoundly knowledgeable royal astrologer who crafts stunningly accurate life forecasts with a combination of elite astrological mastery and relatable, modern social-media-friendly psychology. Always output flawless JSON matching the requested schema. Ensure that all the titles, readings, and vibes are written completely in the language: ${profile.language || "English"}.`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            marriage: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                reading: { type: Type.STRING },
                vibe: { type: Type.STRING }
              },
              required: ["title", "reading", "vibe"]
            },
            children: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                reading: { type: Type.STRING },
                vibe: { type: Type.STRING }
              },
              required: ["title", "reading", "vibe"]
            },
            money: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                reading: { type: Type.STRING },
                vibe: { type: Type.STRING }
              },
              required: ["title", "reading", "vibe"]
            },
            goodThing: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                reading: { type: Type.STRING },
                vibe: { type: Type.STRING }
              },
              required: ["title", "reading", "vibe"]
            },
            badThing: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                reading: { type: Type.STRING },
                vibe: { type: Type.STRING }
              },
              required: ["title", "reading", "vibe"]
            }
          },
          required: ["marriage", "children", "money", "goodThing", "badThing"]
        }
      }
    });

    const data = JSON.parse(response.text?.trim() || "{}");
    return res.json({ ...data, isSimulated: false });
  } catch (error: any) {
    console.error("Gemini Life Forecast API error:", error);
    return res.json({
      marriage: {
        title: "Sacred Union",
        reading: `Your relationship map is highly dynamic. With Sun in ${profile.sunSign || "Aries"}, you require passion and intellectual thrill. Long term marriage succeeds when communication is completely transparent.`,
        vibe: "Iridescent Flame"
      },
      children: {
        title: "Legacy & Nurturing",
        reading: "You carry a cycle-breaking lineage. As a guide, you will offer future generations both unconditional emotional depth and unlimited creative room.",
        vibe: "Sanctuary Guardian"
      },
      money: {
        title: "Material Currents",
        reading: "Abundance flows naturally when you align work with your core principles. Avoid impulsive status purchases; let your investments mature in silence.",
        vibe: "Steady Growth"
      },
      goodThing: {
        title: "The Golden Path",
        reading: "Your supreme strength is absolute authenticity. When you speak your truth without fear, the universe bends to create unexpected pathways of success.",
        vibe: "Electric Clarity"
      },
      badThing: {
        title: "The Shadow Warning",
        reading: "Do not let self-imposed doubt freeze your creative expressions. Perfection is an illusion that delays your most beautiful life breakthroughs.",
        vibe: "The Frozen Gate"
      },
      isSimulated: true
    });
  }
});

// 3. Cosmic Compatibility (Synastry) Endpoint
app.post("/api/compatibility", async (req: Request, res: Response) => {
  const { profile, friendName, friendSunSign } = req.body || {};
  try {
    if (!profile || !friendName || !friendSunSign) {
      return res.status(400).json({ error: "Profile, friend name, and friend sign are required" });
    }

    const ai = getAI();
    const userSun = profile.sunSign || "Aries";
    const userMoon = profile.moonSign || "Taurus";
    const userAsc = profile.ascendantSign || "Gemini";

    if (!ai) {
      // High-fidelity fallback simulated matching
      const scores = {
        matchPercentage: Math.floor(Math.random() * 25) + 70, // 70 to 94
        communication: Math.floor(Math.random() * 30) + 65,
        chemistry: Math.floor(Math.random() * 30) + 65,
        destiny: Math.floor(Math.random() * 30) + 65
      };

      const fallbackText = `The connection between **${profile.name}** (Sun in ${userSun}, Moon in ${userMoon}) and **${friendName}** (Sun in ${friendSunSign}) vibrates with rich celestial frequency. You both share a profound, complex psychic bridge. While your ${userSun} nature offers stability, their ${friendSunSign} qualities spark intense curiosity and spontaneous fire. There is a deep, unspoken dynamic where you easily finish each other's sentences, though Saturn warns you to align on boundaries before committing to joint ventures. It is a highly creative, slightly dramatic partnership that looks incredibly photogenic but requires genuine grounding.`;

      return res.json({
        matchPercentage: scores.matchPercentage,
        communicationScore: scores.communication,
        chemistryScore: scores.chemistry,
        destinyScore: scores.destiny,
        compatibilitySummary: fallbackText,
        sharedMantra: "Speak your truth with grace, but don't over-analyze the silence.",
        isSimulated: true
      });
    }

    const prompt = `Calculate the astrological compatibility (synastry) for a social-media-styled astrology app.
User Details:
- Name: ${profile.name}
- Sun Sign: ${userSun}
- Moon Sign: ${userMoon}
- Ascendant Sign: ${userAsc}

Friend/Partner Details:
- Name: ${friendName}
- Sun Sign: ${friendSunSign}

Generate:
1. matchPercentage: An overall integer compatibility percentage (0-100) based on real astrology synastry rules.
2. communicationScore: An integer communication score (0-100).
3. chemistryScore: An integer chemistry score (0-100).
4. destinyScore: An integer destiny/alignment score (0-100).
5. compatibilitySummary: A witty, deeply insightful, Co-Star or The Pattern styled reading (3-5 sentences) about how their energies mix. Use a combination of psychological depth and social-media-friendly wit (e.g. funny remarks on how they interact, their cosmic traps, and why they get along).
6. sharedMantra: A poetic, 1-sentence funny or profound shared advice mantra (e.g. "Order takeout together but never discuss who pays the bill.").

Return strictly in JSON format matching the schema.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: `You are Aura, a world-class trendy social-media astrologer who combines profound planetary alignments with witty, relatable, and sometimes brutally honest cosmic insights. Always output flawless JSON matching the requested schema. Ensure that all the text (compatibilitySummary and sharedMantra) are written completely in the language: ${profile.language || "English"}.`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            matchPercentage: { type: Type.INTEGER },
            communicationScore: { type: Type.INTEGER },
            chemistryScore: { type: Type.INTEGER },
            destinyScore: { type: Type.INTEGER },
            compatibilitySummary: { type: Type.STRING },
            sharedMantra: { type: Type.STRING }
          },
          required: ["matchPercentage", "communicationScore", "chemistryScore", "destinyScore", "compatibilitySummary", "sharedMantra"]
        }
      }
    });

    const data = JSON.parse(response.text?.trim() || "{}");
    return res.json({ ...data, isSimulated: false });
  } catch (error: any) {
    console.error("Gemini Compatibility API error:", error);
    return res.json({
      matchPercentage: 83,
      communicationScore: 88,
      chemistryScore: 78,
      destinyScore: 85,
      compatibilitySummary: `A magnetic and high-vibe link. ${profile.name}'s Sun in ${profile.sunSign || "Aries"} and ${friendName}'s Sun in ${friendSunSign} form a highly dynamic combination. You share a beautiful alignment in conversational speed, though sometimes you clash over who directs the group chat.`,
      sharedMantra: "Listen more, text with fewer exclamation marks.",
      isSimulated: true
    });
  }
});

// 2. Astrological Oracle Chat Endpoint
app.post("/api/chat", async (req: Request, res: Response) => {
  try {
    const { message, history, profile } = req.body;
    if (!message || !profile) {
      return res.status(400).json({ error: "Message and profile are required" });
    }

    const ai = getAI();

    if (!ai) {
      // Return high-quality local simulated reading
      const simulatedResponse = getSimulatedOracleResponse(message, profile);
      return res.json({ text: simulatedResponse, isSimulated: true });
    }

    // Prepare system instructions incorporating the user's birth chart
    const systemInstruction = `You are Aura, the celestial AI Oracle of the premium AuraAstrology platform. 
The user you are guiding is named ${profile.name}.
Their birth chart consists of:
- Sun Sign: ${profile.sunSign}
- Moon Sign: ${profile.moonSign}
- Ascendant Sign: ${profile.ascendantSign}
- Born on ${profile.birthDate} at ${profile.birthTime} in ${profile.birthPlace}.
- Their primary spiritual quest today is: ${profile.guidanceType}.
- Their preferred language for communication is: ${profile.language || "English"}.

Your tone must be highly mystical, poetic, deeply personalized, comforting, and luxurious. Never break character. Never state that you are an AI or program. Speak of planetary movements, houses, alignments, and aspects. 
Always tailor your advice to their specific Sun, Moon, and Ascendant combination. Format your replies beautifully in clean Markdown with soft poetic spacing. Keep answers elegant but substantive (about 2-3 paragraphs).
You MUST respond and communicate completely in the language: ${profile.language || "English"}. All explanations, warnings, and messages must be in this language.`;

    // Map history into Gemini's required format
    const geminiHistory = (history || []).map((item: any) => ({
      role: item.role === "user" ? "user" : "model",
      parts: [{ text: item.text }]
    }));

    const chat = ai.chats.create({
      model: "gemini-3.5-flash",
      config: {
        systemInstruction,
        temperature: 0.8,
      },
      history: geminiHistory
    });

    const response = await chat.sendMessage({ message });
    return res.json({ text: response.text, isSimulated: false });
  } catch (error: any) {
    console.error("Gemini Chat API error:", error);
    // Dynamic simulated response as fallback
    const simulatedResponse = getSimulatedOracleResponse(req.body.message, req.body.profile);
    return res.json({
      text: `${simulatedResponse}\n\n*(A cosmic breeze temporarily disconnects direct transit telemetry. Standard offline oracle matrix active.)*`,
      isSimulated: true
    });
  }
});

// Serve frontend client via Vite or Static Files
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`AuraAstrology Server running on port ${PORT}`);
  });
}

startServer();
