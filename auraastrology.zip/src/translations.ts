export interface TranslationSet {
  onboarding: {
    title: string;
    subtitle: string;
    enterNameLabel: string;
    enterNamePlaceholder: string;
    langSelectLabel: string;
    beginBtn: string;
    arrivalTitle: string;
    arrivalSubtitle: string;
    dobLabel: string;
    tobLabel: string;
    nextBtn: string;
    geoTitle: string;
    geoSubtitle: string;
    geoPlaceholder: string;
    geoBtn: string;
    questTitle: string;
    questSubtitle: string;
    loveQuest: string;
    careerQuest: string;
    wealthQuest: string;
    spiritualQuest: string;
    prevBtn: string;
    calculateBtn: string;
    requiredError: string;
    geoRequiredError: string;
    dobRequiredError: string;
  };
  dashboard: {
    navTitle: string;
    navTagline: string;
    natalTitle: string;
    natalSubtitle: string;
    sunLabel: string;
    moonLabel: string;
    ascendantLabel: string;
    vitalsTitle: string;
    vitalsLove: string;
    vitalsCareer: string;
    vitalsWealth: string;
    vitalsEnergy: string;
    dailyFlowTitle: string;
    dailyFlowSubtitle: string;
    embraceLabel: string;
    evadeLabel: string;
    destinyTitle: string;
    destinySubtitle: string;
    synastryTitle: string;
    synastrySubtitle: string;
    friendNameLabel: string;
    friendNamePlaceholder: string;
    friendSignLabel: string;
    alignBtn: string;
    calculating: string;
    synastryMatch: string;
    synastryChemistry: string;
    synastryComm: string;
    synastryDestiny: string;
    synastryMantra: string;
    marriageTitle: string;
    childrenTitle: string;
    moneyTitle: string;
    goldenBlessing: string;
    cosmicWarning: string;
    vibeLabel: string;
    oracleTitle: string;
    oracleSubtitle: string;
    oraclePlaceholder: string;
    oracleLoading: string;
    copyBtn: string;
    copiedBtn: string;
    exportBtn: string;
    resetBtn: string;
    footerText: string;
    chartAligned: string;
    quickQuestions: string[];
    welcomeMessage: string;
  };
  zodiac: Record<string, { title: string; element: string; quality: string; planet: string; desc: string; vibe: string }>;
  transits: Record<string, { text: string; embrace: string[]; evade: string[] }>;
  destiny: {
    marriage: { title: string; reading: string; vibe: string };
    children: { title: string; reading: string; vibe: string };
    money: { title: string; reading: string; vibe: string };
    goodThing: { title: string; reading: string; vibe: string };
    badThing: { title: string; reading: string; vibe: string };
  };
}

export const TRANSLATIONS: Record<string, TranslationSet> = {
  English: {
    onboarding: {
      title: "Aura Astrology",
      subtitle: "Mystical, poetic astrology for elite souls",
      enterNameLabel: "What is your earthly name?",
      enterNamePlaceholder: "Enter your name...",
      langSelectLabel: "Select Your Preferred Language",
      beginBtn: "Begin Astral Ritual",
      arrivalTitle: "Your Cosmic Arrival",
      arrivalSubtitle: "Date and exact time of birth determine the precise planetary alignments.",
      dobLabel: "Date of Birth",
      tobLabel: "Time of Birth",
      nextBtn: "Next Dimension",
      geoTitle: "Geographical Anchor",
      geoSubtitle: "The precise coordinates of your birth city align the houses of your chart.",
      geoPlaceholder: "Enter City, Country of birth...",
      geoBtn: "Establish Anchor",
      questTitle: "What is your primary spiritual quest?",
      questSubtitle: "Select the focus area where you seek the most intense cosmic alignment today.",
      loveQuest: "Love & Relationships",
      careerQuest: "Career & Destiny",
      wealthQuest: "Wealth & Abundance",
      spiritualQuest: "Spiritual Growth",
      prevBtn: "Previous Phase",
      calculateBtn: "Calculate Astral Blueprint",
      requiredError: "Please enter your name to unlock the ritual.",
      geoRequiredError: "The alignment requires a geographical anchor.",
      dobRequiredError: "Both date and time of arrival are required for alignment."
    },
    dashboard: {
      navTitle: "Aura Astrology",
      navTagline: "Mystical, poetic astrology for elite souls",
      natalTitle: "The Natal Blueprint",
      natalSubtitle: "Your divine core, subconscious reflection, and rising aura",
      sunLabel: "Sun Sign",
      moonLabel: "Moon Sign",
      ascendantLabel: "Rising Sign",
      vitalsTitle: "Celestial Vitals",
      vitalsLove: "LOVE SYNERGY",
      vitalsCareer: "DESTINY FREQ",
      vitalsWealth: "WEALTH PROSPERITY",
      vitalsEnergy: "SOUL STRENGTH",
      dailyFlowTitle: "The Daily Flow",
      dailyFlowSubtitle: "Planetary aspects governing your focus today",
      embraceLabel: "Embrace",
      evadeLabel: "Evade",
      destinyTitle: "Personal Destiny Matrix",
      destinySubtitle: "Natal blueprint forecast for your life paths",
      synastryTitle: "Synastry Alignment",
      synastrySubtitle: "Check your energetic compatibility with another soul",
      friendNameLabel: "Friend's Earthly Name",
      friendNamePlaceholder: "Enter friend's name...",
      friendSignLabel: "Friend's Sun Sign",
      alignBtn: "Align Our Charts",
      calculating: "Decoding alignments...",
      synastryMatch: "SYNSTRY MATCH",
      synastryChemistry: "CHEMISTRY SCORE",
      synastryComm: "COMMUNICATION FREQ",
      synastryDestiny: "DESTINY FREQUENCY",
      synastryMantra: "Shared Mantra",
      marriageTitle: "Union & Sacred Contracts",
      childrenTitle: "Legacy & Creative Lineage",
      moneyTitle: "Material Prosperity & Abundance",
      goldenBlessing: "The Golden Blessing",
      cosmicWarning: "The Cosmic Warning",
      vibeLabel: "Vibe",
      oracleTitle: "Astral Oracle",
      oracleSubtitle: "Connected",
      oraclePlaceholder: "Ask the stars about your path...",
      oracleLoading: "Consulting transit paths...",
      copyBtn: "Copy Story Link",
      copiedBtn: "✓ Copied Link",
      exportBtn: "Export Image",
      resetBtn: "Dissolve Matrix",
      footerText: "Aura Astrology © 2026. Handcrafted for cosmic travelers.",
      chartAligned: "Chart Aligned",
      quickQuestions: [
        "Will today be lucky for me?",
        "How is my spiritual energy right now?",
        "What challenges should I evade today?"
      ],
      welcomeMessage: "Welcome, beautiful soul **{name}**. I see your Sun shines in **{sun}**, your Moon rests in **{moon}**, and your Ascendant rises majestic in **{asc}**. I am Aura, your personal Astral Oracle. Today, you seek the path of **{quest}**. What celestial secrets can I unlock for you?"
    },
    zodiac: {
      Aries: { title: "Aries — The Divine Spark", element: "Fire", quality: "Cardinal", planet: "Mars", desc: "Your cosmic flame represents the initial spark of creation. You are born with an unyielding life force, a soul destined to break new ground.", vibe: "Pure raw leadership, pioneering light, and fierce independence." },
      Taurus: { title: "Taurus — The Golden Anchor", element: "Earth", quality: "Fixed", planet: "Venus", desc: "Your soul is a master builder, anchored in the rich soil of Venusian sensory pleasure and material stability.", vibe: "Elegance in stillness, luxury in nature, and absolute loyalty." },
      Gemini: { title: "Gemini — The Cosmic Messenger", element: "Air", quality: "Mutable", planet: "Mercury", desc: "You represent the divine intellect in motion, bridging separate realities through language, curiosity, and rapid adaptation.", vibe: "Sprightly intellect, expressive charm, and boundless curiosity." },
      Cancer: { title: "Cancer — The Moonlit Temple", element: "Water", quality: "Cardinal", planet: "Moon", desc: "Your soul is the emotional sanctuary of the zodiac, governed by the ever-shifting silver phases of the Moon.", vibe: "Oceanic intuition, protective warmth, and sacred vulnerability." },
      Leo: { title: "Leo — The Sovereign Star", element: "Fire", quality: "Fixed", planet: "Sun", desc: "Governed by the golden solar center, your soul is a shining beacon of warmth, creative expression, and royal generosity.", vibe: "Majestic presence, golden creativity, and royal warmth." },
      Virgo: { title: "Virgo — The Alchemist's Crucible", element: "Earth", quality: "Mutable", planet: "Mercury", desc: "You are the cosmic craftsman, purifying raw energy into absolute harmony and functional perfection.", vibe: "Mindful precision, elegant order, and pure organic healing." },
      Libra: { title: "Libra — The Celestial Harmony", element: "Air", quality: "Cardinal", planet: "Venus", desc: "Your path is the pursuit of ultimate balance, grace, and relational harmony. Governed by the romantic arts of Venus.", vibe: "Artistic luxury, romantic ideals, and absolute balance." },
      Scorpio: { title: "Scorpio — The Phoenix's Veil", element: "Water", quality: "Fixed", planet: "Pluto", desc: "Your soul descends into the deep, mysterious waters of the underworld, only to rise again, reborn in the golden fire of transformation.", vibe: "Mysterious intensity, profound rebirth, and razor-sharp truth." },
      Sagittarius: { title: "Sagittarius — The Starward Arrow", element: "Fire", quality: "Mutable", planet: "Jupiter", desc: "Your spirit is an eternal seeker, aiming its burning arrow toward the outer boundaries of philosophy, travel, and divine truth.", vibe: "Wild wanderlust, expanding wisdom, and playful laughter." },
      Capricorn: { title: "Capricorn — The Crown of Time", element: "Earth", quality: "Cardinal", planet: "Saturn", desc: "Your soul climbs the rugged mountain of material mastery under the steady hand of Saturn. You are the architect of legacies.", vibe: "Timeless ambition, silent authority, and legacy building." },
      Aquarius: { title: "Aquarius — The Starry Visionary", element: "Air", quality: "Fixed", planet: "Uranus", desc: "You are the rebel-philosopher, holding the vessel of celestial knowledge. Your mind operates on future wavelengths.", vibe: "Future-forward thinking, eclectic brilliance, and collective harmony." },
      Pisces: { title: "Pisces — The Infinite Ocean", element: "Water", quality: "Mutable", planet: "Neptune", desc: "As the final sign, your soul holds the memories of all eleven previous signs, dissolving boundaries into the sea of collective consciousness.", vibe: "Dreamy poetry, transcendental art, and pure spiritual empathy." }
    },
    transits: {
      "Love & Relationships": {
        text: "Venus aligns gracefully with your ruling house today, casting an iridescent glow over your interpersonal connections. The celestial waters run warm and deep, encouraging raw emotional vulnerability. You may feel a magnetic pull toward deep, soul-stirring conversations. Trust the cosmic current.",
        embrace: ["Expressing your deepest unspoken feelings to a loved one", "Engaging in self-love rituals (warm baths, meditation)", "Opening your heart to unexpected cosmic encounters"],
        evade: ["Projecting past relationship fears onto current bonds", "Suppressing your emotional truth for superficial harmony", "Making hasty commitments under an impulsive moon"]
      },
      "Career & Destiny": {
        text: "Saturn and Mercury stand in a powerful conjunction, bringing structure, clarity, and exceptional drive to your professional ambitions. The stars favor strategic planning and execution. The noise of the material world fades, revealing the precise path toward your soul's true calling.",
        embrace: ["Refining your long-term vision board and actionable plans", "Initiating critical conversations with mentors or authority figures", "Setting strict, healthy boundaries around your work hours"],
        evade: ["Allowing imposter syndrome to paralyze your creative drive", "Signing complex business agreements without careful review", "Over-committing to minor tasks at the cost of your main objective"]
      },
      "Wealth & Abundance": {
        text: "Jupiter's abundant shadow sweeps across your house of material prosperity today, sparking positive financial realizations. This is not a time of reckless gambling, but of alignment with the energy of abundance. A celestial doorway is opening for intuitive investments.",
        embrace: ["Auditing your finances with a grateful and abundant mindset", "Investing in high-quality knowledge, books, or spiritual tools", "Decluttering your workspace to let fresh abundance circulate"],
        evade: ["Impulsive spending triggered by emotional fluctuations", "Doubting your capability to build long-term generational wealth", "Ignoring small leaks in your budget or automated subscriptions"]
      },
      "Spiritual Growth": {
        text: "Neptune casts a highly intuitive veil over your subconscious today, merging your earthly self with your infinite starry spirit. Dreams are vivid, synchronicities are loud, and your third eye is vibrating with potential. Step back from the material grind to explore internal worlds.",
        embrace: ["Recording and decoding the mysterious messages in your dreams", "Spending quiet time in nature or dedicated silent meditation", "Sensing and clearing out stale energy fields from your aura"],
        evade: ["Over-analyzing mystical experiences with sterile logic", "Absorbing other people's heavy emotional currents", "Forcing active outcomes when the universe counsels surrender"]
      }
    },
    destiny: {
      marriage: { title: "Union & Sacred Contracts", reading: "Your relationship map is highly dynamic. Passion and deep emotional trust govern your connections. Long-term success succeeds when communication is completely transparent, allowing vulnerability to transform into mutual strength.", vibe: "Iridescent Flame" },
      children: { title: "Legacy & Creative Lineage", reading: "You carry a cycle-breaking lineage. As a guide, your chart grants you exceptional depth to offer future generations both unconditional safety and unlimited creative room.", vibe: "Sanctuary Guardian" },
      money: { title: "Material Prosperity & Abundance", reading: "Abundance flows naturally when you align work with your core principles. Avoid impulsive status purchases; let your investments mature in absolute silence and patient strategy.", vibe: "Steady Growth" },
      goodThing: { title: "The Golden Blessing", reading: "Your supreme strength is absolute authenticity. When you speak your truth without fear, the universe bends to create unexpected pathways of success and deep allies.", vibe: "Electric Clarity" },
      badThing: { title: "The Cosmic Warning", reading: "Do not let self-imposed doubt freeze your creative expressions. Perfection is an illusion that delays your most beautiful life breakthroughs. Step out of the comfort loop.", vibe: "The Frozen Gate" }
    }
  },
  Kannada: {
    onboarding: {
      title: "ಔರಾ ಅಸ್ಟ್ರಾಲಜಿ",
      subtitle: "ಪ್ರತಿಷ್ಠಿತ ಆತ್ಮಗಳಿಗಾಗಿ ಆಧ್ಯಾತ್ಮಿಕ ಮತ್ತು ಕಾವ್ಯಾತ್ಮಕ ಜ್ಯೋತಿಷ್ಯ",
      enterNameLabel: "ನಿಮ್ಮ ಲೌಕಿಕ ಹೆಸರು ಏನು?",
      enterNamePlaceholder: "ನಿಮ್ಮ ಹೆಸರನ್ನು ನಮೂದಿಸಿ...",
      langSelectLabel: "ನಿಮ್ಮ ಆದ್ಯತೆಯ ಭಾಷೆಯನ್ನು ಆಯ್ಕೆಮಾಡಿ",
      beginBtn: "ಖಗೋಳ ಆಚರಣೆಯನ್ನು ಪ್ರಾರಂಭಿಸಿ",
      arrivalTitle: "ನಿಮ್ಮ ಬ್ರಹ್ಮಾಂಡದ ಆಗಮನ",
      arrivalSubtitle: "ನಿಮ್ಮ ನಿಖರವಾದ ಜನ್ಮ ದಿನಾಂಕ ಮತ್ತು ಸಮಯವು ನಿಮ್ಮ ಗ್ರಹಗಳ ಜೋಡಣೆಯನ್ನು ನಿರ್ಧರಿಸುತ್ತದೆ.",
      dobLabel: "ಹುಟ್ಟಿದ ದಿನಾಂಕ",
      tobLabel: "ಹುಟ್ಟಿದ ಸಮಯ",
      nextBtn: "ಮುಂದಿನ ಆಯಾಮ",
      geoTitle: "ಭೌಗೋಳಿಕ ಆಧಾರ",
      geoSubtitle: "ನಿಮ್ಮ ಜನ್ಮಸ್ಥಳದ ನಿಖರವಾದ ನಿರ್ದೇಶಾಂಕಗಳು ನಿಮ್ಮ ಕುಂಡಲಿಯ ಮನೆಗಳನ್ನು ಜೋಡಿಸುತ್ತವೆ.",
      geoPlaceholder: "ಹುಟ್ಟಿದ ನಗರ, ದೇಶವನ್ನು ನಮೂದಿಸಿ...",
      geoBtn: "ಭೌಗೋಳಿಕ ಆಧಾರವನ್ನು ಸ್ಥಾಪಿಸಿ",
      questTitle: "ನಿಮ್ಮ ಮುಖ್ಯ ಆಧ್ಯಾತ್ಮಿಕ ಅನ್ವೇಷಣೆ ಯಾವುದು?",
      questSubtitle: "ಇಂದು ನೀವು ಅತ್ಯಂತ ತೀವ್ರವಾದ ಬ್ರಹ್ಮಾಂಡದ ಜೋಡಣೆಯನ್ನು ಬಯಸುವ ವಲಯವನ್ನು ಆಯ್ಕೆಮಾಡಿ.",
      loveQuest: "ಪ್ರೀತಿ ಮತ್ತು ಸಂಬಂಧಗಳು",
      careerQuest: "ವೃತ್ತಿ ಮತ್ತು ವಿಧಿ",
      wealthQuest: "ಸಂಪತ್ತು ಮತ್ತು ಸಮೃದ್ಧಿ",
      spiritualQuest: "ಆಧ್ಯಾತ್ಮಿಕ ಬೆಳವಣಿಗೆ",
      prevBtn: "ಹಿಂದಿನ ಹಂತ",
      calculateBtn: "ನಕ್ಷತ್ರದ ನೀಲನಕ್ಷೆಯನ್ನು ಲೆಕ್ಕಹಾಕಿ",
      requiredError: "ಆಚರಣೆಯನ್ನು ಅನ್ಲಾಕ್ ಮಾಡಲು ದಯವಿಟ್ಟು ನಿಮ್ಮ ಹೆಸರನ್ನು ನಮೂದಿಸಿ.",
      geoRequiredError: "ಜೋಡಣೆಗೆ ಭೌಗೋಳಿಕ ಆಧಾರದ ಅಗತ್ಯವಿದೆ.",
      dobRequiredError: "ಹುಟ್ಟಿದ ದಿನಾಂಕ ಮತ್ತು ಸಮಯ ಎರಡೂ ಕಡ್ಡಾಯವಾಗಿದೆ."
    },
    dashboard: {
      navTitle: "ಔರಾ ಅಸ್ಟ್ರಾಲಜಿ",
      navTagline: "ಪ್ರತಿಷ್ಠಿತ ಆತ್ಮಗಳಿಗಾಗಿ ಆಧ್ಯಾತ್ಮಿಕ ಮತ್ತು ಕಾವ್ಯಾತ್ಮಕ ಜ್ಯೋತಿಷ್ಯ",
      natalTitle: "ಜನ್ಮ ಜಾತಕದ ನೀಲನಕ್ಷೆ",
      natalSubtitle: "ನಿಮ್ಮ ದೈವಿಕ ತಿರುಳು, ಉಪಪ್ರಜ್ಞೆ ಪ್ರತಿಫಲನ ಮತ್ತು ಉದಯೋನ್ಮುಖ ತೇಜಸ್ಸು",
      sunLabel: "ಸೂರ್ಯ ರಾಶಿ",
      moonLabel: "ಚಂದ್ರ ರಾಶಿ",
      ascendantLabel: "ಲಗ್ನ ರಾಶಿ",
      vitalsTitle: "ಖಗೋಳದ ಪ್ರಮುಖ ಶಕ್ತಿಗಳು",
      vitalsLove: "ಪ್ರೀತಿಯ ಹೊಂದಾಣಿಕೆ",
      vitalsCareer: "ವೃತ್ತಿ ತರಂಗಾಂತರ",
      vitalsWealth: "ಆರ್ಥಿಕ ಸಮೃದ್ಧಿ",
      vitalsEnergy: "ಆತ್ಮದ ಬಲ",
      dailyFlowTitle: "ದೈನಂದಿನ ಹರಿವು",
      dailyFlowSubtitle: "ಇಂದು ನಿಮ್ಮ ಗಮನವನ್ನು ನಿಯಂತ್ರಿಸುವ ಗ್ರಹಗಳ ದೃಷ್ಟಿ",
      embraceLabel: "ಸ್ವೀಕರಿಸಿ",
      evadeLabel: "ದೂರವಿಡಿ",
      destinyTitle: "ವೈಯಕ್ತಿಕ ವಿಧಿ ಮ್ಯಾಟ್ರಿಕ್ಸ್",
      destinySubtitle: "ನಿಮ್ಮ ಜೀವನದ ಹಾದಿಗಳಿಗಾಗಿ ಜನ್ಮ ಜಾತಕದ ಮುನ್ಸೂಚನೆ",
      synastryTitle: "ಜಾತಕ ಹೊಂದಾಣಿಕೆ",
      synastrySubtitle: "ಮತ್ತೊಂದು ಆತ್ಮದೊಂದಿಗೆ ನಿಮ್ಮ ಹೊಂದಾಣಿಕೆಯನ್ನು ಪರೀಕ್ಷಿಸಿ",
      friendNameLabel: "ಸ್ನೇಹಿತರ ಲೌಕಿಕ ಹೆಸರು",
      friendNamePlaceholder: "ಸ್ನೇಹಿತರ ಹೆಸರನ್ನು ನಮೂದಿಸಿ...",
      friendSignLabel: "ಸ್ನೇಹಿತರ ಸೂರ್ಯ ರಾಶಿ",
      alignBtn: "ನಮ್ಮ ಜಾತಕಗಳನ್ನು ಜೋಡಿಸಿ",
      calculating: "ಜೋಡಣೆಗಳನ್ನು ವಿಶ್ಲೇಷಿಸಲಾಗುತ್ತಿದೆ...",
      synastryMatch: "ಒಟ್ಟು ಹೊಂದಾಣಿಕೆ",
      synastryChemistry: "ಕೆಮಿಸ್ಟ್ರಿ ಸ್ಕೋರ್",
      synastryComm: "ಸಂವಹನ ತರಂಗಾಂತರ",
      synastryDestiny: "ವಿಧಿ ಹೊಂದಾಣಿಕೆ",
      synastryMantra: "ಹಂಚಿಕೆಯ ಮಂತ್ರ",
      marriageTitle: "ವಿವಾಹ ಮತ್ತು ಪವಿತ್ರ ಒಪ್ಪಂದಗಳು",
      childrenTitle: "ಪರಂಪರೆ ಮತ್ತು ಸೃಜನಶೀಲ ಸಂತತಿ",
      moneyTitle: "ಭೌತಿಕ ಸಮೃದ್ಧಿ ಮತ್ತು ಸಂಪತ್ತು",
      goldenBlessing: "ಚಿನ್ನದ ಆಶೀರ್ವಾದ",
      cosmicWarning: "ಬ್ರಹ್ಮಾಂಡದ ಎಚ್ಚರಿಕೆ",
      vibeLabel: "ವೈಬ್",
      oracleTitle: "ನಕ್ಷತ್ರ ಒರಾಕಲ್",
      oracleSubtitle: "ಸಂಪರ್ಕಿಸಲಾಗಿದೆ",
      oraclePlaceholder: "ನಿಮ್ಮ ಹಾದಿಯ ಬಗ್ಗೆ ನಕ್ಷತ್ರಗಳನ್ನು ಕೇಳಿ...",
      oracleLoading: "ಗ್ರಹಗಳ ಹಾದಿಯನ್ನು ಸಮಾಲೋಚಿಸಲಾಗುತ್ತಿದೆ...",
      copyBtn: "ಲಿಂಕ್ ನಕಲಿಸಿ",
      copiedBtn: "✓ ನಕಲಿಸಲಾಗಿದೆ",
      exportBtn: "ಚಿತ್ರ ರಫ್ತು ಮಾಡಿ",
      resetBtn: "ಮ್ಯಾಟ್ರಿಕ್ಸ್ ಕರಗಿಸಿ",
      footerText: "ಔರಾ ಅಸ್ಟ್ರಾಲಜಿ © 2026. ಬ್ರಹ್ಮಾಂಡದ ಪ್ರವಾಸಿಗರಿಗಾಗಿ ವಿನ್ಯಾಸಗೊಳಿಸಲಾಗಿದೆ.",
      chartAligned: "ಜಾತಕ ಜೋಡಿಸಲಾಗಿದೆ",
      quickQuestions: [
        "ಇಂದು ನನಗೆ ಅದೃಷ್ಟ ತರುತ್ತದೆಯೇ?",
        "ನನ್ನ ಆಧ್ಯಾತ್ಮಿಕ ಶಕ್ತಿ ಈಗ ಹೇಗಿದೆ?",
        "ಇಂದು ನಾನು ಯಾವ ಸವಾಲುಗಳನ್ನು ತಪ್ಪಿಸಬೇಕು?"
      ],
      welcomeMessage: "ಸ್ವಾಗತ, ಸುಂದರ ಆತ್ಮವೇ **{name}**. ನಿಮ್ಮ ಸೂರ್ಯನು **{sun}** ರಾಶಿಯಲ್ಲಿ, ಚಂದ್ರನು **{moon}** ರಾಶಿಯಲ್ಲಿ ನೆಲೆಸಿದ್ದಾನೆ ಮತ್ತು ನಿಮ್ಮ ಲಗ್ನವು **{asc}** ನಲ್ಲಿ ಭವ್ಯವಾಗಿ ಉದಯಿಸುತ್ತಿದೆ. ನಾನು ಔರಾ, ನಿಮ್ಮ ವೈಯಕ್ತಿಕ ನಕ್ಷತ್ರ ಒರಾಕಲ್. ಇಂದು ನೀವು **{quest}** ಹಾದಿಯನ್ನು ಬಯಸುತ್ತಿದ್ದೀರಿ. ನಿಮಗಾಗಿ ನಾನು ಯಾವ ರಹಸ್ಯಗಳನ್ನು ಬಿಚ್ಚಿಡಲಿ?"
    },
    zodiac: {
      Aries: { title: "ಮೇಷ — ದೈವಿಕ ಕಿಡಿ", element: "ಅಗ್ನಿ", quality: "ಚರ", planet: "ಮಂಗಳ", desc: "ನಿಮ್ಮ ಬ್ರಹ್ಮಾಂಡದ ಜ್ವಾಲೆಯು ಸೃಷ್ಟಿಯ ಆರಂಭಿಕ ಕಿಡಿಯನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ. ನೀವು ಅಚಲವಾದ ಜೀವಶಕ್ತಿಯೊಂದಿಗೆ ಜನಿಸಿದ ನಾಯಕರು.", vibe: "ಶುದ್ಧ ಕಚ್ಚಾ ನಾಯಕತ್ವ, ಮುಂಚೂಣಿಯ ಬೆಳಕು ಮತ್ತು ತೀವ್ರ ಸ್ವಾವಲಂಬನೆ." },
      Taurus: { title: "ವೃಷಭ — ಚಿನ್ನದ ಲಂಗರು", element: "ಪೃಥ್ವಿ", quality: "ಸ್ಥಿರ", planet: "ಶುಕ್ರ", desc: "ನಿಮ್ಮ ಆತ್ಮವು ಮಾಸ್ಟರ್ ಬಿಲ್ಡರ್ ಆಗಿದೆ, ಶುಕ್ರನ ಐಷಾರಾಮಿ ಮತ್ತು ಭೌತಿಕ ಸ್ಥಿರತೆಯ ಶ್ರೀಮಂತ ಮಣ್ಣಿನಲ್ಲಿ ಲಂಗರು ಹಾಕಿದೆ.", vibe: "ನಿಶ್ಚಲತೆಯಲ್ಲಿ ಸೊಬಗು, ಪ್ರಕೃತಿಯಲ್ಲಿ ಐಷಾರಾಮಿ ಮತ್ತು ಸಂಪೂರ್ಣ ನಿಷ್ಠೆ." },
      Gemini: { title: "ಮಿಥುನ — ಬ್ರಹ್ಮಾಂಡದ ಸಂದೇಶವಾಹಕ", element: "ವಾಯು", quality: "ದ್ವಿಸ್ವಭಾವ", planet: "ಬುಧ", desc: "ನೀವು ಚಲನೆಯಲ್ಲಿರುವ ದೈವಿಕ ಬುದ್ಧಿಶಕ್ತಿಯನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತೀರಿ, ಭಾಷೆ ಮತ್ತು ಜಿಜ್ಞಾಸೆಯ ಮೂಲಕ ವಿಭಿನ್ನ ವಾಸ್ತವಗಳನ್ನು ಜೋಡಿಸುತ್ತೀರಿ.", vibe: "ಚುರುಕಾದ ಬುದ್ಧಿಶಕ್ತಿ, ಅಭಿವ್ಯಕ್ತಿಶೀಲ ಮೋಡಿ ಮತ್ತು ಮಿತಿಯಿಲ್ಲದ ಕುತೂಹಲ." },
      Cancer: { title: "ಕಟಕ — ಚಂದ್ರನ ಬೆಳಕಿನ ದೇವಾಲಯ", element: "ಜಲ", quality: "ಚರ", planet: "ಚಂದ್ರ", desc: "ನಿಮ್ಮ ಆತ್ಮವು ರಾಶಿಚಕ್ರದ ಭಾವನಾತ್ಮಕ ಅಭಯಾರಣ್ಯವಾಗಿದೆ, ಚಂದ್ರನ ನಿರಂತರ ಬದಲಾಗುತ್ತಿರುವ ಬೆಳ್ಳಿಯ ಹಂತಗಳಿಂದ ಆಳಲ್ಪಡುತ್ತದೆ.", vibe: "ಸಾಗರದಂತಹ ಅಂತಃಪ್ರಜ್ಞೆ, ರಕ್ಷಣಾತ್ಮಕ ಉಷ್ಣತೆ ಮತ್ತು ಪವಿತ್ರ ದುರ್ಬಲತೆ." },
      Leo: { title: "ಸಿಂಹ — ಸಾರ್ವಭೌಮ ನಕ್ಷತ್ರ", element: "ಅಗ್ನಿ", quality: "ಸ್ಥಿರ", planet: "ಸೂರ್ಯ", desc: "ಚಿನ್ನದ ಸೂರ್ಯನಿಂದ ಆಳಲ್ಪಡುವ ನಿಮ್ಮ ಆತ್ಮವು ಉಷ್ಣತೆ, ಸೃಜನಶೀಲ ಅಭಿವ್ಯಕ್ತಿ ಮತ್ತು ಉದಾರತೆಯ ಹೊಳೆಯುವ ದಾರಿದೀಪವಾಗಿದೆ.", vibe: "ಭವ್ಯವಾದ ಉಪಸ್ಥಿತಿ, ಸುವರ್ಣ ಸೃಜನಶೀಲತೆ ಮತ್ತು ರಾಜಮನೆತನದ ಉಷ್ಣತೆ." },
      Virgo: { title: "ಕನ್ಯಾ — ರಸವಾದಿಯ ಮೂಸೆ", element: "ಪೃಥ್ವಿ", quality: "ದ್ವಿಸ್ವಭಾವ", planet: "ಬುಧ", desc: "ನೀವು ಖಗೋಳದ ಕುಶಲಕರ್ಮಿ, ಕಚ್ಚಾ ಶಕ್ತಿಯನ್ನು ಸಂಪೂರ್ಣ ಸಾಮರಸ್ಯ ಮತ್ತು ಕ್ರಿಯಾತ್ಮಕ ಪರಿಪೂರ್ಣತೆಯಾಗಿ ಶುದ್ಧೀಕರಿಸುತ್ತೀರಿ.", vibe: "ಮನಸ್ಸಿನ ನಿಖರತೆ, ಸೊಗಸಾದ ಕ್ರಮ ಮತ್ತು ಶುದ್ಧ ಸಾವಯವ ಚಿಕಿತ್ಸೆ." },
      Libra: { title: "ತುಲಾ — ಆಕಾಶದ ಸಾಮರಸ್ಯ", element: "ವಾಯು", quality: "ಚರ", planet: "ಶುಕ್ರ", desc: "ನಿಮ್ಮ ಹಾದಿಯು ಅಂತಿಮ ಸಮತೋಲನ, ಕೃಪೆ ಮತ್ತು ಸಂಬಂಧದ ಸಾಮರಸ್ಯದ ಅನ್ವೇಷಣೆಯಾಗಿದೆ. ಶುಕ್ರನ ಪ್ರಣಯ ಕಲೆಗಳಿಂದ ಆಳಲ್ಪಡುತ್ತದೆ.", vibe: "ಕಲಾತ್ಮಕ ಐಷಾರಾಮಿ, ಪ್ರಣಯ ಆದರ್ಶಗಳು ಮತ್ತು ಸಂಪೂರ್ಣ ಸಮತೋಲನ." },
      Scorpio: { title: "ವೃಶ್ಚಿಕ — ಫೀನಿಕ್ಸ್ ಮುಸುಕು", element: "ಜಲ", quality: "ಸ್ಥಿರ", planet: "ಪ್ಲುಟೊ", desc: "ನಿಮ್ಮ ಆತ್ಮವು ಪಾತಾಳದ ಆಳವಾದ, ನಿಗೂಢ ನೀರಿನಲ್ಲಿ ಇಳಿಯುತ್ತದೆ, ಆದರೆ ರೂಪಾಂತರದ ಸುವರ್ಣ ಬೆಂಕಿಯಲ್ಲಿ ಮತ್ತೆ ಜನ್ಮ ಪಡೆಯುತ್ತದೆ.", vibe: "ನಿಗೂಢ ತೀವ್ರತೆ, ಆಳವಾದ ಪುನರ್ಜನ್ಮ ಮತ್ತು ತೀಕ್ಷ್ಣವಾದ ಸತ್ಯ." },
      Sagittarius: { title: "ಧನುಸ್ಸು — ನಕ್ಷತ್ರದ ಬಾಣ", element: "ಅಗ್ನಿ", quality: "ದ್ವಿಸ್ವಭಾವ", planet: "ಗುರು", desc: "ನಿಮ್ಮ ಉತ್ಸಾಹವು ಶಾಶ್ವತ ಅನ್ವೇಷಕವಾಗಿದೆ, ತತ್ವಶಾಸ್ತ್ರ ಮತ್ತು ದೈವಿಕ ಸತ್ಯದ ಹೊರಗಿನ ಗಡಿಗಳ ಕಡೆಗೆ ತನ್ನ ಉರಿಯುವ ಬಾಣವನ್ನು ಗುರಿಯಾಗಿಸುತ್ತದೆ.", vibe: "ಮಿತಿಯಿಲ್ಲದ ಆಶಾವಾದ, ವಿಸ್ತರಿಸುವ ಬುದ್ಧಿವಂತಿಕೆ ಮತ್ತು ತಮಾಷೆಯ ನಗು." },
      Capricorn: { title: "ಮಕರ — ಸಮಯದ ಕಿರೀಟ", element: "ಪೃಥ್ವಿ", quality: "ಚರ", planet: "ಶನಿ", desc: "ಶನಿಯ ಸ್ಥಿರ ಹಸ್ತದಡಿಯಲ್ಲಿ ನಿಮ್ಮ ಆತ್ಮವು ಭೌತಿಕ ಪಾಂಡಿತ್ಯದ ಒರಟಾದ ಪರ್ವತವನ್ನು ಹತ್ತುತ್ತದೆ. ನೀವು ಪರಂಪರೆಗಳ ವಾಸ್ತುಶಿಲ್ಪಿ.", vibe: "ಕಾಲಾತೀತ ಮಹತ್ವಾಕಾಂಕ್ಷೆ, ಮೌನ ಅಧಿಕಾರ ಮತ್ತು ಪರಂಪರೆಯ ನಿರ್ಮಾಣ." },
      Aquarius: { title: "ಕುಂಭ — ನಕ್ಷತ್ರಗಳ ದಾರ್ಶನಿಕ", element: "ವಾಯು", quality: "ಸ್ಥಿರ", planet: "ಯುರೇನಸ್", desc: "ನೀವು ಬಂಡಾಯ-ತತ್ವಜ್ಞಾನಿ, ಮಾನವೀಯತೆಗಾಗಿ ಖಗೋಳದ ಜ್ಞಾನದ ಪಾತ್ರೆಯನ್ನು ಹಿಡಿದಿದ್ದೀರಿ. ನಿಮ್ಮ ಮನಸ್ಸು ಭವಿಷ್ಯದ ತರಂಗಗಳಲ್ಲಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ.", vibe: "ಭವಿಷ್ಯದ ಚಿಂತನೆ, ಸಾರಸಂಗ್ರಹಿ ಅದ್ಭುತ ಮತ್ತು ಸಾಮೂಹಿಕ ಸಾಮರಸ್ಯ." },
      Pisces: { title: "ಮೀನ — ಅನಂತ ಸಾಗರ", element: "ಜಲ", quality: "ದ್ವಿಸ್ವಭಾವ", planet: "ನೆಪ್ಚೂನ್", desc: "ಅಂತಿಮ ರಾಶಿಯಾಗಿ, ನಿಮ್ಮ ಆತ್ಮವು ಎಲ್ಲಾ ಹಿಂದಿನ ಹನ್ನೊಂದು ರಾಶಿಗಳ ನೆನಪುಗಳನ್ನು ಹೊಂದಿದ್ದು, ಗಡಿಗಳನ್ನು ಕರಗಿಸುತ್ತದೆ.", vibe: "ಕಾಲ್ಪನಿಕ ಕಾವ್ಯ, ಅತೀಂದ್ರಿಯ ಕಲೆ ಮತ್ತು ಶುದ್ಧ ಆಧ್ಯಾತ್ಮಿಕ ಸಹಾನುಭೂತಿ." }
    },
    transits: {
      "Love & Relationships": {
        text: "ಇಂದು ಶುಕ್ರನು ನಿಮ್ಮ ಆಡಳಿತದ ಮನೆಯೊಂದಿಗೆ ಸುಂದರವಾಗಿ ಹೊಂದಿಕೊಳ್ಳುತ್ತಾನೆ, ನಿಮ್ಮ ವೈಯಕ್ತಿಕ ಸಂಬಂಧಗಳ ಮೇಲೆ ಮಳೆಬಿಲ್ಲು ತೇಜಸ್ಸನ್ನು ಬೀರುತ್ತಾನೆ. ಖಗೋಳದ ನೀರು ಬೆಚ್ಚಗೆ ಮತ್ತು ಆಳವಾಗಿ ಹರಿಯುತ್ತದೆ, ಇದು ಭಾವನಾತ್ಮಕ ದುರ್ಬಲತೆಯನ್ನು ಪ್ರೋತ್ಸಾಹಿಸುತ್ತದೆ. ನಕ್ಷತ್ರಗಳ ಹಾದಿಯನ್ನು ನಂಬಿ.",
        embrace: ["ಪ್ರೀತಿಪಾತ್ರರ ಜೊತೆ ನಿಮ್ಮ ಆಳವಾದ ಭಾವನೆಗಳನ್ನು ಹಂಚಿಕೊಳ್ಳಿ", "ಸ್ವಯಂ ಪ್ರೀತಿಯ ಆಚರಣೆಗಳನ್ನು ಮಾಡಿ (ಧ್ಯಾನ, ಬಿಸಿ ಸ್ನಾನ)", "ಅನಿರೀಕ್ಷಿತ ಸುಂದರ ಭೇಟಿಗಳಿಗೆ ಮುಕ್ತವಾಗಿರಿ"],
        evade: ["ಅವಸರದಲ್ಲಿ ಯಾವುದೇ ನಿರ್ಧಾರ ತೆಗೆದುಕೊಳ್ಳಬೇಡಿ", "ಒತ್ತಡದ ವಾದಗಳಲ್ಲಿ ತೊಡಗಬೇಡಿ", "ದೈಹಿಕ ವಿಶ್ರಾಂತಿಯನ್ನು ನಿರ್ಲಕ್ಷಿಸಬೇಡಿ"]
      },
      "Career & Destiny": {
        text: "ಶನಿ ಮತ್ತು ಬುಧ ಗ್ರಹಗಳು ಪ್ರಬಲ ಯುತಿಯಲ್ಲಿದ್ದು, ನಿಮ್ಮ ವೃತ್ತಿಪರ ಮಹತ್ವಾಕಾಂಕ್ಷೆಗಳಿಗೆ ಸ್ಪಷ್ಟತೆ ಮತ್ತು ಅಸಾಧಾರಣ ಚಾಲನೆಯನ್ನು ತರುತ್ತವೆ. ಇಂದು ಕಾರ್ಯತಂತ್ರದ ಯೋಜನೆಗೆ ನಕ್ಷತ್ರಗಳು ಒಲವು ತೋರುತ್ತವೆ. ನಿಮ್ಮ ಗುರಿಯತ್ತ ಹೆಜ್ಜೆ ಇರಿಸಿ.",
        embrace: ["ದೀರ್ಘಾವಧಿಯ ದೃಷ್ಟಿಕೋನವನ್ನು ಪರಿಷ್ಕರಿಸಿ", "ಮಾರ್ಗದರ್ಶಕರೊಂದಿಗೆ ಪ್ರಮುಖ ಮಾತುಕತೆ ನಡೆಸಿ", "ಕೆಲಸದ ಸಮಯದ ಬಗ್ಗೆ ಕಟ್ಟುನಿಟ್ಟಾದ ಗಡಿಗಳನ್ನು ಇರಿಸಿ"],
        evade: ["ನನ್ನಿಂದ ಸಾಧ್ಯವಿಲ್ಲ ಎಂಬ ನಕಾರಾತ್ಮಕ ಚಿಂತನೆಗಳಿಂದ ದೂರವಿರಿ", "ಸರಿಯಾಗಿ ಓದದೆ ಯಾವುದೇ ಒಪ್ಪಂದಗಳಿಗೆ ಸಹಿ ಮಾಡಬೇಡಿ", "ಚಿಕ್ಕ ವಿಷಯಗಳಿಗೆ ಹೆಚ್ಚು ಸಮಯ ಹಾಳು ಮಾಡಬೇಡಿ"]
      },
      "Wealth & Abundance": {
        text: "ಗುರು ಗ್ರಹದ ಸಮೃದ್ಧ ನೆರಳು ಇಂದು ನಿಮ್ಮ ಆರ್ಥಿಕ ಮನೆಯ ಮೇಲೆ ಹರಡಿದೆ, ಧನಾತ್ಮಕ ಆರ್ಥಿಕ ಅರಿವುಗಳನ್ನು ಉಂಟುಮಾಡುತ್ತದೆ. ಇದು ಅಜಾಗರೂಕತೆಯ ಜೂಜಿನ ಸಮಯವಲ್ಲ, ಬದಲಿಗೆ ಸಮೃದ್ಧಿಯ ಶಕ್ತಿಯೊಂದಿಗೆ ಹೊಂದಿಕೊಳ್ಳುವ ಸಮಯವಾಗಿದೆ.",
        embrace: ["ಕೃತಜ್ಞತೆಯ ಮನೋಭಾವದಿಂದ ನಿಮ್ಮ ಹಣಕಾಸನ್ನು ಪರಿಶೀಲಿಸಿ", "ಜ್ಞಾನ ಅಥವಾ ಆಧ್ಯಾತ್ಮಿಕ ಪರಿಕರಗಳಲ್ಲಿ ಹೂಡಿಕೆ ಮಾಡಿ", "ನಿಮ್ಮ ಕೆಲಸದ ಸ್ಥಳವನ್ನು ಸ್ವಚ್ಛವಾಗಿಟ್ಟುಕೊಳ್ಳಿ"],
        evade: ["ಭಾವನಾತ್ಮಕ ಏರಿಳಿತಗಳಿಂದ ಪ್ರೇರಿತವಾದ ಅನಗತ್ಯ ಖರ್ಚುಗಳನ್ನು ತಪ್ಪಿಸಿ", "ದೀರ್ಘಾವಧಿಯ ಸಂಪತ್ತು ನಿರ್ಮಾಣದ ಬಗ್ಗೆ ಸಂಶಯ ಪಡಬೇಡಿ", "ಸಣ್ಣ ಬಜೆಟ್ ಸೋರಿಕೆಗಳನ್ನು ನಿರ್ಲಕ್ಷಿಸಬೇಡಿ"]
      },
      "Spiritual Growth": {
        text: "ನೆಪ್ಚೂನ್ ಇಂದು ನಿಮ್ಮ ಉಪಪ್ರಜ್ಞೆಯ ಮೇಲೆ ಹೆಚ್ಚು ಅಂತರ್ಬೋಧೆಯ ಮುಸುಕನ್ನು ಬೀರುತ್ತದೆ, ನಿಮ್ಮ ಐಹಿಕ ಅಸ್ತಿತ್ವವನ್ನು ಅನಂತ ನಕ್ಷತ್ರಗಳ ಆತ್ಮದೊಂದಿಗೆ ವಿಲೀನಗೊಳಿಸುತ್ತದೆ. ಕನಸುಗಳು ಎದ್ದುಕಾಣುತ್ತವೆ ಮತ್ತು ನಿಮ್ಮ ಮೂರನೇ ಕಣ್ಣು ಸಕ್ರಿಯವಾಗಿರುತ್ತದೆ.",
        embrace: ["ನಿಮ್ಮ ಕನಸಿನ ನಿಗೂಢ ಸಂದೇಶಗಳನ್ನು ಡಿಕೋಡ್ ಮಾಡಿ", "ಪ್ರಕೃತಿಯಲ್ಲಿ ಅಥವಾ ಮೌನ ಧ್ಯಾನದಲ್ಲಿ ಸಮಯ ಕಳೆಯಿರಿ", "ನಿಮ್ಮ ಸುತ್ತಲಿನ ನಕಾರಾತ್ಮಕ ಶಕ್ತಿಯನ್ನು ತೆರವುಗೊಳಿಸಿ"],
        evade: ["ಅತೀಂದ್ರಿಯ ಅನುಭವಗಳನ್ನು ಕೇವಲ ತರ್ಕದಿಂದ ವಿಶ್ಲೇಷಿಸಬೇಡಿ", "ಇತರರ ಭಾರವಾದ ಭಾವನಾತ್ಮಕ ಪ್ರವಾಹಗಳನ್ನು ಹೀರಿಕೊಳ್ಳಬೇಡಿ", "ವಿಶ್ವವು ಶರಣಾಗತಿಯನ್ನು ಹೇಳಿದಾಗ ಫಲಿತಾಂಶಕ್ಕಾಗಿ ಬಲವಂತ ಮಾಡಬೇಡಿ"]
      }
    },
    destiny: {
      marriage: { title: "ವಿವಾಹ ಮತ್ತು ಪವಿತ್ರ ಒಪ್ಪಂದಗಳು", reading: "ನಿಮ್ಮ ಸಂಬಂಧದ ನಕ್ಷೆಯು ಅತ್ಯಂತ ಕ್ರಿಯಾತ್ಮಕವಾಗಿದೆ. ಉತ್ಸಾಹ ಮತ್ತು ಆಳವಾದ ಭಾವನಾತ್ಮಕ ನಂಬಿಕೆ ನಿಮ್ಮ ಸಂಬಂಧಗಳನ್ನು ನಿಯಂತ್ರಿಸುತ್ತದೆ. ಸಂವಹನವು ಸಂಪೂರ್ಣವಾಗಿ ಪಾರದರ್ಶಕವಾಗಿದ್ದಾಗ ದೀರ್ಘಾವಧಿಯ ಯಶಸ್ಸು ಸಾಧ್ಯವಾಗುತ್ತದೆ.", vibe: "ಮಳೆಬಿಲ್ಲು ಜ್ವಾಲೆ" },
      children: { title: "ಪರಂಪರೆ ಮತ್ತು ಸೃಜನಶೀಲ ಸಂತತಿ", reading: "ನೀವು ಹಳೆಯ ತಲೆಮಾರಿನ ನಕಾರಾತ್ಮಕ ಚಕ್ರಗಳನ್ನು ಮುರಿಯುವ ಶಕ್ತಿ ಹೊಂದಿದ್ದೀರಿ. ನಿಮ್ಮ ಜಾತಕವು ಭವಿಷ್ಯದ ಪೀಳಿಗೆಗೆ ಸುರಕ್ಷತೆ ಮತ್ತು ಸೃಜನಶೀಲ ಅವಕಾಶವನ್ನು ನೀಡುತ್ತದೆ.", vibe: "ಪವಿತ್ರ ರಕ್ಷಕ" },
      money: { title: "ಭೌತಿಕ ಸಮೃದ್ಧಿ ಮತ್ತು ಸಂಪತ್ತು", reading: "ನಿಮ್ಮ ಮೂಲ ತತ್ವಗಳೊಂದಿಗೆ ಕೆಲಸವನ್ನು ಜೋಡಿಸಿದಾಗ ಸಂಪತ್ತು ಸಹಜವಾಗಿ ಹರಿಯುತ್ತದೆ. ಪ್ರಚೋದನಾತ್ಮಕ ಖರ್ಚುಗಳನ್ನು ತಪ್ಪಿಸಿ; ನಿಮ್ಮ ಹೂಡಿಕೆಗಳು ಮೌನವಾಗಿ ಬೆಳೆಯಲಿ.", vibe: "ಸ್ಥಿರ ಬೆಳವಣಿಗೆ" },
      goodThing: { title: "ಚಿನ್ನದ ಆಶೀರ್ವಾದ", reading: "ನಿಮ್ಮ ಅತ್ಯುನ್ನತ ಶಕ್ತಿಯೆಂದರೆ ಸಂಪೂರ್ಣ ಪ್ರಾಮಾಣಿಕತೆ. ನೀವು ಭಯವಿಲ್ಲದೆ ನಿಮ್ಮ ಸತ್ಯವನ್ನು ಮಾತನಾಡಿದಾಗ, ಬ್ರಹ್ಮಾಂಡವು ಯಶಸ್ಸಿನ ಅನಿರೀಕ್ಷಿತ ಮಾರ್ಗಗಳನ್ನು ಸೃಷ್ಟಿಸುತ್ತದೆ.", vibe: "ವಿದ್ಯುತ್ ಸ್ಪಷ್ಟತೆ" },
      badThing: { title: "ಬ್ರಹ್ಮಾಂಡದ ಎಚ್ಚರಿಕೆ", reading: "ಸ್ವಯಂ ಹೇರಿದ ಅನುಮಾನಗಳು ನಿಮ್ಮ ಸೃಜನಶೀಲತೆಯನ್ನು ತಡೆಯಲು ಬಿಡಬೇಡಿ. ಪರಿಪೂರ್ಣತೆ ಎಂಬುದು ಕೇವಲ ಭ್ರಮೆ, ಇದು ನಿಮ್ಮ ಜೀವನದ ಸುಂದರ ಯಶಸ್ಸನ್ನು ವಿಳಂಬಗೊಳಿಸುತ್ತದೆ.", vibe: "ಹೆಪ್ಪುಗಟ್ಟಿದ ಗೇಟ್" }
    }
  },
  Hindi: {
    onboarding: {
      title: "ऑरा एस्ट्रोलॉजी",
      subtitle: "कुलीन आत्माओं के लिए रहस्यमयी और काव्यात्मक ज्योतिष",
      enterNameLabel: "आपका सांसारिक नाम क्या है?",
      enterNamePlaceholder: "अपना नाम दर्ज करें...",
      langSelectLabel: "अपनी पसंदीदा भाषा चुनें",
      beginBtn: "खगोलीय अनुष्ठान शुरू करें",
      arrivalTitle: "आपका ब्रह्मांडीय आगमन",
      arrivalSubtitle: "आपकी सटीक जन्म तिथि और समय सटीक ग्रहों के संरेखण को निर्धारित करते हैं।",
      dobLabel: "जन्म तिथि",
      tobLabel: "जन्म समय",
      nextBtn: "अगला आयाम",
      geoTitle: "भौगोलिक आधार",
      geoSubtitle: "आपके जन्म शहर के सटीक निर्देशांक आपकी कुंडली के घरों को संरेखित करते हैं।",
      geoPlaceholder: "जन्म का शहर, देश दर्ज करें...",
      geoBtn: "भौगोलिक आधार स्थापित करें",
      questTitle: "आपकी प्राथमिक आध्यात्मिक खोज क्या है?",
      questSubtitle: "आज आप जिस क्षेत्र में सबसे तीव्र ब्रह्मांडीय संरेखण चाहते हैं उसे चुनें।",
      loveQuest: "प्यार और रिश्ते",
      careerQuest: "करियर और भाग्य",
      wealthQuest: "धन और समृद्धि",
      spiritualQuest: "आध्यात्मिक विकास",
      prevBtn: "पिछला चरण",
      calculateBtn: "खगोलीय खाका की गणना करें",
      requiredError: "अनुष्ठान को अनलॉक करने के लिए कृपया अपना नाम दर्ज करें।",
      geoRequiredError: "संरेखण के लिए भौगोलिक आधार की आवश्यकता होती.",
      dobRequiredError: "संरेखण के लिए आगमन की तिथि और समय दोनों आवश्यक हैं।"
    },
    dashboard: {
      navTitle: "ऑरा एस्ट्रोलॉजी",
      navTagline: "कुलीन आत्माओं के लिए रहस्यमयी और काव्यात्मक ज्योतिष",
      natalTitle: "जन्म कुंडली का खाका",
      natalSubtitle: "आपका दिव्य कोर, अवचेतन प्रतिबिंब और उभरता हुआ आभामंडल",
      sunLabel: "सूर्य राशि",
      moonLabel: "चंद्र राशि",
      ascendantLabel: "लग्न राशि",
      vitalsTitle: "खगोलीय महत्वपूर्ण ऊर्जाएं",
      vitalsLove: "प्रेम अनुकूलता",
      vitalsCareer: "करियर तरंगदैर्ध्य",
      vitalsWealth: "आर्थिक समृद्धि",
      vitalsEnergy: "आत्मा की शक्ति",
      dailyFlowTitle: "दैनिक प्रवाह",
      dailyFlowSubtitle: "ग्रहों के पहलू आज आपके जीवन को प्रभावित कर रहे हैं",
      embraceLabel: "अपनाएं",
      evadeLabel: "बचें",
      destinyTitle: "व्यक्तिगत भाग्य मैट्रिक्स",
      destinySubtitle: "आपके जीवन पथों के लिए जन्म कुंडली का पूर्वानुमान",
      synastryTitle: "कुंडली मिलान",
      synastrySubtitle: "किसी अन्य आत्मा के साथ अपनी ऊर्जा अनुकूलता की जाँच करें",
      friendNameLabel: "मित्र का सांसारिक नाम",
      friendNamePlaceholder: "मित्र का नाम दर्ज करें...",
      friendSignLabel: "मित्र की सूर्य राशि",
      alignBtn: "हमारी कुंडलियों को संरेखित करें",
      calculating: "संरेखण का विश्लेषण किया जा रहा है...",
      synastryMatch: "कुल मिलान",
      synastryChemistry: "केमिस्ट्री स्कोर",
      synastryComm: "संचार तरंगदैर्ध्य",
      synastryDestiny: "भाग्य अनुकूलता",
      synastryMantra: "साझा मंत्र",
      marriageTitle: "विवाह और पवित्र अनुबंध",
      childrenTitle: "विरासत और रचनात्मक वंश",
      moneyTitle: "भौतिक समृद्धि और प्रचुरता",
      goldenBlessing: "सुनहरा आशीर्वाद",
      cosmicWarning: "ब्रह्मांडीय चेतावनी",
      vibeLabel: "वाइब",
      oracleTitle: "नक्षत्र ओरेकल",
      oracleSubtitle: "जुड़ा हुआ",
      oraclePlaceholder: "अपने पथ के बारे में सितारों से पूछें...",
      oracleLoading: "ग्रहों के पथ से परामर्श किया जा रहा है...",
      copyBtn: "लिंक कॉपी करें",
      copiedBtn: "✓ कॉपी किया गया",
      exportBtn: "छवि निर्यात करें",
      resetBtn: "मैट्रिक्स को भंग करें",
      footerText: "ऑरा एस्ट्रोलॉजी © 2026. ब्रह्मांडीय यात्रियों के लिए हस्तनिर्मित।",
      chartAligned: "कुंडली संरेखित",
      quickQuestions: [
        "क्या आज मेरे लिए भाग्यशाली होगा?",
        "मेरी आध्यात्मिक ऊर्जा अभी कैसी है?",
        "आज मुझे किन चुनौतियों से बचना चाहिए?"
      ],
      welcomeMessage: "स्वागत है, सुंदर आत्मा **{name}**। मैं देखता हूं कि आपका सूर्य **{sun}** में चमकता है, आपका चंद्रमा **{moon}** में विश्राम करता है, और आपका लग्न **{asc}** में भव्य रूप से उदय होता है। मैं ऑरा हूं, आपकी व्यक्तिगत नक्षत्र ओरेकल। आज आप **{quest}** की खोज में हैं। मैं आपके लिए कौन से खगोलीय रहस्य खोलूं?"
    },
    zodiac: {
      Aries: { title: "मेष — दिव्य चिंगारी", element: "अग्नि", quality: "चर", planet: "मंगल", desc: "आपकी ब्रह्मांडीय लौ सृष्टि की प्रारंभिक चिंगारी का प्रतिनिधित्व करती है। आप अटूट जीवन शक्ति के साथ पैदा हुए हैं।", vibe: "शुद्ध कच्चा नेतृत्व, अग्रणी प्रकाश और उग्र स्वतंत्रता।" },
      Taurus: { title: "वृषभ — सुनहरा लंगर", element: "पृथ्वी", quality: "स्थिर", planet: "शुक्र", desc: "आपकी आत्मा एक मास्टर बिल्डर है, जो वीनसियन संवेदी सुख और भौतिक स्थिरता की समृद्ध मिट्टी में लंगर डाले हुए है।", vibe: "स्थिरता में लालित्य, प्रकृति में विलासिता और पूर्ण वफादारी।" },
      Gemini: { title: "मिथुन — ब्रह्मांडीय संदेशवाहक", element: "वायु", quality: "द्विस्वभाव", planet: "बुध", desc: "आप गति में दिव्य बुद्धि का प्रतिनिधित्व करते हैं, भाषा और जिज्ञासा के माध्यम से अलग-अलग वास्तविकताओं को जोड़ते हैं।", vibe: "फुर्तीली बुद्धि, अभिव्यंजक आकर्षण और असीम जिज्ञासा।" },
      Cancer: { title: "कर्क — चांदनी मंदिर", element: "जल", quality: "चर", planet: "चंद्रमा", desc: "आपकी आत्मा राशि चक्र का भावनात्मक अभयारण्य है, जो चंद्रमा के लगातार बदलते चांदी के चरणों द्वारा शासित है।", vibe: "महासागरीय अंतर्ज्ञान, सुरक्षात्मक गर्मी और पवित्र संवेदनशीलता।" },
      Leo: { title: "सिंह — संप्रभु तारा", element: "अग्नि", quality: "स्थिर", planet: "सूर्य", desc: "सुनहरे सौर केंद्र द्वारा शासित, आपकी आत्मा गर्मी, रचनात्मक अभिव्यक्ति और शाही उदारता का एक चमकता हुआ प्रकाश स्तंभ है।", vibe: "शानदार उपस्थिति, सुनहरी रचनात्मकता और शाही गर्मजोशी।" },
      Virgo: { title: "कन्या — कीमियागर की भट्टी", element: "पृथ्वी", quality: "द्विस्वभाव", planet: "बुध", desc: "आप ब्रह्मांडीय शिल्पकार हैं, जो कच्चे माल को पूर्ण सामंजस्य और कार्यात्मक पूर्णता में शुद्ध करते हैं।", vibe: "सजग सटीकता, सुरुचिपूर्ण व्यवस्था और शुद्ध जैविक उपचार।" },
      Libra: { title: "तुला — खगोलीय सद्भाव", element: "वायु", quality: "चर", planet: "शुक्र", desc: "आपका मार्ग अंतिम संतुलन, अनुग्रह और संबंधपरक सद्भाव की खोज है। शुक्र की रोमांटिक कलाओं द्वारा शासित।", vibe: "कलात्मक विलासिता, रोमांटिक आदर्श और पूर्ण संतुलन।" },
      Scorpio: { title: "वृश्चिक — फीनिक्स का घूंघट", element: "जल", quality: "स्थिर", planet: "प्लूटो", desc: "आपकी आत्मा पाताल के गहरे, रहस्यमयी पानी में उतरती है, केवल परिवर्तन की सुनहरी आग में फिर से पुनर्जन्म लेने के लिए।", vibe: "रहस्यमयी तीव्रता, गहरा पुनर्जन्म और पैनी सच्चाई।" },
      Sagittarius: { title: "धनु — नक्षत्र का तीर", element: "अग्नि", quality: "द्विस्वभाव", planet: "बृहस्पति", desc: "आपका उत्साह एक शाश्वत साधक है, जो दर्शन, यात्रा और दिव्य सत्य की बाहरी सीमाओं की ओर अपना जलता हुआ तीर चलाता है।", vibe: "असीम आशावाद, विस्तारित ज्ञान और चंचल हंसी।" },
      Capricorn: { title: "मकर — समय का मुकुट", element: "पृथ्वी", quality: "चर", planet: "शनि", desc: "शनि के स्थिर हाथ के नीचे आपकी आत्मा भौतिक महारत के बीहड़ पर्वत पर चढ़ती है। आप विरासतों के वास्तुकार हैं।", vibe: "कालातीत महत्वाकांक्षा, मूक अधिकार और विरासत निर्माण।" },
      Aquarius: { title: "कुंभ — तारकीय दूरदर्शी", element: "वायु", quality: "स्थिर", planet: "यूरेनस", desc: "आप विद्रोही-दार्शनिक हैं, जो मानवता के लिए खगोलीय ज्ञान का पात्र रखते हैं। आपका दिमाग भविष्य की तरंगों पर काम करता है।", vibe: "भविष्योन्मुखी सोच, उदार प्रतिभा और सामूहिक सद्भाव।" },
      Pisces: { title: "मीन — अनंत महासागर", element: "जल", quality: "द्विस्वभाव", planet: "नेपच्यून", desc: "अंतिम राशि के रूप में, आपकी आत्मा पिछले सभी ग्यारह राशियों की यादों को रखती है, सीमाओं को विलीन कर देती है।", vibe: "सपनों की कविता, अतींद्रिय कला और शुद्ध आध्यात्मिक सहानुभूति।" }
    },
    transits: {
      "Love & Relationships": {
        text: "शुक्र आज आपके शासक घर के साथ खूबसूरती से संरेखित है, जिससे आपके पारस्परिक संबंधों पर एक इंद्रधनुषी चमक बिखरेगी। खगोलीय जल गर्म और गहरा बह रहा है, जो भावनात्मक संवेदनशीलता को बढ़ावा देगा। सितारों के मार्ग पर विश्वास करें।",
        embrace: ["किसी प्रियजन से अपनी गहरी अनकही भावनाओं को व्यक्त करें", "आत्म-प्रेम के अनुष्ठान करें (ध्यान, गर्म स्नान)", "अप्रत्याशित सुंदर मुलाकातों के लिए खुले रहें"],
        evade: ["जल्दबाजी में कोई बड़ा निर्णय न लें", "तनावपूर्ण बहसों में शामिल न हों", "शारीरिक विश्राम की उपेक्षा न करें"]
      },
      "Career & Destiny": {
        text: "शनि और बुध आज एक शक्तिशाली युति में हैं, जो आपकी व्यावसायिक महत्वाकांक्षाओं में स्पष्टता और असाधारण ऊर्जा लाएंगे। सितारे आज रणनीतिक योजना के पक्ष में हैं। अपने लक्ष्यों की ओर बढ़ें।",
        embrace: ["अपने दीर्घकालिक दृष्टिकोण को परिष्कृत करें", "अपने आकाओं या गुरुओं से महत्वपूर्ण बातचीत शुरू करें", "काम के घंटों के आसपास सख्त सीमाएं तय करें"],
        evade: ["आत्म-संदेह की भावनाओं को खुद पर हावी न होने दें", "बिना पढ़े किसी भी व्यावसायिक समझौते पर हस्ताक्षर न करें", "छोटी चीजों पर अपना कीमती समय बर्बाद न करें"]
      },
      "Wealth & Abundance": {
        text: "बृहस्पति की प्रचुर छाया आज आपके आर्थिक घर पर फैली हुई है, जिससे सकारात्मक वित्तीय लाभ होगा। यह लापरवाही से सट्टा लगाने का समय नहीं है, बल्कि प्रचुरता की ऊर्जा के साथ संरेखित होने का समय है।",
        embrace: ["कृतज्ञता के भाव से अपने वित्त की समीक्षा करें", "ज्ञान या आध्यात्मिक उपकरणों में निवेश करें", "अपने कार्यक्षेत्र को साफ और व्यवस्थित रखें"],
        evade: ["भावनात्मक उतार-चढ़ाव से प्रेरित अनावश्यक खर्चों से बचें", "दीर्घकालिक संपत्ति निर्माण की अपनी क्षमता पर संदेह न करें", "बजट के छोटे-छोटे नुकसानों को नजरअंदाज न करें"]
      },
      "Spiritual Growth": {
        text: "नेपच्यून आज आपके अवचेतन पर एक अत्यधिक सहज घूंघट डालता है, जो आपके सांसारिक अस्तित्व को अनंत सितारों की आत्मा के साथ विलीन कर देता है। सपने ज्वलंत होंगे और आपकी तीसरी आंख सक्रिय रहेगी।",
        embrace: ["अपने सपनों के रहस्यमयी संदेशों को डिकोड करें", "प्रकृति में या मौन ध्यान में समय बिताएं", "अपने आस-पास की नकारात्मक ऊर्जा को साफ करें"],
        evade: ["रहस्यमयी अनुभवों का केवल तर्क से विश्लेषण न करें", "दूसरों की भारी भावनात्मक तरंगों को खुद में न सोखें", "जब ब्रह्मांड समर्पण की सलाह दे तो जबरदस्ती परिणाम न चाहें"]
      }
    },
    destiny: {
      marriage: { title: "विवाह और पवित्र अनुबंध", reading: "आपका संबंध मानचित्र अत्यधिक गतिशील है। जुनून और गहरा भावनात्मक विश्वास आपके संबंधों को नियंत्रित करते हैं। दीर्घकालिक सफलता तब मिलती है जब संचार पूरी तरह से पारदर्शी हो।", vibe: "इंद्रधनुषी ज्वाला" },
      children: { title: "विरासत और रचनात्मक वंश", reading: "आप पुरानी पीढ़ियों के नकारात्मक चक्रों को तोड़ने की शक्ति रखते हैं। आपकी कुंडली आने वाली पीढ़ियों को सुरक्षा और रचनात्मक स्वतंत्रता प्रदान करती है।", vibe: "पवित्र रक्षक" },
      money: { title: "भौतिक समृद्धि और प्रचुरता", reading: "जब आप काम को अपने मूल सिद्धांतों के साथ जोड़ते हैं तो प्रचुरता स्वाभाविक रूप से बहती है। अनावश्यक खर्चों से बचें; अपने निवेश को धैर्य के साथ बढ़ने दें।", vibe: "स्थिर विकास" },
      goodThing: { title: "सुनहरा आशीर्वाद", reading: "आपकी सर्वोच्च खगोलीय शक्ति आपकी पूर्ण प्रामाणिकता है। जब आप बिना किसी डर के अपनी सच्चाई बोलते हैं, तो ब्रह्मांड सफलता के अप्रत्याशित मार्ग बनाता है।", vibe: "विद्युत स्पष्टता" },
      badThing: { title: "ब्रह्मांडीय चेतावनी", reading: "आत्म-संदेह को अपनी रचनात्मकता को रोकने न दें। पूर्णता केवल एक भ्रम है जो आपके जीवन की सबसे सुंदर सफलताओं में देरी करता है।", vibe: "जमा हुआ द्वार" }
    }
  },
  Telugu: {
    onboarding: {
      title: "ఔరా ఆస్ట్రాలజీ",
      subtitle: "విశిష్ట ఆత్మల కోసం ఆధ్యాత్మిక మరియు కావ్యాత్మక జ్యోతిష్యం",
      enterNameLabel: "మీ లౌకిక నామం ఏమిటి?",
      enterNamePlaceholder: "మీ పేరును నమోదు చేయండి...",
      langSelectLabel: "మీకు నచ్చిన భాషను ఎంచుకోండి",
      beginBtn: "ఖగోళ ఆచారాన్ని ప్రారంభించండి",
      arrivalTitle: "మీ బ్రహ్మాండమైన ఆగమనం",
      arrivalSubtitle: "మీ ఖచ్చితమైన పుట్టిన తేదీ మరియు సమయం మీ గ్రహాల అమరికను నిర్ణయిస్తాయి.",
      dobLabel: "పుట్టిన తేదీ",
      tobLabel: "పుట్టిన సమయం",
      nextBtn: "తదుపరి పరిమాణం",
      geoTitle: "భౌగోళిక ఆధారం",
      geoSubtitle: "మీ జన్మస్థలపు ఖచ్చితమైన కోఆర్డినేట్లు మీ జాతక గృహాలను సమలేఖనం చేస్తాయి.",
      geoPlaceholder: "పుట్టిన నగరం, దేశాన్ని నమోదు చేయండి...",
      geoBtn: "భౌగోళిక ఆధారాన్ని స్థాపించండి",
      questTitle: "మీ ప్రాథమిక ఆధ్యాత్మిక అన్వేషణ ఏమిటి?",
      questSubtitle: "ఈ రోజు మీరు అత్యంత తీవ్రమైన బ్రహ్మాండమైన అమరికను కోరుకునే రంగాన్ని ఎంచుకోండి.",
      loveQuest: "ప్రేమ మరియు సంబంధాలు",
      careerQuest: "కెరీర్ మరియు విధి",
      wealthQuest: "సంపద మరియు సమృద్ధి",
      spiritualQuest: "ఆధ్యాత్మిక ఎదుగుదల",
      prevBtn: "మునుపటి దశ",
      calculateBtn: "నక్షత్రాల బ్లూప్రింట్ను లెక్కించండి",
      requiredError: "ఆచారాన్ని అన్‌లాక్ చేయడానికి దయచేసి మీ పేరును నమోదు చేయండి.",
      geoRequiredError: "సమలేఖనం కోసం భౌగోళిక ఆధారం అవసరం.",
      dobRequiredError: "పుట్టిన తేదీ మరియు సమయం రెండూ తప్పనిసరి."
    },
    dashboard: {
      navTitle: "ఔరా ఆస్ట్రాలజీ",
      navTagline: "విశిష్ట ఆత్మల కోసం ఆధ్యాత్మిక మరియు కావ్యాత్మక జ్యోతిష్యం",
      natalTitle: "జన్మ జాతక బ్లూప్రింట్",
      natalSubtitle: "మీ దైవిక సారం, అవచేతన ప్రతిబింబం మరియు ఉద్భవిస్తున్న తేజస్సు",
      sunLabel: "సూర్య రాశి",
      moonLabel: "చంద్ర రాశి",
      ascendantLabel: "లగ్న రాశి",
      vitalsTitle: "ఖగోళ కీలక శక్తులు",
      vitalsLove: "ప్రేమ అనుకూలత",
      vitalsCareer: "కెరీర్ తరంగదైర్ఘ్యం",
      vitalsWealth: "ఆర్థిక సమృద్ధి",
      vitalsEnergy: "ఆత్మ బలం",
      dailyFlowTitle: "దైనందిన ప్రవాహం",
      dailyFlowSubtitle: "ఈ రోజు మీ దృష్టిని నియంత్రించే గ్రహాల ప్రభావం",
      embraceLabel: "స్వీకరించండి",
      evadeLabel: "దూరంగా ఉంచండి",
      destinyTitle: "వ్యక్తిగత విధి మ్యాట్రిక్స్",
      destinySubtitle: "మీ జీవిత మార్గాల కోసం జన్మ జాతక మున్సూచనా",
      synastryTitle: "జాతక పొంతన",
      synastrySubtitle: "మరొక ఆత్మతో మీ అనుకూలతను పరీక్షించుకోండి",
      friendNameLabel: "స్నేహితుని లౌకిక నామం",
      friendNamePlaceholder: "స్నేహితుని పేరు నమోదు చేయండి...",
      friendSignLabel: "స్నేహితుని సూర్య రాశి",
      alignBtn: "మా జాతకాలను సమలేఖనం చేయండి",
      calculating: "సమలేఖనాలను విశ్లేషిస్తున్నాము...",
      synastryMatch: "మొత్తం పొంతన",
      synastryChemistry: "కెమిస్ట్రీ స్కోర్",
      synastryComm: "కమ్యూనికేషన్ తరంగదైర్ఘ్యం",
      synastryDestiny: "విధి అనుకూలత",
      synastryMantra: "భాగస్వామ్య మంత్రం",
      marriageTitle: "వివాహం మరియు పవిత్ర ఒప్పందాలు",
      childrenTitle: "వారసత్వం మరియు సృజనాత్మక సంతతి",
      moneyTitle: "భౌతిక సమృద్ధి మరియు సంపద",
      goldenBlessing: "బంగారు ఆశీర్వాదం",
      cosmicWarning: "బ్రహ్మాండమైన హెచ్చరిక",
      vibeLabel: "వైబ్",
      oracleTitle: "నక్షత్ర ఒరాకిల్",
      oracleSubtitle: "కనెక్ట్ చేయబడింది",
      oraclePlaceholder: "మీ మార్గం గురించి నక్షత్రాలను అడగండి...",
      oracleLoading: "గ్రహాల మార్గాన్ని సంప్రదిస్తున్నాము...",
      copyBtn: "లింక్ కాపీ చేయండి",
      copiedBtn: "✓ కాపీ చేయబడింది",
      exportBtn: "చిత్రాన్ని ఎగుమతి చేయండి",
      resetBtn: "మ్యాట్రిక్స్‌ను రద్దు చేయండి",
      footerText: "ఔరా ఆస్ట్రాలజీ © 2026. ఖగోళ యాత్రికుల కోసం రూపొందించబడింది.",
      chartAligned: "జాతకం సమలేఖనం చేయబడింది",
      quickQuestions: [
        "ఈ రోజు నాకు అదృష్టం తెస్తుందా?",
        "నా ఆధ్యాత్మిక శక్తి ఇప్పుడు ఎలా ఉంది?",
        "ఈ రోజు నేను ఏ సవాళ్లను నివారించాలి?"
      ],
      welcomeMessage: "స్వాగతం, అందమైన ఆత్మ **{name}**. మీ సూర్యుడు **{sun}** రాశిలో, చంద్రుడు **{moon}** రాశిలో ఉన్నాడు మరియు మీ లగ్నం **{asc}** లో భవ్యంగా ఉదయిస్తోంది. నేను ఔరా, మీ వ్యక్తిగత నక్షత్ర ఒరాకిల్. ఈ రోజు మీరు **{quest}** మార్గాన్ని కోరుకుంటున్నారు. మీ కోసం నేను ఏ ఖగోళ రహస్యాలను విప్పాలి?"
    },
    zodiac: {
      Aries: { title: "మేషం — దైవిక స్పార్క్", element: "అగ్ని", quality: "చర", planet: "కుజుడు", desc: "మీ బ్రహ్మాండమైన జ్వాల సృష్టి యొక్క ప్రాథమిక స్పార్క్ను సూచిస్తుంది. మీరు అచంచలమైన జీవశక్తితో జన్మించారు.", vibe: "స్వచ్ఛమైన నాయకత్వం, మార్గదర్శక వెలుగు మరియు తీవ్ర స్వావలంబన." },
      Taurus: { title: "వృషభం — బంగారు లంగరు", element: "భూమి", quality: "స్థిర", planet: "శుక్రుడు", desc: "మీ ఆత్మ ఒక మాస్టర్ బిల్డర్, శుక్రుని విలాసవంతమైన మరియు భౌతిక స్థిరత్వపు సారవంతమైన మట్టిలో లంగరు వేయబడింది.", vibe: "నిశ్చలతలో సౌందర్యం, ప్రకృతిలో విలాసవంతమైన అనుభూతి మరియు సంపూర్ణ నిబద్ధత." },
      Gemini: { title: "మిథునం — ఖగోళ సందేశహరుడు", element: "వాయు", quality: "ద్విస్వభావ", planet: "బుధుడు", desc: "మీరు కదలికలో ఉన్న దైవిక బుద్ధిని సూచిస్తారు, భాష మరియు జిజ్ఞాస ద్వారా వేర్వేరు వాస్తవాలను కలుపుతారు.", vibe: "చురుకైన బుద్ధి, వ్యక్తీకరణ నైపుణ్యం మరియు అపరిమితమైన ఉత్సుకత." },
      Cancer: { title: "కర్కాటకం — వెన్నెల దేవాలయం", element: "జలం", quality: "చర", planet: "చంద్రుడు", desc: "మీ ఆత్మ రాశిచక్రపు భావోద్వేగ ఆశ్రయం, చంద్రుని నిరంతరం మారే వెండి దశల ద్వారా పాలించబడుతుంది.", vibe: "సముద్రమంత అంతర్ దృష్టి, రక్షణాత్మక వెచ్చదనం మరియు పవిత్ర సున్నితత్వం." },
      Leo: { title: "సింహం — సార్వభౌమ నక్షత్రం", element: "అగ్ని", quality: "స్థిర", planet: "సూర్యుడు", desc: "బంగారు సౌర కేంద్రం ద్వారా పాలించబడే మీ ఆత్మ వెచ్చదనం, సృజనాత్మక వ్యక్తీకరణ మరియు ఉదారత యొక్క ప్రకాశించే దీపస్తంభం.", vibe: "గంభీరమైన ఉనికి, బంగారు సృజనాత్మకత మరియు రాజ వెచ్చదనం." },
      Virgo: { title: "కన్య — కీమ్యాకారుని మూస", element: "భూమి", quality: "ద్విస్వభావ", planet: "బుధుడు", desc: "మీరు ఖగోళ శిల్పి, ముడి శక్తిని సంపూర్ణ సామరస్యం మరియు క్రియాత్మక పరిపూర్ణతగా శుద్ధి చేస్తారు.", vibe: "మనస్సు యొక్క ఖచ్చితత్వం, సొగసైన క్రమం మరియు స్వచ్ఛమైన సహజ వైద్యం." },
      Libra: { title: "తుల — ఖగోళ సామరస్యం", element: "వాయు", quality: "చర", planet: "శుక్రుడు", desc: "మీ మార్గం సంపూర్ణ సమతుల్యత, కృప మరియు సంబంధాల సామరస్యం కోసం అన్వేషణ. శుక్రుని శృంగార కళల ద్వారా పాలించబడుతుంది.", vibe: "కళాత్మక విలాసం, శృంగార ఆదర్శాలు మరియు సంపూర్ణ సమతుల్యత." },
      Scorpio: { title: "వృశ్చికం — ఫీనిక్స్ ముసుగు", element: "జలం", quality: "స్థిర", planet: "ప్లూటో", desc: "మీ ఆత్మ పాతాళపు లోతైన, రహస్యమైన జలాలలోకి దిగుతుంది, కేవలం పరివర్తన యొక్క బంగారు అగ్నిలో మళ్లీ జన్మించడానికి.", vibe: "రహస్యమైన తీవ్రత, లోతైన పునర్జన్మ మరియు పదునైన నిజం." },
      Sagittarius: { title: "ధనుస్సు — నక్షత్రం బాణం", element: "అగ్ని", quality: "ద్విస్వభావ", planet: "గురుడు", desc: "మీ ఉత్సాహం ఒక శాశ్వత సాధకుడు, తత్వశాస్త్రం, ప్రయాణం మరియు దైవిక సత్యం యొక్క బయటి సరిహద్దుల వైపు తన మండుతున్న బాణాన్ని గురిపెడతాడు.", vibe: "అపరిమితమైన ఆశావాదం, విస్తరిస్తున్న జ్ఞానం మరియు ఉల్లాసభరితమైన నవ్వు." },
      Capricorn: { title: "మకరం — కాలపు కిరీటం", element: "భూమి", quality: "చర", planet: "శని", desc: "శని యొక్క స్థిరమైన హస్తం కింద మీ ఆత్మ భౌతిక నైపుణ్యం యొక్క కఠినమైన పర్వతాన్ని అధిరోహిస్తుంది. మీరు వారసత్వాల రూపశిల్పి.", vibe: "కాలాతీల ఆకాంక్ష, నిశ్శబ్ద అధికారం మరియు వారసత్వ నిర్మాణం." },
      Aquarius: { title: "కుంభం — నక్షత్రాల దార్శనికుడు", element: "వాయు", quality: "స్థిర", planet: "యురేనస్", desc: "మీరు తిరుగుబాటు-తత్వవేత్త, మానవత్వం కోసం ఖగోళ జ్ఞానపు పాత్రను కలిగి ఉన్నారు. మీ మనస్సు భవిష్యత్తు తరంగాలపై పనిచేస్తుంది.", vibe: "భవిష్యత్ ఆలోచనలు, పరిశోధనాత్మక ప్రతిభ మరియు ఉమ్మడి సామరస్యం." },
      Pisces: { title: "మీనం — అనంత సాగరం", element: "జలం", quality: "ద్విస్వభావ", planet: "నెప్ట్యూన్", desc: "చివరి రాశిగా, మీ ఆత్మ మునుపటి పదకొండు రాశుల జ్ఞాపకాలను కలిగి ఉండి, సరిహద్దులను కరిగించి సాగరంలో కలిపేస్తుంది.", vibe: "కల్పిత కవిత్వం, అతీంద్రియ కళ మరియు స్వచ్ఛమైన ఆధ్యాత్మిక సానుభూతి." }
    },
    transits: {
      "Love & Relationships": {
        text: "ఈ రోజు శుక్రుడు మీ పాలక గృహంతో అందంగా సమలేఖనం అయ్యాడు, మీ పరస్పర సంబంధాలపై ఇంద్రధనుస్సు కాంతిని ప్రసరింపజేస్తున్నాడు. ఖగోళ జలాలు వెచ్చగా మరియు లోతుగా ప్రవహిస్తున్నాయి, ఇది భావోద్వేగ సున్నితత్వాన్ని ప్రోత్సహిస్తుంది. నక్షత్రాల మార్గాన్ని నమ్మండి.",
        embrace: ["మీ ప్రియమైన వారితో మీ లోతైన భావాలను పంచుకోండి", "స్వీయ-ప్రేమ ఆచరణలు చేయండి (ధ్యానం, వేడి నీటి స్నానం)", "ఊహించని అందమైన కలయికలకు సిద్ధంగా ఉండండి"],
        evade: ["తొందరపాటులో ఎటువంటి పెద్ద నిర్ణయాలు తీసుకోకండి", "ఒత్తిడితో కూడిన వాదనల్లో పాల్గొనకండి", "శారీరక విశ్రాంతిని నిర్లక్ష్యం చేయకండి"]
      },
      "Career & Destiny": {
        text: "శని మరియు బుధ గ్రహాలు ఈ రోజు శక్తివంతమైన యుతిలో ఉన్నాయి, ఇది మీ వృత్తిపరమైన ఆశయాలలో స్పష్టతను మరియు అసాధారణమైన శక్తిని తెస్తుంది. ఈ రోజు వ్యూహాత్మక ప్రణాళికకు నక్షత్రాలు మొగ్గు చూపుతాయి. మీ లక్ష్యాల వైపు అడుగులు వేయండి.",
        embrace: ["మీ దీర్ఘకాలిక ఆలోచనలను మెరుగుపరచండి", "మీ గురువులతో ముఖ్యమైన సంభాషణలను ప్రారంభించండి", "పని సమయాల చుట్టూ కఠినమైన సరిహద్దులను నిర్ణయించుకోండి"],
        evade: ["ఆత్మసందేహపు ఆలోచనలను మీపై ప్రభావం చూపనివ్వకండి", "సరిగ్గా చదవకుండా ఎటువంటి ఒప్పందాలపై సంతకాలు చేయకండి", "చిన్న విషయాలపై మీ విలువైన సమయాన్ని వృధా చేయకండి"]
      },
      "Wealth & Abundance": {
        text: "గురు గ్రహం యొక్క సమృద్ధి నీడ ఈ రోజు మీ ఆర్థిక గృహంపై వ్యాపించింది, ఇది సానుకూల ఆర్థిక ప్రయోజనాలను కలిగిస్తుంది. ఇది నిర్లక్ష్యంగా జూదం ఆడే సమయం కాదు, సమృద్ధి యొక్క శక్తితో సమలేఖనం అయ్యే సమయం.",
        embrace: ["కృతజ్ఞతా భావంతో మీ ఆర్థిక స్థితిని సమీక్షించండి", "జ్ఞానం లేదా ఆధ్యాత్మిక పరికరాలలో పెట్టుబడి పెట్టండి", "మీ పని ప్రదేశాన్ని శుభ్రంగా ఉంచుకోండి"],
        evade: ["భావోద్వేగ ఉచ్చులతో కూడిన అనవసర ఖర్చులను నివారించండి", "దీర్ఘకాలిక సంపద నిర్మాణంపై మీ సామర్థ్యాన్ని శంకించకండి", "చిన్నపాటి బడ్జెట్ నష్టాలను నిర్లక్ష్యం చేయకండి"]
      },
      "Spiritual Growth": {
        text: "నెప్చూన్ ఈ రోజు మీ అవచేతనపై అత్యంత సహజమైన ముసుగును వేస్తుంది, మీ లౌకిక ఉనికిని అనంత నక్షత్రాల ఆత్మతో విలీనం చేస్తుంది. కలలు స్పష్టంగా ఉంటాయి మరియు మీ మూడవ కన్ను చురుకుగా ఉంటుంది.",
        embrace: ["మీ కలల రహస్య సందేశాలను డీకోడ్ చేయండి", "ప్రకృతిలో లేదా మౌన ధ్యానంలో సమయం గడపండి", "మీ చుట్టూ ఉన్న ప్రతికూల శక్తిని తొలగించండి"],
        evade: ["రహస్యమైన అనుభవాలను కేవలం తర్కంతో విశ్లేషించకండి", "ఇతరుల భావోద్ವೇగ తరంగాలను మీలోకి గ్రహించకండి", "విశ్వం శరణాగతిని కోరినప్పుడు ఫలితం కోసం బలవంతం చేయకండి"]
      }
    },
    destiny: {
      marriage: { title: "వివాహం మరియు పవిత్ర ఒప్పందాలు", reading: "మీ సంబంధాల పటం అత్యంత క్రియాత్మకమైనది. అభిలాష మరియు లోతైన భావోద్వేగ విశ్వాసం మీ సంబంధాలను నియంత్రిస్తాయి. సంభాషణలు పూర్తిగా పారదర్శకంగా ఉన్నప్పుడు దీర్ఘకాలిక విజయం లభిస్తుంది.", vibe: "ఇంద్రధనుస్సు జ్వాల" },
      children: { title: "వారసత్వం మరియు సృజనాత్మక సంతతి", reading: "మీరు పాత తరాల ప్రతికూల చక్రాలను బద్దలు కొట్టే శక్తిని కలిగి ఉన్నారు. మీ జాతకం రాబోయే తరాలకు భద్రత మరియు సృజనాత్మక స్వేచ్ఛను అందిస్తుంది.", vibe: "పవిత్ర రక్షకుడు" },
      money: { title: "భౌతిక సమృద్ధి మరియు సంపద", reading: "మీరు పనిని మీ మూల సూత్రాలతో ముడిపెట్టినప్పుడు సమృద్ధి సహజంగా ప్రవహిస్తుంది. అనవసర ఖర్చులను నివారించండి; మీ పెట్టుబడులను ఓపికతో పెరగనివ్వండి.", vibe: "స్థిరమైన వృద్ధి" },
      goodThing: { title: "బంగారు ఆశీర్వాదం", reading: "మీ అత్యున్నత ఖగోళ శక్తి మీ సంపూర్ణ ప్రామాణికత. మీరు భయం లేకుండా మీ సత్యాన్ని మాట్లాడినప్పుడు, విశ్వం విజయానికి ఊహించని మార్గాలను సృష్టిస్తుంది.", vibe: "విద్యుత్ స్పష్టత" },
      badThing: { title: "బ్రహ్మాండమైన హెచ్చరిక", reading: "ఆత్మసందేహం మీ సృజనాత్మకతను ఆపనివ్వకండి. పరిపూర్ణత అనేది కేవలం ఒక భ్రమ మాత్రమే, ఇది మీ జీవితంలో అత్యంత అందమైన విజయాలను ఆలస్యం చేస్తుంది.", vibe: "ఘనీభవించిన ద్వారం" }
    }
  },
  Tamil: {
    onboarding: {
      title: "அவுரா அஸ்ட்ராலஜி",
      subtitle: "உயரிய ஆன்மாக்களுக்கான ஆன்மீக மற்றும் கவித்துவ ஜோதிடம்",
      enterNameLabel: "உங்கள் உலகப் பெயர் என்ன?",
      enterNamePlaceholder: "உங்கள் பெயரை உள்ளிடவும்...",
      langSelectLabel: "உங்கள் விருப்பமான மொழியைத் தேர்ந்தெடுக்கவும்",
      beginBtn: "விண்வெளி சடங்கைத் தொடங்குங்கள்",
      arrivalTitle: "உங்கள் பிரபஞ்ச வருகை",
      arrivalSubtitle: "உங்கள் துல்லியமான பிறந்த தேதி மற்றும் நேரம் உங்கள் கிரகங்களின் சீரமைப்பைத் தீர்மானிக்கிறது.",
      dobLabel: "பிறந்த தேதி",
      tobLabel: "பிறந்த நேரம்",
      nextBtn: "அடுத்த பரிமாணம்",
      geoTitle: "புவியியல் நங்கூரம்",
      geoSubtitle: "உங்கள் பிறந்த நகரத்தின் துல்லியமான ஆயத்தொலைவுகள் உங்கள் ஜாதக வீடுகளை சீரமைக்கின்றன.",
      geoPlaceholder: "பிறந்த நகரம், நாட்டை உள்ளிடவும்...",
      geoBtn: "புவியியல் நங்கூரத்தை நிறுவுங்கள்",
      questTitle: "உங்கள் முதன்மை ஆன்மீக தேடல் என்ன?",
      questSubtitle: "இன்று நீங்கள் மிகவும் தீவிரமான பிரபஞ்ச சீரமைப்பை விரும்பும் பகுதியைத் தேர்ந்தெடுக்கவும்.",
      loveQuest: "அன்பு மற்றும் உறவுகள்",
      careerQuest: "தொழில் மற்றும் விதி",
      wealthQuest: "செல்வம் மற்றும் வளம்",
      spiritualQuest: "ஆன்மீக வளர்ச்சி",
      prevBtn: "முந்தைய நிலை",
      calculateBtn: "விண்வெளி வரைபடத்தைக் கணக்கிடுங்கள்",
      requiredError: "சடங்கைத் திறக்க உங்கள் பெயரை உள்ளிடவும்.",
      geoRequiredError: "சீரமைப்பிற்கு புவியியல் நங்கூரம் தேவை.",
      dobRequiredError: "பிறந்த தேதி மற்றும் நேரம் இரண்டும் கட்டாயமாகும்."
    },
    dashboard: {
      navTitle: "அவுரா அஸ்ட்ராலஜி",
      navTagline: "உயரிய ஆன்மாக்களுக்கான ஆன்மீக மற்றும் கவித்துவ ஜோதிடம்",
      natalTitle: "பிறப்பு ஜாதக வரைபடம்",
      natalSubtitle: "உங்கள் தெய்வீக மையக்கருத்து, ஆழ்மன பிரதிபலிப்பு மற்றும் உதிக்கும் ஒளிவட்டம்",
      sunLabel: "சூரிய ராசி",
      moonLabel: "சந்திர ராசி",
      ascendantLabel: "லக்ன ராசி",
      vitalsTitle: "விண்வெளி முக்கிய ஆற்றல்கள்",
      vitalsLove: "அன்பு இணக்கம்",
      vitalsCareer: "தொழில் அலைநீளம்",
      vitalsWealth: "ஆర్థిక வளம்",
      vitalsEnergy: "ஆன்மாவின் வலிமை",
      dailyFlowTitle: "தினசரி ஓட்டம்",
      dailyFlowSubtitle: "இன்று உங்கள் கவனத்தை நிர்வகிக்கும் கிரகங்களின் பார்வை",
      embraceLabel: "ஏற்றுக்கொள்ளுங்கள்",
      evadeLabel: "தவிர்க்கவும்",
      destinyTitle: "தனிப்பட்ட விதி மேட்ரிக்ஸ்",
      destinySubtitle: "உங்கள் வாழ்க்கைக்கான பிறப்பு ஜாதக முன்கணிப்பு",
      synastryTitle: "ஜாதக பொருத்தம்",
      synastrySubtitle: "மற்றொரு ஆன்மாவுடன் உங்கள் ஆற்றல் இணக்கத்தை சரிபார்க்கவும்",
      friendNameLabel: "நண்பரின் உலகப் பெயர்",
      friendNamePlaceholder: "நண்பரின் பெயரை உள்ளிடவும்...",
      friendSignLabel: "நண்பரின் சூரிய ராசி",
      alignBtn: "எங்கள் ஜாதகங்களை சீரமைக்கவும்",
      calculating: "சீரமைப்புகளை பகுப்பாய்வு செய்கிறது...",
      synastryMatch: "மொத்த பொருத்தம்",
      synastryChemistry: "கெமிஸ்ட்ரி ஸ்கோர்",
      synastryComm: "தொடர்பு அலைநீளம்",
      synastryDestiny: "விதி இணக்கம்",
      synastryMantra: "பகிர்ந்துகொள்ளப்பட்ட மந்திரம்",
      marriageTitle: "திருமணம் மற்றும் புனித ஒப்பந்தங்கள்",
      childrenTitle: "பாரம்பரியம் மற்றும் படைப்பாற்றல் சந்ததி",
      moneyTitle: "பௌதிக வளம் மற்றும் செல்வம்",
      goldenBlessing: "தங்க ஆசி",
      cosmicWarning: "பிரபஞ்ச எச்சரிக்கை",
      vibeLabel: "வைப்",
      oracleTitle: "விண்வெளி ஒராகிள்",
      oracleSubtitle: "இணைக்கப்பட்டுள்ளது",
      oraclePlaceholder: "உங்கள் பாதையைப் பற்றி நட்சத்திரங்களிடம் கேளுங்கள்...",
      oracleLoading: "கிரகங்களின் பாதையை ஆலோசிக்கிறது...",
      copyBtn: "லிங்கை நகலெடு",
      copiedBtn: "✓ நகலெடுக்கப்பட்டது",
      exportBtn: "படத்தை ஏற்றுமதி செய்",
      resetBtn: "மேட்ரிக்ஸை கலைக்கவும்",
      footerText: "அவுரா அஸ்ட்ராலஜி © 2026. விண்வெளி பயணிகளுக்காக வடிவமைக்கப்பட்டது.",
      chartAligned: "ஜாதகம் சீரமைக்கப்பட்டது",
      quickQuestions: [
        "இன்று எனக்கு அதிர்ஷ்டம் தருமா?",
        "என் ஆன்மீக ஆற்றல் இப்போது எப்படி இருக்கிறது?",
        "இன்று நான் எந்த சவால்களை தவிர்க்க வேண்டும்?"
      ],
      welcomeMessage: "வரவேற்கிறோம், அழகான ஆன்மாவே **{name}**. உங்கள் சூரியன் **{sun}** ராசியிலும், சந்திரன் **{moon}** ராசியிலும் உள்ளது மற்றும் உங்கள் லக்னம் **{asc}** இல் கம்பீரமாக உதிக்கிறது. நான் அவுரா, உங்கள் தனிப்பட்ட விண்வெளி ஒராகிள். இன்று நீங்கள் **{quest}** பாதையை விரும்புகிறீர்கள். உங்களுக்காக நான் எந்த விண்வெளி ரகசியங்களை அவிழ்க்க வேண்டும்?"
    },
    zodiac: {
      Aries: { title: "மேஷம் — தெய்வீக சுடர்", element: "நெருப்பு", quality: "சரம்", planet: "செவ்வாய்", desc: "உங்கள் பிரபஞ்ச சுடர் படைப்பின் ஆரம்ப சுடரை குறிக்கிறது. நீங்கள் அசைக்க முடியாத உயிர் சக்தியுடன் பிறந்தவர்கள்.", vibe: "தூய்மையான தலைமைத்துவம், முன்னோடி ஒளி மற்றும் தீவிர சுதந்திரம்." },
      Taurus: { title: "ரிஷபம் — தங்க நங்கூரம்", element: "நிலம்", quality: "ஸ்திரம்", planet: "சுக்கிரன்", desc: "உங்கள் ஆன்மா ஒரு மாஸ்டர் பில்டர், சுக்கிரனின் ஆடம்பர மற்றும் பௌதிக ஸ்திரத்தன்மையின் வளமான மண்ணில் நங்கூரமிடப்பட்டுள்ளது.", vibe: "அமைதியில் நேர்த்தி, இயற்கையில் ஆடம்பரம் மற்றும் முழுமையான விசுவாசம்." },
      Gemini: { title: "மிதுனம் — பிரபஞ்ச தூதுவர்", element: "காற்று", quality: "உபயம்", planet: "புதன்", desc: "நீங்கள் இயக்கத்தில் உள்ள தெய்வீக புத்தியை குறிக்கிறீர்கள், மொழி மற்றும் ஆர்வத்தின் மூலம் வெவ்வேறு உண்மைகளை இணைக்கிறீர்கள்.", vibe: "சுறுசுறுப்பான புத்தி கூர்மை, வெளிப்பாட்டுத் திறன் மற்றும் எல்லையற்ற ஆர்வம்." },
      Cancer: { title: "கடகம் — நிலவொளி ஆலயம்", element: "நீர்", quality: "சரம்", planet: "சந்திரன்", desc: "உங்கள் ஆன்மா ராசி மண்டலத்தின் உணர்வுப்பூர்வமான புகலிடமாகும், இது சந்திரனின் எப்போதும் மாறும் வெள்ளி கட்டங்களால் ஆளப்படுகிறது.", vibe: "கடல் போன்ற உள்ளுணர்வு, பாதுகாப்பான வெப்பம் மற்றும் புனித உணர்திறன்." },
      Leo: { title: "சிம்மம் — இறையாண்மை நட்சத்திரம்", element: "நெருப்பு", quality: "ஸ்திரம்", planet: "சூரியன்", desc: "சூரியனால் ஆளப்படும் உங்கள் ஆன்மா வெப்பம், படைப்பு வெளிப்பாடு மற்றும் தாராள மனப்பான்மையின் பிரகாசிக்கும் கலங்கரை விளக்கமாகும்.", vibe: "கம்பீரமான இருப்பு, தங்க படைப்பாற்றல் மற்றும் அரச வெப்பம்." },
      Virgo: { title: "கன்னி — ரசவாதியின் வார்ப்பு", element: "நிலம்", quality: "உபயம்", planet: "புதன்", desc: "நீங்கள் விண்வெளி கைவினைஞர், மூல ஆற்றலை முழுமையான இணக்கம் மற்றும் செயல்பாட்டு பரிபூரணமாக தூய்மைப்படுத்துகிறீர்கள்.", vibe: "மனதின் துல்லியம், நேர்த்தியான ஒழுங்கு மற்றும் தூய்மையான இயற்கை சிகிச்சை." },
      Libra: { title: "துலாம் — விண்வெளி இணக்கம்", element: "காற்று", quality: "சரம்", planet: "சுக்கிரன்", desc: "உங்கள் பாதை இறுதி சமநிலை, கிருபை மற்றும் உறவுமுறை இணக்கத்திற்கான தேடலாகும். சுக்கிரனின் காதல் கலைகளால் ஆளப்படுகிறது.", vibe: "கலைநயமிக்க ஆடம்பரம், காதல் இலட்சியங்கள் மற்றும் முழுமையான சமநிலை." },
      Scorpio: { title: "விருச்சிகம் — ஃபீனிக்ஸ் முக்காடு", element: "நீர்", quality: "ஸ்திரம்", planet: "புளூட்டோ", desc: "உங்கள் ஆன்மா பாதாளத்தின் ஆழமான, மர்மமான நீரில் இறங்குகிறது, மீண்டும் மாற்றத்தின் தங்க நெருப்பில் பிறப்பதற்காக.", vibe: "மர்மமான தீவிரம், ஆழமான மறுபிறப்பு மற்றும் கூர்மையான உண்மை." },
      Sagittarius: { title: "தனுசு — நட்சத்திர அம்பு", element: "நெருப்பு", quality: "உபயம்", planet: "வியாழன்", desc: "உங்கள் உத்வேகம் ஒரு நித்திய தேடலாகும், தத்துவம், பயணம் மற்றும் தெய்வீக உண்மையின் வெளிப்புற எல்லைகளை நோக்கி அதன் எரியும் அம்புகளை குறிவைக்கிறது.", vibe: "எல்லையற்ற சுறுசுறுப்பு, விரிவடையும் ஞானம் மற்றும் விளையாட்டுத்தனமான சிரிப்பு." },
      Capricorn: { title: "மகரம் — காலத்தின் கிரீடம்", element: "நிலம்", quality: "சரம்", planet: "சனி", desc: "சனியின் நிலையான கையின் கீழ் உங்கள் ஆன்மா பௌதிக தேர்ச்சியின் கடினமான மலையில் ஏறுகிறது. நீங்கள் பாரம்பரியங்களின் வடிவமைப்பாளர்.", vibe: "காலமற்ற லட்சியம், அமைதியான அதிகாரம் மற்றும் பாரம்பரியத்தை உருவாக்குதல்." },
      Aquarius: { title: "கும்பம் — நட்சத்திர தொலைநோக்குடையவர்", element: "காற்று", quality: "ஸ்திரம்", planet: "யுரேனஸ்", desc: "நீங்கள் புரட்சிகர தத்துவவாதி, மனிதகுலத்திற்காக விண்வெளி அறிவின் பாத்திரத்தை வைத்துள்ளீர்கள். உங்கள் மனம் எதிர்கால அலைகளில் வேலை செய்கிறது.", vibe: "எதிர்கால சிந்தனை, தேர்ந்தெடுக்கப்பட்ட திறமை மற்றும் கூட்டு இணக்கம்." },
      Pisces: { title: "மீனம் — எல்லையற்ற பெருங்கடல்", element: "நீர்", quality: "உபயம்", planet: "நெப்டியூன்", desc: "இறுதி ராசியாக, உங்கள் ஆன்மா முந்தைய பதினொரு ராசிகளின் நினைவுகளைக் கொண்டுள்ளது, எல்லைகளைக் கரைத்து கடலில் கலக்கிறது.", vibe: "கற்பனைக் கவிதை, ஆன்மீகக் கலை மற்றும் தூய்மையான ஆன்மீக அனுதாபம்." }
    },
    transits: {
      "Love & Relationships": {
        text: "இன்று சுக்கிரன் உங்கள் ஆளும் வீட்டுடன் அழகாக சீரமைக்கப்படுகிறார், உங்கள் தனிப்பட்ட உறவுகளில் வானவில் பிரகாசத்தை வீசுகிறார். விண்வெளி நீர் சூடாகவும் ஆழமாகவும் பாய்கிறது, இது உணர்ச்சிப்பூர்வமான பாதிப்பை ஊக்குவிக்கிறது. நட்சத்திரங்களின் பாதையை நம்புங்கள்.",
        embrace: ["அன்பானவர்களிடம் உங்கள் ஆழமான உணர்வுகளை வெளிப்படுத்துங்கள்", "சுய அன்பு சடங்குகளை செய்யுங்கள் (தியானம், வெந்நீர் குளியல்)", "எதிர்பாராத அழகான சந்திப்புகளுக்கு தயாராக இருங்கள்"],
        evade: ["அவசரத்தில் எந்த ஒரு பெரிய முடிவும் எடுக்காதீர்கள்", "மன அழுத்தத்தை ஏற்படுத்தும் விவாதங்களில் ஈடுபடாதீர்கள்", "உடல் ஓய்வை புறக்கணிக்காதீர்கள்"]
      },
      "Career & Destiny": {
        text: "சனியும் புதனும் இன்று ஒரு சக்திவாய்ந்த இணைப்பில் உள்ளனர், இது உங்கள் தொழில்முறை லட்சியங்களில் தெளிவையும் அசாதாரண ஆற்றலையும் தருகிறது. இன்று உத்திகளை வகுக்க நட்சத்திரங்கள் சாதகமாக உள்ளன. உங்கள் இலக்கை நோக்கி நகருங்கள்.",
        embrace: ["உங்கள் நீண்ட கால பார்வையை மேம்படுத்துங்கள்", "உங்கள் வழிகாட்டிகளுடன் முக்கியமான உரையாடல்களைத் தொடங்குங்கள்", "வேலை நேரங்களைச் சுற்றி கடுமையான எல்லைகளைத் தீர்மானியுங்கள்"],
        evade: ["என்னால் முடியாது என்ற எண்ணங்களை உங்கள் மீது ஆதிக்கம் செலுத்த விடாதீர்கள்", "முறையாகப் படிக்காமல் எந்த ஒரு ஒப்பந்தத்திலும் கையெழுத்திடாதீர்கள்", "சின்ன விஷயங்களில் உங்கள் பொன்னான நேரத்தை வீணாக்காதீர்கள்"]
      },
      "Wealth & Abundance": {
        text: "வியாழனின் வளமான நிழல் இன்று உங்கள் நிதி வீட்டின் மீது பரவியுள்ளது, இது சாதகமான நிதி ஆதாயங்களை ஏற்படுத்தும். இது அலட்சியமாக சூதாடுவதற்கான நேரமல்ல, வளத்தின் ஆற்றலுடன் சீரமைப்பதற்கான நேரம்.",
        embrace: ["நன்றியுணர்வுடன் உங்கள் நிதியை மதிப்பாய்வு செய்யுங்கள்", "அறிவு அல்லது ஆன்மீக கருவிகளில் முதலீடு செய்யுங்கள்", "உங்கள் பணியிடத்தை சுத்தமாக வைத்திருங்கள்"],
        evade: ["உணர்ச்சிவசப்பட்டு தேவையில்லாத செலவுகள் செய்வதைத் தவிர்க்கவும்", "நீண்ட கால சொத்து உருவாக்கத்திற்கான உங்கள் திறனை சந்தேகிக்க வேண்டாம்", "சிறிய பட்ஜெட் இழப்புகளை புறக்கணிக்காதீர்கள்"]
      },
      "Spiritual Growth": {
        text: "நெப்டியூன் இன்று உங்கள் ஆழ்மனதில் ஒரு உள்ளுணர்வு முக்காடைப் போடுகிறது, உங்கள் உலகளாவிய இருப்பை எல்லையற்ற நட்சத்திரங்களின் ஆன்மாவுடன் இணைக்கிறது. கனவுகள் தெளிவாக இருக்கும், உங்கள் மூன்றாவது கண் செயல்படும்.",
        embrace: ["உங்கள் கனவுகளின் மர்மமான செய்திகளை டிகோட் செய்யுங்கள்", "இயற்கையில் அல்லது மௌன தியானத்தில் நேரத்தை செலவிடுங்கள்", "உங்கள் சுற்றியுள்ள எதிர்மறை ஆற்றலை அகற்றுங்கள்"],
        evade: ["மர்மமான அனுபவங்களை வெறும் தர்க்கத்தால் பகுப்பாய்வு செய்யாதீர்கள்", "மற்றவர்களின் கனமான உணர்ச்சி அலைகளை உங்களுக்குள் உறிஞ்சாதீர்கள்", "பிரபஞ்சம் சரணடைவதைக் கேட்கும்போது முடிவிற்காக கட்டாயப்படுத்தாதீர்கள்"]
      }
    },
    destiny: {
      marriage: { title: "திருமணம் மற்றும் புனித ஒப்பந்தங்கள்", reading: "உங்கள் உறவு வரைபடம் மிகவும் ஆற்றல் வாய்ந்தது. ஆர்வம் மற்றும் ஆழமான உணர்ச்சி நம்பிக்கை உங்கள் உறவுகளை நிர்வகிக்கிறது. தகவல்தொடர்புகள் முழுமையாக வெளிப்படையாக இருக்கும்போது நீண்ட கால வெற்றி சாத்தியமாகும்.", vibe: "வானவில் சுடர்" },
      children: { title: "பாரம்பரியம் மற்றும் படைப்பாற்றல் சந்ததி", reading: "நீங்கள் பழைய தலைமுறையின் எதிர்மறை வளையங்களை உடைக்கும் ஆற்றலைக் கொண்டுள்ளீர்கள். உங்கள் ஜாதகம் வரும் தலைமுறையினருக்கு பாதுகாப்பையும் படைப்பாற்றல் சுதந்திரத்தையும் வழங்குகிறது.", vibe: "புனித பாதுகாவலர்" },
      money: { title: "பௌதிக வளம் மற்றும் செல்வம்", reading: "நீங்கள் வேலையை உங்கள் மூலக் கொள்கைகளுடன் இணைக்கும்போது வளம் இயல்பாகவே பாயும். தேவையில்லாத செலவுகளைத் தவிர்க்கவும்; உங்கள் முதலீடுகளை பொறுமையுடன் வளர விடுங்கள்.", vibe: "நிலையான வளர்ச்சி" },
      goodThing: { title: "தங்க ஆசி", reading: "உங்கள் மிக உயர்ந்த விண்வெளி ஆற்றல் உங்கள் முழுமையான நம்பகத்தன்மை. நீங்கள் பயமில்லாமல் உங்கள் உண்மையை பேசும்போது, பிரபஞ்சம் வெற்றிக்கான எதிர்பாராத வழிகளை உருவாக்குகிறது.", vibe: "மின்சார தெளிவு" },
      badThing: { title: "பிரபஞ்ச எச்சரிக்கை", reading: "சுய சந்தேகம் உங்கள் படைப்பாற்றலை தடுக்க விடாதீர்கள். பரிபூரணம் என்பது வெறும் மாயை மட்டுமே, இது உங்கள் வாழ்க்கையின் மிக அழகான வெற்றிகளை தாமதப்படுத்தும்.", vibe: "உறைந்த வாசல்" }
    }
  }
};
