import { SignMatrixDetail } from "../types";

export const ZODIAC_SIGNS = [
  "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
  "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"
];

export const SIGN_MATRIX: Record<string, SignMatrixDetail> = {
  Aries: {
    title: "Aries — The Divine Spark",
    element: "Fire",
    quality: "Cardinal",
    rulingPlanet: "Mars",
    description: "Your cosmic flame represents the initial spark of creation. You are born with an unyielding life force, a soul destined to break new ground and spearhead celestial movements. Your path is one of courage, direct action, and the search for authentic selfhood.",
    strengths: ["Infinite Pioneer Spirit", "Fearless Passion", "Infectious Enthusiasm"],
    vibe: "Pure raw leadership, pioneering light, and fierce independence."
  },
  Taurus: {
    title: "Taurus — The Golden Anchor",
    element: "Earth",
    quality: "Fixed",
    rulingPlanet: "Venus",
    description: "Your soul is a master builder, anchored in the rich soil of Venusian sensory pleasure and material stability. You possess the sacred art of patience and presence, transforming raw physical energy into magnificent, everlasting beauty and security.",
    strengths: ["Unshakable Resilience", "Mastery of Aesthetics", "Soulful Reliability"],
    vibe: "Elegance in stillness, luxury in nature, and absolute loyalty."
  },
  Gemini: {
    title: "Gemini — The Cosmic Messenger",
    element: "Air",
    quality: "Mutable",
    rulingPlanet: "Mercury",
    description: "You represent the divine intellect in motion, bridging separate realities through language, curiosity, and rapid adaptation. Your mind is an infinite starry network, constantly collecting, synthesizing, and sharing the secrets of the universe.",
    strengths: ["Infinite Mental Agility", "Dualistic Adaptability", "Radiant Wit"],
    vibe: "Sprightly intellect, expressive charm, and boundless curiosity."
  },
  Cancer: {
    title: "Cancer — The Moonlit Temple",
    element: "Water",
    quality: "Cardinal",
    rulingPlanet: "Moon",
    description: "Your soul is the emotional sanctuary of the zodiac, governed by the ever-shifting silver phases of the Moon. You possess extraordinary intuitive depth, a sacred protective nature, and the power to heal through profound emotional resonance.",
    strengths: ["Telepathic Empathy", "Fierce Nurturing Shield", "Soulful Memory"],
    vibe: "Oceanic intuition, protective warmth, and sacred vulnerability."
  },
  Leo: {
    title: "Leo — The Sovereign Star",
    element: "Fire",
    quality: "Fixed",
    rulingPlanet: "Sun",
    description: "Governed by the golden solar center, your soul is a shining beacon of warmth, creative expression, and royal generosity. You are here to learn the art of noble leadership, creative radiance, and living with an open, courageous heart.",
    strengths: ["Sovereign Magnanimity", "Magnetic Creative Fire", "Unwavering Loyalty"],
    vibe: "Majestic presence, golden creativity, and royal warmth."
  },
  Virgo: {
    title: "Virgo — The Alchemist's Crucible",
    element: "Earth",
    quality: "Mutable",
    rulingPlanet: "Mercury",
    description: "You are the cosmic craftsman, purifying raw energy into absolute harmony and functional perfection. Your soul understands that divinity lives in the micro-details, dedicating itself to selfless service, wellness, and mental refinement.",
    strengths: ["Analytical Alchemy", "Exquisite Discernment", "Selfless Devotion"],
    vibe: "Mindful precision, elegant order, and pure organic healing."
  },
  Libra: {
    title: "Libra — The Celestial Harmony",
    element: "Air",
    quality: "Cardinal",
    rulingPlanet: "Venus",
    description: "Your path is the pursuit of ultimate balance, grace, and relational harmony. Governed by the romantic arts of Venus, your soul acts as a celestial architect of peace, seeking to mirror divine beauty and justice in all connections.",
    strengths: ["Diplomatic Sophistication", "Aesthetic Symmetry", "Fair-minded Grace"],
    vibe: "Artistic luxury, romantic ideals, and absolute balance."
  },
  Scorpio: {
    title: "Scorpio — The Phoenix's Veil",
    element: "Water",
    quality: "Fixed",
    rulingPlanet: "Pluto",
    description: "Your soul descends into the deep, mysterious waters of the underworld, only to rise again, reborn in the golden fire of transformation. You possess unparalleled emotional intensity, detective-like perception, and powerful magnetic secrets.",
    strengths: ["Hypnotic Personal Power", "Fearless Vulnerability", "Unmatched Regeneration"],
    vibe: "Mysterious intensity, profound rebirth, and razor-sharp truth."
  },
  Sagittarius: {
    title: "Sagittarius — The Starward Arrow",
    element: "Fire",
    quality: "Mutable",
    rulingPlanet: "Jupiter",
    description: "Your spirit is an eternal seeker, aiming its burning arrow toward the outer boundaries of philosophy, travel, and divine truth. Governed by prosperous Jupiter, you look at existence with infectious optimism and a quest for expansive freedom.",
    strengths: ["Boundless Optimism", "Philosophical Sagacity", "Adventuresome Spirit"],
    vibe: "Wild wanderlust, expanding wisdom, and playful laughter."
  },
  Capricorn: {
    title: "Capricorn — The Crown of Time",
    element: "Earth",
    quality: "Cardinal",
    rulingPlanet: "Saturn",
    description: "Your soul climbs the rugged mountain of material mastery under the steady hand of Saturn. You are the architect of legacies, possessing deep patience, a majestic sense of duty, and the strength to turn quiet ambitions into empires.",
    strengths: ["Monumental Discipline", "Strategic Sovereignty", "Unyielding Endurance"],
    vibe: "Timeless ambition, silent authority, and legacy building."
  },
  Aquarius: {
    title: "Aquarius — The Starry Visionary",
    element: "Air",
    quality: "Fixed",
    rulingPlanet: "Uranus",
    description: "You are the rebel-philosopher, holding the vessel of celestial knowledge to pour over humanity. Your mind operates on future wavelengths, constantly dreaming of progressive evolution, collective unity, and unique eccentric expressions.",
    strengths: ["Visionary Genius", "Unapologetic Originality", "Humanitarian Heart"],
    vibe: "Future-forward thinking, eclectic brilliance, and collective harmony."
  },
  Pisces: {
    title: "Pisces — The Infinite Ocean",
    element: "Water",
    quality: "Mutable",
    rulingPlanet: "Neptune",
    description: "As the final sign, your soul holds the memories of all eleven previous signs, dissolving boundaries into the sea of collective consciousness. You possess absolute artistic genius, vivid dreams, and a direct channel to divine unconditional love.",
    strengths: ["Divine Artistic Channeling", "Boundless Compassion", "Intuitive Mysticism"],
    vibe: "Dreamy poetry, transcendental art, and pure spiritual empathy."
  }
};

export function getSunSign(dateStr: string): string {
  if (!dateStr) return "Aries";
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return "Aries";
  const month = date.getMonth() + 1;
  const day = date.getDate();

  if ((month === 3 && day >= 21) || (month === 4 && day <= 19)) return "Aries";
  if ((month === 4 && day >= 20) || (month === 5 && day <= 20)) return "Taurus";
  if ((month === 5 && day >= 21) || (month === 6 && day <= 20)) return "Gemini";
  if ((month === 6 && day >= 21) || (month === 7 && day <= 22)) return "Cancer";
  if ((month === 7 && day >= 23) || (month === 8 && day <= 22)) return "Leo";
  if ((month === 8 && day >= 23) || (month === 9 && day <= 22)) return "Virgo";
  if ((month === 9 && day >= 23) || (month === 10 && day <= 22)) return "Libra";
  if ((month === 10 && day >= 23) || (month === 11 && day <= 21)) return "Scorpio";
  if ((month === 11 && day >= 22) || (month === 12 && day <= 21)) return "Sagittarius";
  if ((month === 12 && day >= 22) || (month === 1 && day <= 19)) return "Capricorn";
  if ((month === 1 && day >= 20) || (month === 2 && day <= 18)) return "Aquarius";
  return "Pisces";
}

export function getMoonSign(dateStr: string): string {
  if (!dateStr) return "Cancer";
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return "Cancer";
  
  // Moon completes an orbit in 27.3 days. Use deterministic calculation since a known epoch (Jan 1 2000)
  const msDiff = date.getTime() - new Date("2000-01-01").getTime();
  const days = msDiff / (1000 * 60 * 60 * 24);
  const moonCycle = 27.32166;
  const position = ((days % moonCycle) + moonCycle) % moonCycle;
  const signIndex = Math.floor((position / moonCycle) * 12);
  
  // Map index with offset
  return ZODIAC_SIGNS[(signIndex + 6) % 12];
}

export function getAscendantSign(dateStr: string, timeStr: string): string {
  const sunSign = getSunSign(dateStr);
  const sunIndex = ZODIAC_SIGNS.indexOf(sunSign);
  if (sunIndex === -1) return "Leo";

  let hour = 12; // Default to mid-day
  if (timeStr) {
    const parts = timeStr.split(":");
    if (parts.length >= 2) {
      hour = parseInt(parts[0], 10);
    }
  }

  // Sunrise is approximately 6:00 AM.
  // The ascendant rotates through all 12 signs in 24 hours (approx 2 hours per sign).
  const hoursSinceSunrise = (hour - 6 + 24) % 24;
  const shift = Math.floor(hoursSinceSunrise / 2);
  return ZODIAC_SIGNS[(sunIndex + shift) % 12];
}
