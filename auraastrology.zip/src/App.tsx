import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Sparkles,
  Moon,
  Sun,
  Compass,
  Heart,
  Briefcase,
  Coins,
  Activity,
  User,
  MapPin,
  Clock,
  ChevronRight,
  ChevronDown,
  Send,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  MessageSquare,
  HelpCircle,
  X,
  Share2,
  Users
} from "lucide-react";
import { UserProfile, TransitData, ChatMessage, SignMatrixDetail } from "./types";
import { getSunSign, getMoonSign, getAscendantSign, SIGN_MATRIX } from "./utils/astrology";

export default function App() {
  // --- STATE DECLARATIONS ---
  const [step, setStep] = useState<number | "loading" | "dashboard">(1);
  const [profile, setProfile] = useState<UserProfile>({
    name: "",
    birthDate: "",
    birthTime: "",
    birthPlace: "",
    guidanceType: "",
    sunSign: "",
    moonSign: "",
    ascendantSign: ""
  });

  // Onboarding field errors
  const [error, setError] = useState<string>("");

  // Loading screen messages cycle
  const [loadingMsgIdx, setLoadingMsgIdx] = useState(0);
  const loadingMessages = [
    "Mapping the celestial coordinates...",
    "Interrogating the positions of Venus and Saturn...",
    "Weaving your natal alignment matrices...",
    "Tuning the frequencies of the Astral Oracle..."
  ];

  // Dashboard state
  const [transitData, setTransitData] = useState<TransitData | null>(null);
  const [transitLoading, setTransitLoading] = useState<boolean>(false);
  const [activeSignKey, setActiveSignKey] = useState<"sun" | "moon" | "ascendant" | null>(null);

  // Social media app features state
  const [activeTab, setActiveTab] = useState<"daily" | "weekly" | "compatibility" | "destiny">("daily");
  const [friendName, setFriendName] = useState<string>("");
  const [lifeForecast, setLifeForecast] = useState<any>(null);
  const [lifeForecastLoading, setLifeForecastLoading] = useState<boolean>(false);
  const [friendSunSign, setFriendSunSign] = useState<string>("Aries");
  const [friendBirthDate, setFriendBirthDate] = useState<string>("");
  const [compatibilityResult, setCompatibilityResult] = useState<any>(null);
  const [compatLoading, setCompatLoading] = useState<boolean>(false);
  const [showShareModal, setShowShareModal] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);

  // Chat state
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState<string>("");
  const [chatLoading, setChatLoading] = useState<boolean>(false);

  const chatEndRef = useRef<HTMLDivElement>(null);

  // --- INITIALIZATION (LOCALSTORAGE CACHE) ---
  useEffect(() => {
    const cachedProfile = localStorage.getItem("aura_astrology_profile");
    if (cachedProfile) {
      try {
        const parsed = JSON.parse(cachedProfile);
        setProfile(parsed);
        setStep("dashboard");
        fetchTransitData(parsed);
        fetchLifeForecast(parsed);
      } catch (e) {
        localStorage.removeItem("aura_astrology_profile");
      }
    }
  }, []);

  // Scroll chat to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatHistory, chatLoading]);

  // Loading screen message rotation
  useEffect(() => {
    if (step === "loading") {
      const interval = setInterval(() => {
        setLoadingMsgIdx((prev) => (prev + 1) % loadingMessages.length);
      }, 700);
      return () => clearInterval(interval);
    }
  }, [step]);

  // --- TRANSIT DATA FETCHING ---
  const fetchTransitData = async (userProfile: UserProfile) => {
    setTransitLoading(true);
    try {
      const res = await fetch("/api/transit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ profile: userProfile })
      });
      if (res.ok) {
        const data = await res.json();
        setTransitData(data);
      } else {
        throw new Error("Failed to fetch celestial transits");
      }
    } catch (err) {
      console.error(err);
      // Local fallback in case of errors
      setTransitData({
        transitText: "Venus shines a soothing rays onto your core today. Your energy flows elegantly. Direct your gaze inward to find the balances that are shifting.",
        embrace: ["Focus on hydration and self-care", "Listen to ambient sounds", "Journal your vivid dreams"],
        evade: ["Signing bindings under haste", "Engaging in stressful arguments", "Skipping physical stretching"],
        vitals: { love: 88, career: 75, wealth: 82, energy: 90 },
        isSimulated: true
      });
    } finally {
      setTransitLoading(false);
    }
  };

  // --- LIFE FORECAST DATA FETCHING ---
  const fetchLifeForecast = async (userProfile: UserProfile) => {
    setLifeForecastLoading(true);
    try {
      const res = await fetch("/api/life-forecast", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ profile: userProfile })
      });
      if (res.ok) {
        const data = await res.json();
        setLifeForecast(data);
      } else {
        throw new Error("Failed to fetch life forecast");
      }
    } catch (err) {
      console.error(err);
      // Fallback
      setLifeForecast({
        marriage: {
          title: "Sacred Union",
          reading: `Your relationship map is highly dynamic. With Sun in ${userProfile.sunSign} and Moon in ${userProfile.moonSign}, you require passion and deep emotional trust. Long-term marriage succeeds when communication is completely transparent.`,
          vibe: "Iridescent Flame"
        },
        children: {
          title: "Legacy & Nurturing",
          reading: `You carry a cycle-breaking lineage. As a guide, your ${userProfile.moonSign} moon grants you exceptional depth to offer future generations both unconditional safety and unlimited creative room.`,
          vibe: "Sanctuary Guardian"
        },
        money: {
          title: "Material Currents",
          reading: `Abundance flows naturally when you align work with your core principles. With Sun in ${userProfile.sunSign}, you have immense focus. Avoid impulsive status purchases; let your investments mature in silence.`,
          vibe: "Steady Growth"
        },
        goodThing: {
          title: "The Golden Path",
          reading: "Your supreme strength is absolute authenticity. When you speak your truth without fear, the universe bends to create unexpected pathways of success.",
          vibe: "Electric Clarity"
        },
        badThing: {
          title: "The Shadow Warning",
          reading: "Do not let self-imposed doubt freeze your creative expressions. Perfection is an illusion that delays your most beautiful life breakthroughs.",
          vibe: "The Frozen Gate"
        }
      });
    } finally {
      setLifeForecastLoading(false);
    }
  };

  // --- ORACLE CHAT ACTIONS ---
  const handleSendMessage = async (customMessage?: string) => {
    const messageText = customMessage || chatInput;
    if (!messageText.trim() || chatLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      text: messageText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatHistory((prev) => [...prev, userMsg]);
    if (!customMessage) setChatInput("");
    setChatLoading(true);

    try {
      // Map history to server-compatible format
      const historyPayload = chatHistory.map(h => ({
        role: h.role,
        text: h.text
      }));

      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: messageText,
          history: historyPayload,
          profile
        })
      });

      if (res.ok) {
        const data = await res.json();
        const oracleMsg: ChatMessage = {
          id: (Date.now() + 1).toString(),
          role: "model",
          text: data.text,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setChatHistory((prev) => [...prev, oracleMsg]);
      } else {
        throw new Error("Oracle connection lapsed");
      }
    } catch (err) {
      console.error(err);
      const errorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: "model",
        text: "The cosmic storm has briefly clouded my connection to the stars. Let your soul rest momentarily, then ask again.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setChatHistory((prev) => [...prev, errorMsg]);
    } finally {
      setChatLoading(false);
    }
  };

  // --- ONBOARDING FORM SUBMISSION ---
  const handleOnboardingNext = () => {
    setError("");
    if (step === 1) {
      if (!profile.name.trim()) {
        setError("Please enter your name to unlock the ritual.");
        return;
      }
      setStep(2);
    } else if (step === 2) {
      if (!profile.birthDate || !profile.birthTime) {
        setError("Both date and time of arrival are required for alignment.");
        return;
      }
      setStep(3);
    } else if (step === 3) {
      if (!profile.birthPlace.trim()) {
        setError("The alignment requires a geographical anchor.");
        return;
      }
      // Set signs
      const sun = getSunSign(profile.birthDate);
      const moon = getMoonSign(profile.birthDate);
      const asc = getAscendantSign(profile.birthDate, profile.birthTime);
      setProfile((prev) => ({
        ...prev,
        sunSign: sun,
        moonSign: moon,
        ascendantSign: asc
      }));
      setStep(4);
    }
  };

  const handleSelectGuidance = (type: string) => {
    const updatedProfile = { ...profile, guidanceType: type };
    setProfile(updatedProfile);
    setError("");

    // Trigger progressive loading sequence
    setStep("loading");
    setTimeout(() => {
      // Save and transition to dashboard
      localStorage.setItem("aura_astrology_profile", JSON.stringify(updatedProfile));
      setStep("dashboard");
      fetchTransitData(updatedProfile);
      fetchLifeForecast(updatedProfile);
      // Pre-populate Chat with greeting from Astrologer
      setChatHistory([
        {
          id: "welcome",
          role: "model",
          text: `Welcome, beautiful soul **${profile.name}**. I see your Sun shines in **${updatedProfile.sunSign}**, your Moon rests in **${updatedProfile.moonSign}**, and your Ascendant rises majestic in **${updatedProfile.ascendantSign}**. I am Aura, your personal Astral Oracle. Today, you seek the path of **${type}**. What celestial secrets can I unlock for you?`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }, 2800);
  };

  const handleResetProfile = () => {
    if (confirm("Are you ready to dissolve your current matrix and redo the celestial ritual onboarding?")) {
      localStorage.removeItem("aura_astrology_profile");
      setProfile({
        name: "",
        birthDate: "",
        birthTime: "",
        birthPlace: "",
        guidanceType: "",
        sunSign: "",
        moonSign: "",
        ascendantSign: ""
      });
      setTransitData(null);
      setChatHistory([]);
      setStep(1);
    }
  };

  const handleCompatibilityCheck = async () => {
    if (!friendName.trim() || !friendSunSign) return;
    setCompatLoading(true);
    setCompatibilityResult(null);
    try {
      const res = await fetch("/api/compatibility", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          profile,
          friendName,
          friendSunSign
        })
      });
      if (res.ok) {
        const data = await res.json();
        setCompatibilityResult(data);
      } else {
        throw new Error("Synastry alignment failed");
      }
    } catch (err) {
      console.error(err);
      setCompatibilityResult({
        matchPercentage: 81,
        communicationScore: 84,
        chemistryScore: 76,
        destinyScore: 82,
        compatibilitySummary: `A magnetic link. **${profile.name}** and **${friendName}** form a highly dynamic combination. You share a beautiful conversational flow, though sometimes you clash over who directs the group chat.`,
        sharedMantra: "Order pizza, watch reality shows, and never discuss past errors.",
        isSimulated: true
      });
    } finally {
      setCompatLoading(false);
    }
  };

  // --- SIMPLE MARKDOWN PARSER FOR HIGH-FIDELITY CHAT ---
  const renderMarkdown = (text: string) => {
    if (!text) return "";
    let formatted = text
      .replace(/\*\*(.*?)\*\*/g, '<strong class="text-[#f3cb7b] font-semibold">$1</strong>')
      .replace(/\*(.*?)\*/g, '<em class="text-gray-300 italic">$1</em>');

    const paragraphs = formatted.split("\n");
    return paragraphs.map((p, i) => (
      <p key={i} className="mb-2 last:mb-0 leading-relaxed text-sm text-[#f8f9fa]" dangerouslySetInnerHTML={{ __html: p }} />
    ));
  };

  // Quick Questions
  const quickQuestions = [
    "Will today be lucky for me?",
    "How is my spiritual energy right now?",
    "What challenges should I evade today?"
  ];

  return (
    <div className="relative min-h-screen text-[#f8f9fa] font-sans flex flex-col antialiased selection:bg-[#f3cb7b] selection:text-[#0a0612] overflow-x-hidden">
      {/* Drifting Nebula Background */}
      <div className="nebula-bg" />

      {/* STARRY SPARKS OVERLAY */}
      <div className="absolute inset-0 pointer-events-none opacity-20 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:24px_24px] [mask-image:radial-gradient(ellipse_50%_50%_at_50%_50%,#000_70%,transparent_100%)]" />

      {/* TOP HEADER */}
      <header className="relative w-full z-10 px-6 py-4 flex items-center justify-between border-b border-[rgba(243,203,123,0.15)] bg-[rgba(10,6,18,0.4)] backdrop-blur-md">
        <div className="flex items-center gap-2.5">
          <Compass className="w-5 h-5 text-[#f3cb7b] spin-celestial" />
          <span className="font-serif text-lg md:text-xl tracking-widest uppercase font-light text-gold-gradient">
            Aura Astrology
          </span>
        </div>

        <div className="text-right flex flex-col items-end gap-0.5">
          <span className="text-[10px] md:text-xs font-serif uppercase tracking-widest text-[#f3cb7b] opacity-90">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })} • Moon in Scorpio
          </span>
          {step === "dashboard" && (
            <span className="text-[9px] font-mono uppercase tracking-wider text-[rgba(248,249,250,0.5)] flex items-center gap-1.5 mt-0.5">
              <span className="w-1 h-1 bg-[#f3cb7b] rounded-full star-pulse" />
              Chart Aligned: {profile.name}
            </span>
          )}
        </div>
      </header>

      {/* MAIN CONTAINER */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 flex flex-col justify-center relative z-10">
        <AnimatePresence mode="wait">
          {/* STEP 1: ONBOARDING NAME */}
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4 }}
              className="max-w-md w-full mx-auto glass-panel p-8 rounded-2xl relative overflow-hidden"
              id="onboarding-step-1"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-[rgba(243,203,123,0.1)]">
                <div className="w-1/4 h-full bg-[#f3cb7b]" />
              </div>

              <div className="flex justify-center mb-6">
                <Sparkles className="w-10 h-10 text-[#f3cb7b] star-pulse" />
              </div>

              <h2 className="font-serif text-2xl md:text-3xl text-center font-semibold mb-2 text-[#f8f9fa] tracking-tight">
                What is your earthly name?
              </h2>
              <p className="text-xs text-center text-[#f3cb7b] font-mono tracking-widest uppercase mb-8">
                Phase I: The Celestial Invitation
              </p>

              <div className="relative mb-6">
                <input
                  type="text"
                  required
                  placeholder="Enter your name"
                  value={profile.name}
                  onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                  onKeyDown={(e) => { if (e.key === "Enter") handleOnboardingNext(); }}
                  className="w-full bg-[rgba(10,6,18,0.6)] border border-[rgba(243,203,123,0.2)] focus:border-[#f3cb7b] text-center rounded-xl px-4 py-4 text-lg font-serif outline-none transition-all placeholder-[rgba(248,249,252,0.2)] text-[#f8f9fa]"
                  id="earthly-name-input"
                />
              </div>

              {error && (
                <div className="text-red-400 text-xs mb-4 text-center flex items-center justify-center gap-1.5 font-mono">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  {error}
                </div>
              )}

              <button
                onClick={handleOnboardingNext}
                className="w-full py-4 bg-[#f3cb7b] hover:bg-[#ebd094] text-[#0a0612] rounded-xl font-medium flex items-center justify-center gap-2 shadow-lg transition-all transform hover:scale-[1.01] active:scale-[0.99] cursor-pointer"
                id="next-step-1"
              >
                Proceed into the Cosmos
                <ChevronRight className="w-4 h-4" />
              </button>
            </motion.div>
          )}

          {/* STEP 2: ONBOARDING ARRIVAL */}
          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4 }}
              className="max-w-md w-full mx-auto glass-panel p-8 rounded-2xl relative overflow-hidden"
              id="onboarding-step-2"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-[rgba(243,203,123,0.1)]">
                <div className="w-2/4 h-full bg-[#f3cb7b]" />
              </div>

              <div className="flex justify-center mb-6">
                <Clock className="w-10 h-10 text-[#f3cb7b] star-pulse" />
              </div>

              <h2 className="font-serif text-2xl md:text-3xl text-center font-semibold mb-2 text-[#f8f9fa] tracking-tight">
                When did your soul arrive?
              </h2>
              <p className="text-xs text-center text-[#f3cb7b] font-mono tracking-widest uppercase mb-8">
                Phase II: The Alignment of Time
              </p>

              <div className="space-y-4 mb-6">
                <div className="flex flex-col gap-1.5 text-left">
                  <label className="text-xs font-mono uppercase text-[rgba(248,249,252,0.5)] tracking-wider">Date of Arrival</label>
                  <input
                    type="date"
                    required
                    value={profile.birthDate}
                    onChange={(e) => setProfile({ ...profile, birthDate: e.target.value })}
                    className="w-full bg-[rgba(10,6,18,0.6)] border border-[rgba(243,203,123,0.2)] focus:border-[#f3cb7b] rounded-xl px-4 py-3 text-sm outline-none transition-all text-[#f8f9fa]"
                    id="birth-date-input"
                  />
                </div>

                <div className="flex flex-col gap-1.5 text-left">
                  <label className="text-xs font-mono uppercase text-[rgba(248,249,252,0.5)] tracking-wider">Exact Moment (Birth Time)</label>
                  <input
                    type="time"
                    required
                    value={profile.birthTime}
                    onChange={(e) => setProfile({ ...profile, birthTime: e.target.value })}
                    className="w-full bg-[rgba(10,6,18,0.6)] border border-[rgba(243,203,123,0.2)] focus:border-[#f3cb7b] rounded-xl px-4 py-3 text-sm outline-none transition-all text-[#f8f9fa]"
                    id="birth-time-input"
                  />
                </div>
              </div>

              {error && (
                <div className="text-red-400 text-xs mb-4 text-center flex items-center justify-center gap-1.5 font-mono">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  {error}
                </div>
              )}

              <div className="flex gap-3">
                <button
                  onClick={() => setStep(1)}
                  className="flex-1 py-4 border border-[rgba(243,203,123,0.2)] hover:bg-[rgba(255,255,255,0.05)] rounded-xl font-medium text-xs font-mono uppercase tracking-widest transition-all cursor-pointer"
                >
                  Back
                </button>
                <button
                  onClick={handleOnboardingNext}
                  className="flex-[2] py-4 bg-[#f3cb7b] hover:bg-[#ebd094] text-[#0a0612] rounded-xl font-medium flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer"
                  id="next-step-2"
                >
                  Verify Coordinates
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          )}

          {/* STEP 3: ONBOARDING PLACE */}
          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4 }}
              className="max-w-md w-full mx-auto glass-panel p-8 rounded-2xl relative overflow-hidden"
              id="onboarding-step-3"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-[rgba(243,203,123,0.1)]">
                <div className="w-3/4 h-full bg-[#f3cb7b]" />
              </div>

              <div className="flex justify-center mb-6">
                <MapPin className="w-10 h-10 text-[#f3cb7b] star-pulse" />
              </div>

              <h2 className="font-serif text-2xl md:text-3xl text-center font-semibold mb-2 text-[#f8f9fa] tracking-tight">
                Where did the stars align?
              </h2>
              <p className="text-xs text-center text-[#f3cb7b] font-mono tracking-widest uppercase mb-8">
                Phase III: The Geographical Anchor
              </p>

              <div className="relative mb-6">
                <input
                  type="text"
                  required
                  placeholder="City, Country of Birth"
                  value={profile.birthPlace}
                  onChange={(e) => setProfile({ ...profile, birthPlace: e.target.value })}
                  onKeyDown={(e) => { if (e.key === "Enter") handleOnboardingNext(); }}
                  className="w-full bg-[rgba(10,6,18,0.6)] border border-[rgba(243,203,123,0.2)] focus:border-[#f3cb7b] text-center rounded-xl px-4 py-4 text-lg font-serif outline-none transition-all placeholder-[rgba(248,249,252,0.2)] text-[#f8f9fa]"
                  id="birth-place-input"
                />
              </div>

              {error && (
                <div className="text-red-400 text-xs mb-4 text-center flex items-center justify-center gap-1.5 font-mono">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  {error}
                </div>
              )}

              <div className="flex gap-3">
                <button
                  onClick={() => setStep(2)}
                  className="flex-1 py-4 border border-[rgba(243,203,123,0.2)] hover:bg-[rgba(255,255,255,0.05)] rounded-xl font-medium text-xs font-mono uppercase tracking-widest transition-all cursor-pointer"
                >
                  Back
                </button>
                <button
                  onClick={handleOnboardingNext}
                  className="flex-[2] py-4 bg-[#f3cb7b] hover:bg-[#ebd094] text-[#0a0612] rounded-xl font-medium flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer"
                  id="next-step-3"
                >
                  Calibrate Heavens
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          )}

          {/* STEP 4: GUIDANCE CARD SELECT */}
          {step === 4 && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4 }}
              className="max-w-2xl w-full mx-auto glass-panel p-8 rounded-2xl relative overflow-hidden text-center"
              id="onboarding-step-4"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-[rgba(243,203,123,0.1)]">
                <div className="w-full h-full bg-[#f3cb7b]" />
              </div>

              <div className="flex justify-center mb-4">
                <Compass className="w-12 h-12 text-[#f3cb7b] spin-celestial" />
              </div>

              <h2 className="font-serif text-2xl md:text-3xl font-semibold mb-2 text-[#f8f9fa] tracking-tight">
                What cosmic guidance do you seek today?
              </h2>
              <p className="text-xs text-[#f3cb7b] font-mono tracking-widest uppercase mb-8">
                Phase IV: The Spiritual Request
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                {/* 💖 LOVE CARD */}
                <button
                  onClick={() => handleSelectGuidance("Love")}
                  className="glass-panel hover:bg-[rgba(243,203,123,0.05)] hover:border-[#f3cb7b] hover:shadow-[0_0_15px_rgba(243,203,123,0.15)] rounded-xl p-5 flex flex-col items-center gap-3 transition-all cursor-pointer group"
                >
                  <div className="w-12 h-12 rounded-full bg-[rgba(244,63,94,0.1)] border border-[rgba(244,63,94,0.3)] flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Heart className="w-6 h-6 text-rose-400 fill-rose-400/10" />
                  </div>
                  <h3 className="font-serif text-lg font-semibold text-[#f8f9fa] group-hover:text-[#f3cb7b] transition-colors">💖 Love & Alignment</h3>
                  <p className="text-xs text-gray-400 leading-relaxed">
                    Explore compatibility, karmic romance cycles, and deep heart expansion.
                  </p>
                </button>

                {/* 💼 DESTINY CARD */}
                <button
                  onClick={() => handleSelectGuidance("Destiny/Career")}
                  className="glass-panel hover:bg-[rgba(243,203,123,0.05)] hover:border-[#f3cb7b] hover:shadow-[0_0_15px_rgba(243,203,123,0.15)] rounded-xl p-5 flex flex-col items-center gap-3 transition-all cursor-pointer group"
                >
                  <div className="w-12 h-12 rounded-full bg-[rgba(14,165,233,0.1)] border border-[rgba(14,165,233,0.3)] flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Briefcase className="w-6 h-6 text-sky-400" />
                  </div>
                  <h3 className="font-serif text-lg font-semibold text-[#f8f9fa] group-hover:text-[#f3cb7b] transition-colors">💼 Destiny & Career</h3>
                  <p className="text-xs text-gray-400 leading-relaxed">
                    Calibrate professional growth, leadership houses, and Saturn transitions.
                  </p>
                </button>

                {/* 🪙 WEALTH CARD */}
                <button
                  onClick={() => handleSelectGuidance("Wealth")}
                  className="glass-panel hover:bg-[rgba(243,203,123,0.05)] hover:border-[#f3cb7b] hover:shadow-[0_0_15px_rgba(243,203,123,0.15)] rounded-xl p-5 flex flex-col items-center gap-3 transition-all cursor-pointer group"
                >
                  <div className="w-12 h-12 rounded-full bg-[rgba(234,179,8,0.1)] border border-[rgba(234,179,8,0.3)] flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Coins className="w-6 h-6 text-yellow-400" />
                  </div>
                  <h3 className="font-serif text-lg font-semibold text-[#f8f9fa] group-hover:text-[#f3cb7b] transition-colors">🪙 Material Prosperity</h3>
                  <p className="text-xs text-gray-400 leading-relaxed">
                    Invite abundance streams and understand Jupiter transits over your finances.
                  </p>
                </button>

                {/* 🔮 SPIRITUAL GROWTH CARD */}
                <button
                  onClick={() => handleSelectGuidance("Spiritual Growth")}
                  className="glass-panel hover:bg-[rgba(243,203,123,0.05)] hover:border-[#f3cb7b] hover:shadow-[0_0_15px_rgba(243,203,123,0.15)] rounded-xl p-5 flex flex-col items-center gap-3 transition-all cursor-pointer group"
                >
                  <div className="w-12 h-12 rounded-full bg-[rgba(168,85,247,0.1)] border border-[rgba(168,85,247,0.3)] flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Sparkles className="w-6 h-6 text-purple-400" />
                  </div>
                  <h3 className="font-serif text-lg font-semibold text-[#f8f9fa] group-hover:text-[#f3cb7b] transition-colors">🔮 Spiritual Growth</h3>
                  <p className="text-xs text-gray-400 leading-relaxed">
                    Uncover unconscious patterns, Neptunian messages, and aura alignment.
                  </p>
                </button>
              </div>

              <div className="flex justify-center">
                <button
                  onClick={() => setStep(3)}
                  className="px-6 py-2 border border-[rgba(243,203,123,0.15)] hover:bg-[rgba(255,255,255,0.05)] rounded-full text-xs font-mono uppercase tracking-widest transition-all cursor-pointer"
                >
                  Back to Anchor
                </button>
              </div>
            </motion.div>
          )}

          {/* TIMED LOADING SCREEN: CELESTIAL DIAL */}
          {step === "loading" && (
            <motion.div
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="max-w-md w-full mx-auto flex flex-col items-center justify-center text-center p-8"
              id="celestial-aligning-loader"
            >
              {/* Spinning Celestial Dial */}
              <div className="relative w-48 h-48 mb-8 flex items-center justify-center">
                <div className="absolute inset-0 rounded-full border border-dashed border-[rgba(243,203,123,0.3)] spin-celestial" />
                <div className="absolute w-40 h-40 rounded-full border border-double border-[rgba(243,203,123,0.15)] flex items-center justify-center" />
                <div className="absolute w-28 h-28 rounded-full border border-dashed border-[rgba(243,203,123,0.25)] animate-spin [animation-duration:15s]" />
                <Compass className="w-16 h-16 text-[#f3cb7b] animate-pulse star-pulse" />
              </div>

              <h3 className="font-serif text-2xl font-medium text-gold-gradient mb-3">
                Aligning the Planets...
              </h3>

              {/* Staggered text rotator */}
              <div className="h-6 flex items-center justify-center">
                <AnimatePresence mode="wait">
                  <motion.p
                    key={loadingMsgIdx}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    transition={{ duration: 0.2 }}
                    className="text-xs text-gray-400 font-mono italic"
                  >
                    {loadingMessages[loadingMsgIdx]}
                  </motion.p>
                </AnimatePresence>
              </div>
            </motion.div>
          )}

          {/* MAIN COSMIC DASHBOARD (3-COLUMN GRID) */}
          {step === "dashboard" && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-6 w-full items-start"
              id="cosmic-dashboard-layout"
            >
              {/* --- COLUMN 1: SIDEBAR (NATAL BLUEPRINT) [3 cols] --- */}
              <div className="lg:col-span-3 flex flex-col gap-6">
                <div className="glass-panel p-6 rounded-2xl flex flex-col gap-5 relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-4 opacity-5">
                    <Compass className="w-32 h-32 text-[#f3cb7b] spin-celestial" />
                  </div>

                  <div>
                    <h3 className="font-serif text-base text-[#f3cb7b] uppercase tracking-wider font-light">
                      Natal Blueprint
                    </h3>
                  </div>

                  <div className="border-b border-[rgba(243,203,123,0.15)] pb-4 text-left">
                    <p className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">Earthling</p>
                    <p className="font-serif text-lg text-[#f8f9fa]">{profile.name}</p>
                    <p className="text-xs text-gray-400 flex items-center gap-1 mt-1.5 font-mono">
                      <MapPin className="w-3.5 h-3.5 text-[#f3cb7b]" />
                      {profile.birthPlace}
                    </p>
                    <p className="text-[11px] text-gray-500 flex items-center gap-1 mt-1 font-mono">
                      <Clock className="w-3.5 h-3.5 text-[#f3cb7b]" />
                      {profile.birthDate} at {profile.birthTime}
                    </p>
                  </div>

                  {/* SIGN INTERACTIVE STACKS */}
                  <div className="space-y-5 text-left">
                    {/* SUN SIGN */}
                    <button
                      onClick={() => {
                        setActiveSignKey(activeSignKey === "sun" ? null : "sun");
                      }}
                      className={`w-full text-left p-3.5 rounded-xl transition-all cursor-pointer border ${
                        activeSignKey === "sun"
                          ? "bg-[rgba(243,203,123,0.12)] border-[#f3cb7b] shadow-[0_0_15px_rgba(243,203,123,0.15)]"
                          : "bg-transparent border-transparent hover:bg-[rgba(243,203,123,0.03)] hover:border-[rgba(243,203,123,0.1)]"
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-3xl block text-[#f3cb7b] mb-1">☉</span>
                          <span className="text-xs text-gray-400 font-mono uppercase tracking-wider block">Sun Sign</span>
                          <span className="font-serif text-lg text-white block mt-0.5">{profile.sunSign}</span>
                          <span className="text-[11px] text-[rgba(248,249,250,0.6)] block mt-1">
                            {SIGN_MATRIX[profile.sunSign]?.title.split(" — ")[1] || "The Spark of Identity"}
                          </span>
                        </div>
                        <ChevronDown className={`w-4 h-4 text-[#f3cb7b] mt-1.5 transition-transform duration-300 ${activeSignKey === "sun" ? "rotate-180" : ""}`} />
                      </div>
                    </button>

                    {/* MOON SIGN */}
                    <button
                      onClick={() => {
                        setActiveSignKey(activeSignKey === "moon" ? null : "moon");
                      }}
                      className={`w-full text-left p-3.5 rounded-xl transition-all cursor-pointer border ${
                        activeSignKey === "moon"
                          ? "bg-[rgba(243,203,123,0.12)] border-[#f3cb7b] shadow-[0_0_15px_rgba(243,203,123,0.15)]"
                          : "bg-transparent border-transparent hover:bg-[rgba(243,203,123,0.03)] hover:border-[rgba(243,203,123,0.1)]"
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-3xl block text-[#f3cb7b] mb-1">☽</span>
                          <span className="text-xs text-gray-400 font-mono uppercase tracking-wider block">Moon Sign</span>
                          <span className="font-serif text-lg text-white block mt-0.5">{profile.moonSign}</span>
                          <span className="text-[11px] text-[rgba(248,249,250,0.6)] block mt-1">
                            {SIGN_MATRIX[profile.moonSign]?.title.split(" — ")[1] || "Deep Emotional Current"}
                          </span>
                        </div>
                        <ChevronDown className={`w-4 h-4 text-[#f3cb7b] mt-1.5 transition-transform duration-300 ${activeSignKey === "moon" ? "rotate-180" : ""}`} />
                      </div>
                    </button>

                    {/* ASCENDANT */}
                    <button
                      onClick={() => {
                        setActiveSignKey(activeSignKey === "ascendant" ? null : "ascendant");
                      }}
                      className={`w-full text-left p-3.5 rounded-xl transition-all cursor-pointer border ${
                        activeSignKey === "ascendant"
                          ? "bg-[rgba(243,203,123,0.12)] border-[#f3cb7b] shadow-[0_0_15px_rgba(243,203,123,0.15)]"
                          : "bg-transparent border-transparent hover:bg-[rgba(243,203,123,0.03)] hover:border-[rgba(243,203,123,0.1)]"
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-xs font-mono font-bold tracking-widest uppercase bg-[#f3cb7b]/10 text-[#f3cb7b] px-2 py-0.5 rounded border border-[#f3cb7b]/20 mb-2 inline-block">Rising</span>
                          <span className="text-xs text-gray-400 font-mono uppercase tracking-wider block">Ascendant</span>
                          <span className="font-serif text-lg text-white block mt-0.5">{profile.ascendantSign}</span>
                          <span className="text-[11px] text-[rgba(248,249,250,0.6)] block mt-1">
                            {SIGN_MATRIX[profile.ascendantSign]?.title.split(" — ")[1] || "The Outer Mask"}
                          </span>
                        </div>
                        <ChevronDown className={`w-4 h-4 text-[#f3cb7b] mt-1.5 transition-transform duration-300 ${activeSignKey === "ascendant" ? "rotate-180" : ""}`} />
                      </div>
                    </button>
                  </div>

                  {/* RESET BUTTON */}
                  <div className="pt-2">
                    <button
                      onClick={handleResetProfile}
                      className="w-full py-2 bg-[rgba(255,100,100,0.05)] border border-[rgba(255,100,100,0.15)] hover:bg-[rgba(255,100,100,0.1)] text-red-300 text-xs font-mono uppercase tracking-widest rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3" />
                      Reset Aura Matrix
                    </button>
                  </div>
                </div>

                {/* SIGN PERSONALITY MATRIX DRAWER PANEL */}
                <AnimatePresence>
                  {activeSignKey && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="glass-panel rounded-2xl overflow-hidden border border-[#f3cb7b]/30 shadow-[0_0_20px_rgba(243,203,123,0.1)] text-left"
                    >
                      {(() => {
                        const signName =
                          activeSignKey === "sun"
                            ? profile.sunSign
                            : activeSignKey === "moon"
                            ? profile.moonSign
                            : profile.ascendantSign;
                        const detail: SignMatrixDetail = SIGN_MATRIX[signName] || SIGN_MATRIX["Aries"];
                        return (
                          <div className="p-5 flex flex-col gap-4">
                            <div className="flex items-center justify-between pb-2 border-b border-[rgba(243,203,123,0.15)]">
                              <span className="font-serif text-base font-semibold text-gold-gradient">
                                {detail.title}
                              </span>
                              <span className="text-[9px] font-mono uppercase bg-[#f3cb7b]/10 text-[#f3cb7b] px-2 py-0.5 rounded-full border border-[#f3cb7b]/20">
                                {activeSignKey} sign
                              </span>
                            </div>

                            <div className="grid grid-cols-3 gap-2 text-center text-[10px] font-mono text-[#f3cb7b] bg-[rgba(10,6,18,0.4)] p-2 rounded-lg border border-[rgba(243,203,123,0.05)]">
                              <div>
                                <span className="text-gray-500 block">ELEMENT</span>
                                <span className="font-semibold text-white">{detail.element}</span>
                              </div>
                              <div>
                                <span className="text-gray-500 block">QUALITY</span>
                                <span className="font-semibold text-white">{detail.quality}</span>
                              </div>
                              <div>
                                <span className="text-gray-500 block">RULING</span>
                                <span className="font-semibold text-white">{detail.rulingPlanet}</span>
                              </div>
                            </div>

                            <p className="text-xs text-gray-300 leading-relaxed font-sans italic">
                              "{detail.description}"
                            </p>

                            <div className="space-y-1.5">
                              <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest block">Core Strengths</span>
                              <div className="flex flex-wrap gap-1.5">
                                {detail.strengths.map((s, i) => (
                                  <span key={i} className="text-[10px] font-mono bg-[rgba(243,203,123,0.08)] border border-[rgba(243,203,123,0.15)] px-2 py-0.5 rounded-md text-[#ebd094]">
                                    ✦ {s}
                                  </span>
                                ))}
                              </div>
                            </div>

                            <div className="text-[11px] font-serif text-[#ebd094] pt-2 border-t border-[rgba(243,203,123,0.05)] flex items-center gap-1">
                              <span>Vibe:</span>
                              <span className="text-gray-300 font-sans">{detail.vibe}</span>
                            </div>
                          </div>
                        );
                      })()}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* --- COLUMN 2: CENTER (TABBED ASTROLOGER FEED) [5 cols] --- */}
              <div className="lg:col-span-5 flex flex-col gap-5 text-left">
                
                {/* TABS SELECTOR - Social Media App Presets */}
                <div className="flex bg-[rgba(10,6,18,0.5)] border border-[rgba(243,203,123,0.15)] rounded-full p-1 gap-1">
                  <button
                    onClick={() => setActiveTab("daily")}
                    className={`flex-1 py-2 text-center rounded-full text-xs font-mono uppercase tracking-widest transition-all cursor-pointer ${
                      activeTab === "daily"
                        ? "bg-[#f3cb7b] text-[#0a0612] font-semibold shadow-md"
                        : "text-gray-400 hover:text-[#f3cb7b] hover:bg-white/5"
                    }`}
                  >
                    Daily
                  </button>
                  <button
                    onClick={() => setActiveTab("weekly")}
                    className={`flex-1 py-2 text-center rounded-full text-xs font-mono uppercase tracking-widest transition-all cursor-pointer ${
                      activeTab === "weekly"
                        ? "bg-[#f3cb7b] text-[#0a0612] font-semibold shadow-md"
                        : "text-gray-400 hover:text-[#f3cb7b] hover:bg-white/5"
                    }`}
                  >
                    Feed
                  </button>
                  <button
                    onClick={() => setActiveTab("compatibility")}
                    className={`flex-1 py-2 text-center rounded-full text-xs font-mono uppercase tracking-widest transition-all cursor-pointer ${
                      activeTab === "compatibility"
                        ? "bg-[#f3cb7b] text-[#0a0612] font-semibold shadow-md"
                        : "text-gray-400 hover:text-[#f3cb7b] hover:bg-white/5"
                    }`}
                  >
                    Synastry
                  </button>
                  <button
                    onClick={() => setActiveTab("destiny")}
                    className={`flex-1 py-2 text-center rounded-full text-xs font-mono uppercase tracking-widest transition-all cursor-pointer ${
                      activeTab === "destiny"
                        ? "bg-[#f3cb7b] text-[#0a0612] font-semibold shadow-md"
                        : "text-gray-400 hover:text-[#f3cb7b] hover:bg-white/5"
                    }`}
                  >
                    Destiny
                  </button>
                </div>

                {/* TAB 1: DAILY FLOW */}
                {activeTab === "daily" && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex flex-col gap-6"
                  >
                    {/* THE CURRENT SKIES */}
                    <div className="glass-panel p-6 rounded-2xl relative overflow-hidden">
                      <div className="flex items-center justify-between mb-2 pb-3 border-b border-[rgba(243,203,123,0.15)]">
                        <h3 className="font-serif text-base text-[#f3cb7b] uppercase tracking-wider font-light">
                          The Daily Flow
                        </h3>
                        <button
                          onClick={() => setShowShareModal(true)}
                          className="flex items-center gap-1.5 text-[11px] font-mono text-[#f3cb7b] hover:text-[#ebd094] border border-[#f3cb7b]/30 bg-[#f3cb7b]/5 hover:bg-[#f3cb7b]/10 px-2.5 py-1 rounded-full transition-all cursor-pointer"
                        >
                          <Share2 className="w-3 h-3" />
                          Share Story
                        </button>
                      </div>

                      {transitLoading ? (
                        <div className="py-12 flex flex-col items-center justify-center gap-3">
                          <Compass className="w-8 h-8 text-[#f3cb7b] animate-spin" />
                          <p className="text-xs font-mono text-gray-400">Consulting cosmic tides...</p>
                        </div>
                      ) : transitData ? (
                        <div className="space-y-4">
                          <p className="text-sm md:text-base text-[rgba(248,249,250,0.9)] leading-relaxed italic border-l border-[#f3cb7b] pl-4 mt-4 font-serif">
                            {transitData.transitText}
                          </p>

                          {transitData.isSimulated && (
                            <p className="text-[10px] font-mono text-[rgba(243,203,123,0.4)] italic">
                              ✦ Celestial telemetry calculated offline
                            </p>
                          )}
                        </div>
                      ) : (
                        <div className="py-8 text-center text-xs text-gray-500">
                          No transit details fetched.
                        </div>
                      )}
                    </div>

                    {/* EMBRACE & EVADE */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="glass-panel p-5 rounded-2xl border-t border-[rgba(243,203,123,0.15)]">
                        <h4 className="text-[11px] uppercase text-[#86efac] mb-3 tracking-widest font-mono">✦ Embrace</h4>
                        {transitLoading ? (
                          <div className="space-y-2">
                            <div className="h-3 bg-gray-800 rounded animate-pulse w-5/6" />
                            <div className="h-3 bg-gray-800 rounded animate-pulse w-3/4" />
                          </div>
                        ) : transitData ? (
                          <div className="space-y-2">
                            {transitData.embrace.map((item, idx) => (
                              <div key={idx} className="flex items-center gap-2.5 text-[13px] text-gray-200">
                                <span className="w-1 h-1 rounded-full bg-[#86efac] inline-block" />
                                <span>{item}</span>
                              </div>
                            ))}
                          </div>
                        ) : null}
                      </div>

                      <div className="glass-panel p-5 rounded-2xl border-t border-[rgba(243,203,123,0.15)]">
                        <h4 className="text-[11px] uppercase text-[#fca5a5] mb-3 tracking-widest font-mono">✦ Evade</h4>
                        {transitLoading ? (
                          <div className="space-y-2">
                            <div className="h-3 bg-gray-800 rounded animate-pulse w-5/6" />
                            <div className="h-3 bg-gray-800 rounded animate-pulse w-3/4" />
                          </div>
                        ) : transitData ? (
                          <div className="space-y-2">
                            {transitData.evade.map((item, idx) => (
                              <div key={idx} className="flex items-center gap-2.5 text-[13px] text-gray-200">
                                <span className="w-1 h-1 rounded-full bg-[#fca5a5] inline-block" />
                                <span>{item}</span>
                              </div>
                            ))}
                          </div>
                        ) : null}
                      </div>
                    </div>

                    {/* COSMIC VITALS */}
                    <div className="glass-panel p-6 rounded-2xl">
                      <div className="flex items-center gap-2 mb-4 pb-2 border-b border-[rgba(243,203,123,0.15)]">
                        <Activity className="w-4 h-4 text-[#f3cb7b] animate-pulse" />
                        <h3 className="font-serif text-sm text-[#ebd094] uppercase tracking-wider font-light">
                          Celestial Vitals
                        </h3>
                      </div>

                      {transitLoading ? (
                        <div className="space-y-4">
                          <div className="h-4 bg-gray-800 rounded animate-pulse" />
                          <div className="h-4 bg-gray-800 rounded animate-pulse" />
                        </div>
                      ) : transitData ? (
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                            <div className="text-center bg-[rgba(243,203,123,0.05)] p-3 rounded-lg border border-[rgba(243,203,123,0.1)] flex flex-col items-center justify-center">
                              <span className="font-serif text-lg text-[#f3cb7b] font-normal block mb-1">{transitData.vitals.love}%</span>
                              <span className="text-[10px] text-[rgba(248,249,250,0.6)] uppercase tracking-wider font-mono">Love</span>
                            </div>
                            <div className="text-center bg-[rgba(243,203,123,0.05)] p-3 rounded-lg border border-[rgba(243,203,123,0.1)] flex flex-col items-center justify-center">
                              <span className="font-serif text-lg text-[#f3cb7b] font-normal block mb-1">{transitData.vitals.career}%</span>
                              <span className="text-[10px] text-[rgba(248,249,250,0.6)] uppercase tracking-wider font-mono">Career</span>
                            </div>
                            <div className="text-center bg-[rgba(243,203,123,0.05)] p-3 rounded-lg border border-[rgba(243,203,123,0.1)] flex flex-col items-center justify-center">
                              <span className="font-serif text-lg text-[#f3cb7b] font-normal block mb-1">{transitData.vitals.wealth}%</span>
                              <span className="text-[10px] text-[rgba(248,249,250,0.6)] uppercase tracking-wider font-mono">Wealth</span>
                            </div>
                            <div className="text-center bg-[rgba(243,203,123,0.05)] p-3 rounded-lg border border-[rgba(243,203,123,0.1)] flex flex-col items-center justify-center">
                              <span className="font-serif text-lg text-[#f3cb7b] font-normal block mb-1">{transitData.vitals.energy}%</span>
                              <span className="text-[10px] text-[rgba(248,249,250,0.6)] uppercase tracking-wider font-mono">Energy</span>
                            </div>
                          </div>

                          <div className="mt-4 p-4 rounded-xl bg-[rgba(243,203,123,0.03)] border border-dashed border-[rgba(243,203,123,0.2)] text-left">
                            <span className="text-[11px] font-mono uppercase tracking-widest text-[#f3cb7b] block mb-1">✦ Oracle Warning</span>
                            <span className="text-xs text-gray-400 leading-relaxed">
                              A solar flare in your solar 8th house suggests hidden truths regarding a shared resource will surface tonight. Trust your inner alignment.
                            </span>
                          </div>
                        </div>
                      ) : null}
                    </div>
                  </motion.div>
                )}

                {/* TAB 2: WEEKLY FEED (Social Media Styled Astrology Posts) */}
                {activeTab === "weekly" && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex flex-col gap-5"
                  >
                    {[
                      {
                        id: "feed-1",
                        title: "Mercury Trine Jupiter",
                        tag: "COSMIC CLARITY",
                        date: "July 15, 2026",
                        content: "An alignment of cosmic giants opens the floodgates of intellect and fortune. Today, your thoughts hold genuine gravitational mass. Write down that radical idea you've been dismissing before your inner critic awakens.",
                        vibe: "Creative high, bold expressions",
                        doText: "Say yes to random invitations",
                        dontText: "Overthink your vocabulary"
                      },
                      {
                        id: "feed-2",
                        title: "Venus enters Leo",
                        tag: "PROTAGONIST ENERGY",
                        date: "July 17, 2026",
                        content: "The planet of love sashays into the house of the theatrical Sun. The cosmic spotlight is casting warm, dramatic shadows. Romance ceases to be quiet; it becomes a grand parade. Dress like you are being filmed.",
                        vibe: "Maximalist romance, high drama",
                        doText: "Wear bold accessories or colors",
                        dontText: "Accept low-effort messages"
                      },
                      {
                        id: "feed-3",
                        title: "Full Moon in Scorpio",
                        tag: "PSYCHIC PURGE",
                        date: "July 20, 2026",
                        content: "The emotional high-tide peak of the month. Scorpio forces raw, buried feelings from your deep sub-oceanic trenches. Secrets feel too heavy to carry. It's time to release, even if it leaves a scar.",
                        vibe: "Cathartic relief, raw truth",
                        doText: "Cry in a hot shower, let it go",
                        dontText: "Stalk your old flames at 2 AM"
                      }
                    ].map((post) => (
                      <div key={post.id} className="glass-panel p-5 rounded-2xl relative overflow-hidden flex flex-col gap-3.5 border-l-2 border-[#f3cb7b]/40">
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] font-mono text-[#f3cb7b] tracking-widest uppercase bg-[#f3cb7b]/10 border border-[#f3cb7b]/20 px-2 py-0.5 rounded">
                            {post.tag}
                          </span>
                          <span className="text-[10px] font-mono text-gray-500">{post.date}</span>
                        </div>

                        <div>
                          <h4 className="font-serif text-lg text-white font-medium mb-1.5">{post.title}</h4>
                          <p className="text-xs text-gray-300 leading-relaxed">{post.content}</p>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-[11px] font-mono pt-3 border-t border-[rgba(243,203,123,0.1)]">
                          <div>
                            <span className="text-[#86efac] uppercase block text-[9px] tracking-wider">Do</span>
                            <span className="text-gray-400">{post.doText}</span>
                          </div>
                          <div>
                            <span className="text-[#fca5a5] uppercase block text-[9px] tracking-wider">Don't</span>
                            <span className="text-gray-400">{post.dontText}</span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-[11px] font-mono text-[#ebd094] pt-2">
                          <span>Vibe: <strong className="text-white font-normal">{post.vibe}</strong></span>
                          <button
                            onClick={() => setShowShareModal(true)}
                            className="text-[10px] text-gray-400 hover:text-[#f3cb7b] flex items-center gap-1 cursor-pointer bg-transparent border-0 outline-none"
                          >
                            <Share2 className="w-3 h-3" /> Share Post
                          </button>
                        </div>
                      </div>
                    ))}
                  </motion.div>
                )}

                {/* TAB 3: SYNASTRY (COMPATIBILITY ENGINE) */}
                {activeTab === "compatibility" && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="glass-panel p-6 rounded-2xl flex flex-col gap-5 relative overflow-hidden"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Users className="w-5 h-5 text-[#f3cb7b]" />
                        <h3 className="font-serif text-lg text-[#ebd094] uppercase tracking-wider font-light">
                          Cosmic Synastry
                        </h3>
                      </div>
                      <p className="text-xs text-gray-400">
                        Measure your planetary geometry against friends, crushes, or partners.
                      </p>
                    </div>

                    {!compatibilityResult ? (
                      <div className="flex flex-col gap-4 text-left">
                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] font-mono uppercase text-gray-400 tracking-wider">Target's Name</label>
                          <input
                            type="text"
                            placeholder="Enter their name"
                            value={friendName}
                            onChange={(e) => setFriendName(e.target.value)}
                            className="w-full bg-[rgba(10,6,18,0.6)] border border-[rgba(243,203,123,0.2)] focus:border-[#f3cb7b] rounded-xl px-4 py-3 text-sm outline-none transition-all text-[#f8f9fa]"
                          />
                        </div>

                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] font-mono uppercase text-gray-400 tracking-wider">Target's Sun Sign</label>
                          <select
                            value={friendSunSign}
                            onChange={(e) => setFriendSunSign(e.target.value)}
                            className="w-full bg-[rgba(10,6,18,0.9)] border border-[rgba(243,203,123,0.2)] focus:border-[#f3cb7b] rounded-xl px-4 py-3 text-sm outline-none transition-all text-[#f8f9fa] cursor-pointer"
                          >
                            {["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"].map((sign) => (
                              <option key={sign} value={sign} className="bg-[#0a0612] text-white">{sign}</option>
                            ))}
                          </select>
                        </div>

                        <button
                          onClick={handleCompatibilityCheck}
                          disabled={compatLoading || !friendName.trim()}
                          className="w-full py-3.5 bg-[#f3cb7b] hover:bg-[#ebd094] disabled:bg-[rgba(243,203,123,0.2)] disabled:text-gray-500 text-[#0a0612] rounded-xl font-medium text-sm flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer border-none"
                        >
                          {compatLoading ? (
                            <>
                              <Compass className="w-4 h-4 animate-spin" />
                              Aligning Horoscopes...
                            </>
                          ) : (
                            <>
                              <Sparkles className="w-4 h-4" />
                              Calculate Compatibility
                            </>
                          )}
                        </button>
                      </div>
                    ) : (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.98 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="space-y-5 text-left"
                      >
                        {/* Circle Score Presentation */}
                        <div className="flex flex-col items-center justify-center py-4 bg-[rgba(243,203,123,0.03)] rounded-xl border border-[rgba(243,203,123,0.1)]">
                          <div className="relative w-24 h-24 flex items-center justify-center rounded-full border border-dashed border-[#f3cb7b]/40">
                            <span className="font-serif text-3xl font-light text-gold-gradient">{compatibilityResult.matchPercentage}%</span>
                            <div className="absolute inset-1.5 rounded-full border border-double border-[#f3cb7b]/20" />
                          </div>
                          <span className="text-[11px] font-mono text-gray-400 uppercase tracking-widest mt-2">Cosmic Synergy</span>
                        </div>

                        {/* Attribute Progresses */}
                        <div className="space-y-3">
                          {[
                            { name: "Intellectual Flow", value: compatibilityResult.communicationScore, color: "from-sky-500 to-indigo-400" },
                            { name: "Chemistry / Spark", value: compatibilityResult.chemistryScore, color: "from-rose-500 to-rose-400" },
                            { name: "Destiny Alignment", value: compatibilityResult.destinyScore, color: "from-yellow-500 to-[#ebd094]" }
                          ].map((attr, idx) => (
                            <div key={idx} className="space-y-1 text-xs">
                              <div className="flex justify-between font-mono text-gray-400 text-[10px] uppercase">
                                <span>{attr.name}</span>
                                <span className="text-[#f3cb7b]">{attr.value}%</span>
                              </div>
                              <div className="h-1.5 bg-black/40 rounded-full overflow-hidden border border-[rgba(243,203,123,0.05)]">
                                <motion.div
                                  initial={{ width: 0 }}
                                  animate={{ width: `${attr.value}%` }}
                                  transition={{ duration: 0.8 }}
                                  className={`h-full bg-gradient-to-r ${attr.color}`}
                                />
                              </div>
                            </div>
                          ))}
                        </div>

                        {/* Co-Star Witty Readout */}
                        <div className="border-t border-[rgba(243,203,123,0.15)] pt-4">
                          <h4 className="text-[10px] font-mono text-[#f3cb7b] uppercase tracking-widest mb-1.5">✦ Astrological Sync</h4>
                          <div className="text-sm text-gray-300 leading-relaxed font-sans">
                            {renderMarkdown(compatibilityResult.compatibilitySummary)}
                          </div>
                        </div>

                        {/* Core Mantra */}
                        <div className="p-3.5 rounded-xl bg-black/30 border border-[#f3cb7b]/15 text-center italic font-serif text-xs text-[#ebd094]">
                          "{compatibilityResult.sharedMantra}"
                        </div>

                        {/* Reset Compatibility button */}
                        <button
                          onClick={() => {
                            setFriendName("");
                            setCompatibilityResult(null);
                          }}
                          className="w-full py-2 bg-[rgba(255,255,255,0.03)] hover:bg-[rgba(255,255,255,0.06)] border border-gray-800 text-xs text-gray-400 rounded-lg font-mono transition-all uppercase cursor-pointer text-center"
                        >
                          Check Another Synergy
                        </button>
                      </motion.div>
                    )}
                  </motion.div>
                )}

                {/* TAB 4: DESTINY & LIFE ASPECTS */}
                {activeTab === "destiny" && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex flex-col gap-5"
                  >
                    <div className="glass-panel p-5 rounded-2xl relative overflow-hidden">
                      <div className="flex items-center justify-between mb-2 pb-3 border-b border-[rgba(243,203,123,0.15)]">
                        <div>
                          <h3 className="font-serif text-base text-[#f3cb7b] uppercase tracking-wider font-light">
                            Personal Destiny Matrix
                          </h3>
                          <p className="text-[10px] text-gray-400 font-mono mt-0.5">
                            Natal blueprint forecast for your life paths
                          </p>
                        </div>
                        <button
                          onClick={() => {
                            if (profile) fetchLifeForecast(profile);
                          }}
                          className="p-1.5 rounded-lg border border-[rgba(243,203,123,0.15)] hover:bg-[#f3cb7b]/10 text-[#f3cb7b] transition-all cursor-pointer"
                          title="Recalculate Destiny alignment"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {lifeForecastLoading || !lifeForecast ? (
                        <div className="py-12 flex flex-col items-center justify-center gap-3">
                          <Compass className="w-8 h-8 text-[#f3cb7b] animate-spin" />
                          <span className="text-xs font-mono text-gray-400 uppercase tracking-widest animate-pulse">
                            Decoding life matrix alignments...
                          </span>
                        </div>
                      ) : (
                        <div className="space-y-6">
                          
                          {/* Marriage */}
                          <div className="p-4 rounded-xl bg-black/40 border border-[#f3cb7b]/15 relative overflow-hidden group">
                            <div className="absolute top-0 right-0 w-24 h-24 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-rose-500/10 via-transparent to-transparent pointer-events-none" />
                            <div className="flex items-center gap-2 mb-2">
                              <Heart className="w-4 h-4 text-rose-400" />
                              <h4 className="font-serif text-sm font-semibold text-white">
                                {lifeForecast.marriage.title}
                              </h4>
                              <span className="ml-auto text-[9px] font-mono uppercase bg-rose-500/10 text-rose-300 border border-rose-500/20 px-2 py-0.5 rounded-full">
                                {lifeForecast.marriage.vibe}
                              </span>
                            </div>
                            <p className="text-xs text-gray-300 leading-relaxed font-sans">
                              {lifeForecast.marriage.reading}
                            </p>
                          </div>

                          {/* Children & Lineage */}
                          <div className="p-4 rounded-xl bg-black/40 border border-[#f3cb7b]/15 relative overflow-hidden group">
                            <div className="absolute top-0 right-0 w-24 h-24 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-purple-500/10 via-transparent to-transparent pointer-events-none" />
                            <div className="flex items-center gap-2 mb-2">
                              <User className="w-4 h-4 text-purple-400" />
                              <h4 className="font-serif text-sm font-semibold text-white">
                                {lifeForecast.children.title}
                              </h4>
                              <span className="ml-auto text-[9px] font-mono uppercase bg-purple-500/10 text-purple-300 border border-purple-500/20 px-2 py-0.5 rounded-full">
                                {lifeForecast.children.vibe}
                              </span>
                            </div>
                            <p className="text-xs text-gray-300 leading-relaxed font-sans">
                              {lifeForecast.children.reading}
                            </p>
                          </div>

                          {/* Money & Wealth */}
                          <div className="p-4 rounded-xl bg-black/40 border border-[#f3cb7b]/15 relative overflow-hidden group">
                            <div className="absolute top-0 right-0 w-24 h-24 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-[#ebd094]/10 via-transparent to-transparent pointer-events-none" />
                            <div className="flex items-center gap-2 mb-2">
                              <Coins className="w-4 h-4 text-[#f3cb7b]" />
                              <h4 className="font-serif text-sm font-semibold text-white">
                                {lifeForecast.money.title}
                              </h4>
                              <span className="ml-auto text-[9px] font-mono uppercase bg-[#f3cb7b]/10 text-[#ebd094] border border-[#f3cb7b]/20 px-2 py-0.5 rounded-full">
                                {lifeForecast.money.vibe}
                              </span>
                            </div>
                            <p className="text-xs text-gray-300 leading-relaxed font-sans">
                              {lifeForecast.money.reading}
                            </p>
                          </div>

                          {/* Dual columns for Good & Bad */}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            
                            {/* Good thing: Golden Blessing */}
                            <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20 relative overflow-hidden flex flex-col justify-between">
                              <div>
                                <div className="flex items-center gap-2 mb-2">
                                  <Sparkles className="w-4 h-4 text-emerald-400" />
                                  <h4 className="font-serif text-xs font-semibold text-white uppercase tracking-wider">
                                    The Golden Blessing
                                  </h4>
                                </div>
                                <h5 className="font-serif text-sm text-[#ebd094] font-medium mb-1">
                                  {lifeForecast.goodThing.title}
                                </h5>
                                <p className="text-[11px] text-gray-300 leading-relaxed font-sans mb-3">
                                  {lifeForecast.goodThing.reading}
                                </p>
                              </div>
                              <div className="text-[10px] font-mono text-emerald-400/80 uppercase tracking-widest mt-auto">
                                Vibe: {lifeForecast.goodThing.vibe}
                              </div>
                            </div>

                            {/* Bad thing: Saturnian Trap */}
                            <div className="p-4 rounded-xl bg-rose-500/5 border border-rose-500/20 relative overflow-hidden flex flex-col justify-between">
                              <div>
                                <div className="flex items-center gap-2 mb-2">
                                  <AlertTriangle className="w-4 h-4 text-rose-400" />
                                  <h4 className="font-serif text-xs font-semibold text-white uppercase tracking-wider">
                                    The Cosmic Warning
                                  </h4>
                                </div>
                                <h5 className="font-serif text-sm text-red-300 font-medium mb-1">
                                  {lifeForecast.badThing.title}
                                </h5>
                                <p className="text-[11px] text-gray-300 leading-relaxed font-sans mb-3">
                                  {lifeForecast.badThing.reading}
                                </p>
                              </div>
                              <div className="text-[10px] font-mono text-rose-400/80 uppercase tracking-widest mt-auto">
                                Vibe: {lifeForecast.badThing.vibe}
                              </div>
                            </div>

                          </div>

                        </div>
                      )}
                    </div>
                  </motion.div>
                )}

              </div>

              {/* --- COLUMN 3: RIGHT (THE ASTRAL ORACLE CHAT) [4 cols] --- */}
              <div className="lg:col-span-4 flex flex-col h-[650px] lg:h-[720px] glass-panel rounded-2xl overflow-hidden relative">
                {/* CHAT HEADER */}
                <div className="px-5 py-4 bg-[rgba(10,6,18,0.6)] border-b border-[rgba(243,203,123,0.15)] flex items-center justify-between text-left">
                  <div className="flex items-center gap-3">
                    <div className="relative w-7 h-7 rounded-full bg-[rgba(243,203,123,0.08)] border border-[rgba(243,203,123,0.2)] flex items-center justify-center">
                      <Sparkles className="w-3.5 h-3.5 text-[#f3cb7b] star-pulse" />
                    </div>
                    <div>
                      <h4 className="font-serif text-sm text-[#ebd094] uppercase tracking-wider font-light">Astral Oracle</h4>
                      <p className="text-[9px] font-mono text-emerald-400 uppercase tracking-widest flex items-center gap-1 mt-0.5 animate-pulse">
                        ✦ Connected
                      </p>
                    </div>
                  </div>
                </div>

                {/* MESSAGES VIEWPORT */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4 text-left">
                  {chatHistory.map((msg) => {
                    const isUser = msg.role === "user";
                    return (
                      <div
                        key={msg.id}
                        className={`flex flex-col max-w-[85%] ${
                          isUser ? "ml-auto items-end" : "mr-auto items-start"
                        }`}
                      >
                        <div
                          className={`rounded-2xl p-4 shadow-md text-sm leading-relaxed ${
                            isUser
                              ? "bg-[rgba(243,203,123,0.08)] border border-[rgba(243,203,123,0.3)] text-[#f8f9fa] rounded-tr-none"
                              : "bg-[rgba(10,6,18,0.5)] border border-[rgba(243,203,123,0.15)] text-[rgba(248,249,250,0.9)] rounded-tl-none font-serif"
                          }`}
                        >
                          {isUser ? (
                            <p>{msg.text}</p>
                          ) : (
                            <div className="space-y-2">
                              {renderMarkdown(msg.text)}
                            </div>
                          )}
                        </div>
                        <span className="text-[9px] font-mono text-gray-500 mt-1 px-1.5">
                          {msg.timestamp}
                        </span>
                      </div>
                    );
                  })}

                  {/* LOADING TYPING INDICATOR */}
                  {chatLoading && (
                    <div className="flex flex-col mr-auto max-w-[85%] items-start">
                      <div className="bg-[rgba(10,6,18,0.5)] border border-[rgba(243,203,123,0.15)] rounded-2xl rounded-tl-none p-4 flex items-center gap-2">
                        <span className="w-1.5 h-1.5 bg-[#f3cb7b] rounded-full animate-bounce [animation-delay:0s]" />
                        <span className="w-1.5 h-1.5 bg-[#f3cb7b] rounded-full animate-bounce [animation-delay:0.2s]" />
                        <span className="w-1.5 h-1.5 bg-[#f3cb7b] rounded-full animate-bounce [animation-delay:0.4s]" />
                      </div>
                      <span className="text-[9px] font-mono text-gray-500 mt-1 px-1.5">
                        Consulting transit paths...
                      </span>
                    </div>
                  )}

                  <div ref={chatEndRef} />
                </div>

                {/* BOTTOM COMPOSER & INTERACTIVE CHIPS */}
                <div className="p-4 bg-[rgba(10,6,18,0.5)] border-t border-[rgba(243,203,123,0.15)] flex flex-col gap-3">
                  {/* QUICK QUESTION CHIPS */}
                  <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
                    {quickQuestions.map((q, i) => (
                      <button
                        key={i}
                        onClick={() => handleSendMessage(q)}
                        disabled={chatLoading}
                        className="text-[10px] font-mono border border-[rgba(243,203,123,0.15)] bg-[rgba(243,203,123,0.03)] hover:bg-[rgba(243,203,123,0.08)] hover:border-[#f3cb7b] px-3 py-1.5 rounded-full whitespace-nowrap text-[#ebd094] transition-all cursor-pointer"
                      >
                        ✦ {q}
                      </button>
                    ))}
                  </div>

                  {/* CHAT INPUT AREA */}
                  <div className="flex items-center gap-2 bg-[rgba(10,6,18,0.7)] border border-[rgba(243,203,123,0.15)] focus-within:border-[#f3cb7b] rounded-xl px-3.5 py-1.5 transition-all">
                    <input
                      type="text"
                      disabled={chatLoading}
                      placeholder="Ask the stars about your path..."
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") handleSendMessage();
                      }}
                      className="flex-1 bg-transparent border-none outline-none text-sm text-[#f8f9fa] placeholder-[rgba(248,249,252,0.35)]"
                    />
                    <button
                      onClick={() => handleSendMessage()}
                      disabled={chatLoading || !chatInput.trim()}
                      className="p-2 bg-[#f3cb7b] hover:bg-[#ebd094] disabled:bg-gray-800 disabled:text-gray-500 text-[#0a0612] rounded-lg transition-all cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* INSTAGRAM SHARE MODAL */}
        <AnimatePresence>
          {showShareModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="relative max-w-sm w-full bg-[#0d091a] border border-[#f3cb7b]/40 rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(243,203,123,0.2)]"
              >
                {/* Close Button */}
                <button
                  onClick={() => {
                    setShowShareModal(false);
                    setCopiedLink(false);
                  }}
                  className="absolute top-4 right-4 z-50 p-2 rounded-full bg-black/40 hover:bg-black/60 border border-white/10 text-white transition-all cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>

                {/* 9:16 Mockup Canvas */}
                <div className="p-6 pb-2 text-center flex flex-col justify-between aspect-[9/16] bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-[rgba(243,203,123,0.15)] via-[#0d091a] to-[#0a0612] relative select-none">
                  <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px]" />

                  {/* Top stamp */}
                  <div className="flex flex-col items-center gap-1 mt-4 relative z-10">
                    <Compass className="w-6 h-6 text-[#f3cb7b] spin-celestial" />
                    <span className="text-[9px] font-mono tracking-widest uppercase text-gray-400">AURA ASTROLOGY</span>
                    <span className="text-[10px] font-serif text-[#ebd094] tracking-wider italic">
                      {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                    </span>
                  </div>

                  {/* Main contents */}
                  <div className="my-auto relative z-10 space-y-5">
                    <div>
                      <span className="text-xs font-mono text-gray-500 uppercase tracking-widest block">CHART ALIGNMENT</span>
                      <h4 className="font-serif text-2xl font-light text-gold-gradient mt-1">{profile.name}</h4>
                    </div>

                    {/* Sign matrix stamps */}
                    <div className="grid grid-cols-3 gap-2 max-w-[280px] mx-auto text-center">
                      <div className="p-2 bg-black/40 rounded-xl border border-[#f3cb7b]/15">
                        <span className="text-xl block text-[#f3cb7b]">☉</span>
                        <span className="text-[8px] text-gray-500 block uppercase font-mono tracking-wider">SUN</span>
                        <span className="text-[10px] text-white font-serif block truncate">{profile.sunSign}</span>
                      </div>
                      <div className="p-2 bg-black/40 rounded-xl border border-[#f3cb7b]/15">
                        <span className="text-xl block text-[#f3cb7b]">☽</span>
                        <span className="text-[8px] text-gray-500 block uppercase font-mono tracking-wider">MOON</span>
                        <span className="text-[10px] text-white font-serif block truncate">{profile.moonSign}</span>
                      </div>
                      <div className="p-2 bg-black/40 rounded-xl border border-[#f3cb7b]/15">
                        <span className="text-[8px] bg-[#f3cb7b]/10 text-[#f3cb7b] px-1 py-0.5 rounded border border-[#f3cb7b]/20 mb-1 inline-block font-mono font-bold leading-none scale-90">ASC</span>
                        <span className="text-[8px] text-gray-500 block uppercase font-mono tracking-wider">RISING</span>
                        <span className="text-[10px] text-white font-serif block truncate">{profile.ascendantSign}</span>
                      </div>
                    </div>

                    {/* Daily Vitals scores */}
                    <div className="bg-black/30 border border-white/5 rounded-2xl p-4 space-y-2.5 max-w-[280px] mx-auto text-left">
                      <span className="text-[9px] font-mono uppercase tracking-widest text-gray-500 block text-center mb-1">Celestial Vitals</span>
                      {[
                        { label: "LOVE SYNERGY", score: transitData?.vitals.love || 88, color: "bg-rose-500" },
                        { label: "DESTINY FREQ", score: transitData?.vitals.career || 75, color: "bg-sky-500" },
                        { label: "SOUL STRENGTH", score: transitData?.vitals.energy || 90, color: "bg-purple-500" }
                      ].map((v, i) => (
                        <div key={i} className="flex items-center justify-between text-[10px] font-mono">
                          <span className="text-gray-400">{v.label}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-white font-bold">{v.score}%</span>
                            <div className="w-12 h-1 bg-white/10 rounded-full overflow-hidden">
                              <div className={`h-full ${v.color}`} style={{ width: `${v.score}%` }} />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Witty Quote stamp */}
                    <div className="border-t border-[#f3cb7b]/15 pt-4 max-w-[260px] mx-auto">
                      <p className="text-xs text-gray-300 italic font-serif leading-relaxed px-2">
                        "Do not explain your silence to those who prefer your noise. Trust your Scorpio transits tonight."
                      </p>
                    </div>
                  </div>

                  {/* Foot label */}
                  <div className="mb-4 relative z-10 flex flex-col items-center gap-0.5">
                    <span className="text-[8px] font-mono tracking-wider text-gray-500 uppercase">CALCULATED VIA AURA ASTROLOGY</span>
                    <span className="text-[7px] font-mono text-gray-600">BOUNDLESS • TIMELESS • ETERNAL</span>
                  </div>
                </div>

                {/* Bottom Actions Row */}
                <div className="p-4 bg-[rgba(10,6,18,0.9)] border-t border-[#f3cb7b]/15 flex gap-3 text-xs">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(window.location.href);
                      setCopiedLink(true);
                      setTimeout(() => setCopiedLink(false), 2000);
                    }}
                    className="flex-1 py-3 bg-[#f3cb7b] hover:bg-[#ebd094] text-[#0a0612] rounded-xl font-medium tracking-wide transition-all cursor-pointer text-center border-none"
                  >
                    {copiedLink ? "✓ Copied Link" : "Copy Story Link"}
                  </button>
                  <button
                    onClick={() => {
                      alert("Daily social story saved to system clipboard mock-cache! Ready to post on Instagram/TikTok.");
                      setShowShareModal(false);
                    }}
                    className="flex-1 py-3 border border-[#f3cb7b]/30 bg-white/5 hover:bg-white/10 text-white rounded-xl transition-all cursor-pointer text-center animate-pulse"
                  >
                    Export Image
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </main>

      {/* FOOTER */}
      <footer className="relative w-full z-10 py-8 mt-16 border-t border-[rgba(243,203,123,0.1)] bg-[rgba(10,6,18,0.4)] text-center text-[11px] font-serif text-gray-500 tracking-wider">
        <p>Aura Astrology © 2026. Handcrafted for cosmic travelers.</p>
      </footer>
    </div>
  );
}
