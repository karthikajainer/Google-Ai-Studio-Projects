export interface UserProfile {
  name: string;
  birthDate: string;
  birthTime: string;
  birthPlace: string;
  guidanceType: string;
  sunSign: string;
  moonSign: string;
  ascendantSign: string;
}

export interface TransitData {
  transitText: string;
  embrace: string[];
  evade: string[];
  vitals: {
    love: number;
    career: number;
    wealth: number;
    energy: number;
  };
  isSimulated?: boolean;
}

export interface ChatMessage {
  id: string;
  role: "user" | "model";
  text: string;
  timestamp: string;
}

export interface SignMatrixDetail {
  title: string;
  element: string;
  quality: string;
  rulingPlanet: string;
  description: string;
  strengths: string[];
  vibe: string;
}
